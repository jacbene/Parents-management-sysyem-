/**
 * Utilitaire d'encodage SMS pour la gestion des caractères français (GSM-7 vs UCS-2)
 * Permet de diagnostiquer et d'optimiser l'envoi de SMS via Twilio et passerelles mobiles.
 */

// Alphabet GSM 03.38 standard (7 bits)
// Note: 'é', 'è', 'à', 'ù', 'ì', 'ò', 'Ç' font partie du GSM-7 standard.
// Les lettres 'ê', 'ë', 'â', 'î', 'ï', 'ô', 'û', 'ç' (minuscule) nécessitent UCS-2.
const GSM_7_REGEX = /^[@£$¥èéùìòÇ\r\nØøÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !"#¤%&'()*+,\-./0-9:;<=>?¡A-ZÄÖÑÜ§¿a-zäöñüà\f\^{}\[~\]\\|€]*$/;

export interface SmsEncodingAnalysis {
  encoding: 'GSM-7' | 'UCS-2 (Unicode)';
  isGsm7: boolean;
  length: number;
  segments: number;
  maxPerSingleSms: number;
  maxPerMultiSegment: number;
  charsRemainingInCurrentSegment: number;
  nonGsmCharacters: string[];
}

/**
 * Analyse le texte d'un SMS et détermine son encodage réel (GSM-7 ou UCS-2),
 * ainsi que le nombre de segments qui seront facturés par l'opérateur.
 */
export function analyzeSms(text: string): SmsEncodingAnalysis {
  if (!text) {
    return {
      encoding: 'GSM-7',
      isGsm7: true,
      length: 0,
      segments: 0,
      maxPerSingleSms: 160,
      maxPerMultiSegment: 153,
      charsRemainingInCurrentSegment: 160,
      nonGsmCharacters: []
    };
  }

  // Détection des caractères hors GSM-7 (ex: ç, ê, â, î, ô, û, œ)
  const nonGsmSet = new Set<string>();
  for (const char of text) {
    if (!GSM_7_REGEX.test(char)) {
      nonGsmSet.add(char);
    }
  }

  const isGsm7 = nonGsmSet.size === 0;
  const length = text.length;

  if (isGsm7) {
    // GSM-7 Standard : 160 caractères pour le 1er SMS, 153 par segment pour les SMS multiples
    const maxSingle = 160;
    const maxMulti = 153;
    const segments = length <= maxSingle ? (length === 0 ? 0 : 1) : Math.ceil(length / maxMulti);
    const charsRemaining = length <= maxSingle 
      ? maxSingle - length 
      : (segments * maxMulti) - length;

    return {
      encoding: 'GSM-7',
      isGsm7: true,
      length,
      segments,
      maxPerSingleSms: maxSingle,
      maxPerMultiSegment: maxMulti,
      charsRemainingInCurrentSegment: Math.max(0, charsRemaining),
      nonGsmCharacters: []
    };
  } else {
    // UCS-2 (Unicode UTF-16) : 70 caractères pour le 1er SMS, 67 par segment pour les SMS multiples
    const maxSingle = 70;
    const maxMulti = 67;
    const segments = length <= maxSingle ? 1 : Math.ceil(length / maxMulti);
    const charsRemaining = length <= maxSingle 
      ? maxSingle - length 
      : (segments * maxMulti) - length;

    return {
      encoding: 'UCS-2 (Unicode)',
      isGsm7: false,
      length,
      segments,
      maxPerSingleSms: maxSingle,
      maxPerMultiSegment: maxMulti,
      charsRemainingInCurrentSegment: Math.max(0, charsRemaining),
      nonGsmCharacters: Array.from(nonGsmSet)
    };
  }
}

/**
 * Optimise un texte contenant des accents français pour le standard GSM-7 (160 car./SMS)
 * en remplaçant uniquement les caractères non-GSM7 par des équivalents lisibles.
 * Ex : 'ç' -> 'c', 'ê' -> 'e', 'â' -> 'a', etc.
 * Les caractères 'é', 'è', 'à' qui sont DÉJÀ en GSM-7 sont scrupuleusement conservés.
 */
export function optimizeToGsm7(text: string): string {
  if (!text) return text;
  
  return text
    // 'ç' minuscule -> 'c' (car seul le 'Ç' majuscule est dans le GSM-7 standard)
    .replace(/ç/g, 'c')
    // Circonflexes et trémas (hors GSM-7)
    .replace(/[êë]/g, 'e')
    .replace(/[ÊË]/g, 'E')
    .replace(/[âä]/g, 'a')
    .replace(/[ÂÄ]/g, 'A')
    .replace(/[îï]/g, 'i')
    .replace(/[ÎÏ]/g, 'I')
    .replace(/[ôö]/g, 'o')
    .replace(/[ÔÖ]/g, 'O')
    .replace(/[ûü]/g, 'u')
    .replace(/[ÛÜ]/g, 'U')
    // Ligatures
    .replace(/œ/g, 'oe')
    .replace(/Œ/g, 'OE')
    .replace(/æ/g, 'ae')
    .replace(/Æ/g, 'AE')
    // Apostrophes typographiques
    .replace(/[’‘`]/g, "'")
    // Guillemets français
    .replace(/[«»]/g, '"');
}
