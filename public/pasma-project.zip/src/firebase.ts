import { initializeApp, getApp, getApps } from 'firebase/app';
import { 
  getAuth, 
  initializeAuth,
  browserLocalPersistence,
  browserSessionPersistence,
  GoogleAuthProvider, 
  signInWithPopup, 
  signInWithRedirect,
  getRedirectResult,
  signOut, 
  signInAnonymously, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  sendPasswordResetEmail,
  sendEmailVerification 
} from 'firebase/auth';
import { initializeFirestore, setLogLevel, getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Silence Firestore's built-in unreachable backend warnings in sandbox container
setLogLevel('silent');

const databaseId = (firebaseConfig as any).firestoreDatabaseId;
let dbInstance;

try {
  // Use experimentalForceLongPolling: true to ensure stable network connections
  // in sandboxed iframe / containerized environments to prevent transport-layer stream drop exceptions (ca9/b815 / ve: -1).
  dbInstance = databaseId 
    ? initializeFirestore(app, { experimentalForceLongPolling: true }, databaseId)
    : initializeFirestore(app, { experimentalForceLongPolling: true });
} catch (error: any) {
  // If already initialized (e.g. during dev HMR loads), safely retrieve the active instance
  dbInstance = databaseId ? getFirestore(app, databaseId) : getFirestore(app);
}

export const db = dbInstance;
export const storage = getStorage(app);

let simulatedOffline = typeof localStorage !== 'undefined' ? localStorage.getItem('pasma_offline_simulated') === 'true' : false;

export function isOffline() {
  return simulatedOffline || (typeof navigator !== 'undefined' && !navigator.onLine);
}

export async function goOffline() {
  simulatedOffline = true;
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('pasma_offline_simulated', 'true');
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('pasma_connection_changed'));
    window.dispatchEvent(new Event('pasma_actions_updated'));
  }
  console.log("[Pasma-sys Local Sync] Simulated offline mode activated (using local persistence cache).");
}

export async function goOnline() {
  simulatedOffline = false;
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('pasma_offline_simulated', 'false');
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('pasma_connection_changed'));
    window.dispatchEvent(new Event('pasma_actions_updated'));
  }
  console.log("[Pasma-sys Local Sync] Connection network active / sync restored.");
}

export function queuePendingAction(
  type: 'CREATE' | 'UPDATE' | 'DELETE',
  collection: string,
  targetId: string,
  title: string,
  data?: any
) {
  try {
    if (typeof localStorage === 'undefined') return;
    const saved = localStorage.getItem('pasma_pending_actions');
    const list = saved ? JSON.parse(saved) : [];
    
    let newList = [...list];
    if (type === 'DELETE') {
      newList = newList.filter((item: any) => !(item.collection === collection && item.targetId === targetId));
    } else if (type === 'UPDATE') {
      const existingIdx = newList.findIndex((item: any) => item.collection === collection && item.targetId === targetId && item.type !== 'DELETE');
      if (existingIdx !== -1) {
        newList[existingIdx].data = data;
        newList[existingIdx].title = title;
        newList[existingIdx].timestamp = new Date().toISOString();
        localStorage.setItem('pasma_pending_actions', JSON.stringify(newList));
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new Event('pasma_actions_updated'));
          window.dispatchEvent(new CustomEvent('pasma_save_offline', { detail: { title } }));
        }
        return;
      }
    }

    const newAction = {
      id: 'pa_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      type,
      collection,
      targetId,
      title,
      timestamp: new Date().toISOString(),
      data
    };
    newList.push(newAction);
    localStorage.setItem('pasma_pending_actions', JSON.stringify(newList));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('pasma_actions_updated'));
      window.dispatchEvent(new CustomEvent('pasma_save_offline', { detail: { title } }));
    }
  } catch (err) {
    console.error("Failed to queue pending action:", err);
  }
}

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export const googleDriveProvider = new GoogleAuthProvider();
googleDriveProvider.addScope('https://www.googleapis.com/auth/drive.file');
googleDriveProvider.addScope('https://www.googleapis.com/auth/spreadsheets');
googleDriveProvider.addScope('https://www.googleapis.com/auth/gmail.readonly');
googleDriveProvider.addScope('https://www.googleapis.com/auth/gmail.send');
googleDriveProvider.addScope('https://www.googleapis.com/auth/gmail.labels');
googleDriveProvider.addScope('https://www.googleapis.com/auth/gmail.modify');
googleDriveProvider.setCustomParameters({ prompt: 'select_account' });

export let googleAccessToken: string | null = typeof localStorage !== 'undefined' ? localStorage.getItem('pasma_google_access_token') : null;

export function setGoogleAccessToken(token: string | null) {
  googleAccessToken = token;
  if (typeof localStorage !== 'undefined') {
    if (token) {
      localStorage.setItem('pasma_google_access_token', token);
    } else {
      localStorage.removeItem('pasma_google_access_token');
    }
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('pasma_google_token_changed'));
  }
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errMsg = error instanceof Error ? error.message : String(error);
  if (
    errMsg.includes('unavailable') || 
    errMsg.includes('Could not reach') || 
    errMsg.includes('offline') || 
    errMsg.includes('Failed to get document') ||
    errMsg.includes('permission') ||
    errMsg.includes('Missing or insufficient permissions') ||
    errMsg.includes('PERMISSION_DENIED')
  ) {
    console.warn(`[Pasma-sys Local Sync] Notice during ${operationType} on ${path || 'database'}: ${errMsg}. Handled via local storage cache.`);
    return;
  }
  const errInfo: FirestoreErrorInfo = {
    error: errMsg,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.warn('Firestore Notice: ', JSON.stringify(errInfo));
}

export async function loginWithGoogle(requireDriveScopes: boolean = false) {
  const providerToUse = requireDriveScopes ? googleDriveProvider : googleProvider;
  try {
    const result = await signInWithPopup(auth, providerToUse);
    if (result) {
      try {
        const credential = GoogleAuthProvider.credentialFromResult(result);
        if (credential?.accessToken) {
          setGoogleAccessToken(credential.accessToken);
        }
      } catch (e) {
        console.warn("Could not extract credential from result:", e);
      }
      return result.user;
    }
    return null;
  } catch (error: any) {
    console.warn("Google Auth Error during signInWithPopup:", error);
    const isInIframe = typeof window !== 'undefined' && window.self !== window.top;
    
    // Only attempt redirect fallback if NOT in a sandboxed iframe (redirecting inside an iframe gets blocked by X-Frame-Options)
    if (!isInIframe && (error?.code === 'auth/popup-blocked' || error?.code === 'auth/cancelled-popup-request')) {
      console.info("Popup blocked outside iframe, attempting signInWithRedirect fallback...");
      try {
        if (typeof sessionStorage !== 'undefined') {
          sessionStorage.setItem('pasma_redirect_pending', 'true');
        }
      } catch (e) {
        // ignore
      }
      await signInWithRedirect(auth, providerToUse);
      return null;
    }
    throw error;
  }
}

export async function checkRedirectResult() {
  // If running inside a sandboxed iframe (like AI Studio preview), redirect flows are disabled/unsupported
  const isInIframe = typeof window !== 'undefined' && window.self !== window.top;
  if (isInIframe) {
    return null;
  }

  // Check if a redirect sign-in was actually initiated before invoking getRedirectResult
  // Calling getRedirectResult() unconditionally when no redirect took place causes @firebase/auth (v12.x)
  // to trigger an unhandled assertion "INTERNAL ASSERTION FAILED: Pending promise was never set"
  let hasPendingRedirect = false;
  try {
    if (typeof sessionStorage !== 'undefined') {
      if (sessionStorage.getItem('pasma_redirect_pending') === 'true') {
        hasPendingRedirect = true;
        sessionStorage.removeItem('pasma_redirect_pending');
      } else {
        for (let i = 0; i < sessionStorage.length; i++) {
          const key = sessionStorage.key(i);
          if (key && (key.includes('pendingRedirect') || key.includes('firebase:authUser'))) {
            hasPendingRedirect = true;
            break;
          }
        }
      }
    }
    if (typeof window !== 'undefined' && window.location) {
      const hash = window.location.hash || '';
      const search = window.location.search || '';
      if (hash.includes('access_token') || hash.includes('id_token') || search.includes('apiKey') || search.includes('state')) {
        hasPendingRedirect = true;
      }
    }
  } catch (e) {
    // ignore storage access errors in sandboxes
  }

  if (!hasPendingRedirect) {
    return null;
  }

  try {
    const result = await getRedirectResult(auth);
    if (result) {
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setGoogleAccessToken(credential.accessToken);
      }
      return result.user;
    }
  } catch (error: any) {
    if (error?.message?.includes('Pending promise was never set')) {
      return null;
    }
    console.warn("Error checking redirect result:", error);
  }
  return null;
}

export async function loginAnonymously() {
  try {
    const result = await signInAnonymously(auth);
    return result.user;
  } catch (error: any) {
    console.info("Anonymous auth notice, trying shared sandbox fallback account:", error?.message || error);
    try {
      const result = await signInWithEmailAndPassword(auth, "sandbox@pasma.sys", "sandbox123456");
      return result.user;
    } catch (err2: any) {
      if (err2?.code === 'auth/user-not-found' || err2?.code === 'auth/invalid-credential' || err2?.code === 'auth/wrong-password') {
        try {
          const result = await createUserWithEmailAndPassword(auth, "sandbox@pasma.sys", "sandbox123456");
          return result.user;
        } catch (err3: any) {
          console.info("Notice: Returning local offline guest user profile:", err3?.message || err3);
          return {
            uid: 'sandboxed_guest_user_ekali',
            email: 'directeur.ekali@gmail.com',
            displayName: "Directeur Académique (Mode Sécurisé Local)",
            photoURL: '',
            isAnonymous: true
          } as any;
        }
      }
      console.info("Notice: Returning local offline guest user fallback profile:", err2?.message || err2);
      return {
        uid: 'sandboxed_guest_user_ekali',
        email: 'directeur.ekali@gmail.com',
        displayName: "Directeur Académique (Mode Sécurisé Local)",
        photoURL: '',
        isAnonymous: true
      } as any;
    }
  }
}

export async function dispatchBackendConfirmationEmail(email: string, name?: string, type?: string) {
  try {
    const response = await fetch('/api/send-confirmation-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, name, type })
    });
    const data = await response.json();
    if (data?.testUrl) {
      console.log(`[Ethereal Confirmation Email Preview]: ${data.testUrl}`);
    }
    return data;
  } catch (err) {
    console.warn("Backend confirmation email request failed:", err);
    return null;
  }
}

export function markEmailAsVerifiedLocally(email: string) {
  if (!email) return;
  try {
    const clean = email.toLowerCase().trim();
    const existingStr = localStorage.getItem('pasma_verified_emails');
    const existing: string[] = existingStr ? JSON.parse(existingStr) : [];
    if (!existing.includes(clean)) {
      existing.push(clean);
      localStorage.setItem('pasma_verified_emails', JSON.stringify(existing));
    }
  } catch (e) {
    console.warn("Error storing verified email locally:", e);
  }
}

export function isEmailVerifiedLocally(email?: string | null): boolean {
  if (!email) return false;
  try {
    const clean = email.toLowerCase().trim();
    if (clean === 'jacquesbene301@gmail.com' || clean === 'adjoint@pasma.sys' || clean.endsWith('@pasma.sys')) {
      return true;
    }
    const existingStr = localStorage.getItem('pasma_verified_emails');
    const existing: string[] = existingStr ? JSON.parse(existingStr) : [];
    return Array.isArray(existing) && existing.includes(clean);
  } catch (e) {
    return false;
  }
}

export function isUserEmailVerified(user: any): boolean {
  if (!user) return true;
  if (user.isAnonymous) return true;
  if (user.emailVerified) return true;
  if (user.email && isEmailVerifiedLocally(user.email)) return true;
  return false;
}

export async function sendUserEmailVerification(userToVerify?: any) {
  try {
    const targetUser = userToVerify || auth.currentUser;
    
    // Check if targetUser is already verified
    if (isUserEmailVerified(targetUser)) {
      return false; // Already verified!
    }

    // Try reloading user from Firebase auth to check fresh server status
    if (targetUser && typeof targetUser.reload === 'function') {
      try {
        await targetUser.reload();
        if (targetUser.emailVerified) {
          if (targetUser.email) markEmailAsVerifiedLocally(targetUser.email);
          return false; // Already verified after reload!
        }
      } catch (rErr) {
        console.warn("Notice reloading user before verification dispatch:", rErr);
      }
    }

    const email = targetUser?.email;
    const displayName = targetUser?.displayName;

    if (targetUser && !targetUser.isAnonymous && typeof targetUser.getIdToken === 'function') {
      try {
        await sendEmailVerification(targetUser);
      } catch (sdkError: any) {
        console.warn("Firebase Auth sendEmailVerification SDK notice:", sdkError);
      }
    }

    if (email) {
      await dispatchBackendConfirmationEmail(email, displayName || email.split('@')[0], 'verification');
    }

    return true;
  } catch (error) {
    console.warn("Send Email Verification Error:", error);
    return true; // Graceful fallback
  }
}

export async function signUpWithEmail(email: string, password: string) {
  try {
    const result = await createUserWithEmailAndPassword(auth, email, password);
    if (result.user) {
      try {
        await sendEmailVerification(result.user);
      } catch (verifErr) {
        console.warn("Automatic sendEmailVerification failed:", verifErr);
      }
      await dispatchBackendConfirmationEmail(email, result.user.displayName || email.split('@')[0], 'verification');
    }
    return result.user;
  } catch (error) {
    console.warn("SignUp Email Error, dispatching backend confirmation email fallback:", error);
    await dispatchBackendConfirmationEmail(email, email.split('@')[0], 'verification');
    throw error;
  }
}

export async function loginWithEmail(email: string, password: string) {
  try {
    const result = await signInWithEmailAndPassword(auth, email, password);
    try {
      await result.user.reload();
      if (result.user.emailVerified && result.user.email) {
        markEmailAsVerifiedLocally(result.user.email);
      }
    } catch (reloadErr) {
      console.warn("Notice reloading user after login:", reloadErr);
    }
    return result.user;
  } catch (error) {
    console.warn("Login Email Error:", error);
    throw error;
  }
}

export async function resetPassword(email: string) {
  try {
    await sendPasswordResetEmail(auth, email);
    await dispatchBackendConfirmationEmail(email, email.split('@')[0], 'password_reset');
    return true;
  } catch (error: any) {
    console.warn("Password Reset Error, sending via backend fallback:", error);
    if (email && email.includes('@')) {
      await dispatchBackendConfirmationEmail(email, email.split('@')[0], 'password_reset');
      return true;
    }
    throw error;
  }
}

export async function logout() {
  await signOut(auth);
  googleAccessToken = null;
}
