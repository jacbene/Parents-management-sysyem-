import React, { useState } from 'react';
import { Save, HelpCircle, Shield, Settings, Info, CheckCircle2, Plus, Trash2, Edit2, X, TrendingUp, Lock, Unlock, UserCheck, User, Phone, Mail, GraduationCap, AlertTriangle, CreditCard, Smartphone, Calculator, Percent, TrendingDown, RefreshCw, DollarSign, BookOpen, BookMarked, Layers, Filter } from 'lucide-react';
import { ApeeSettings, ApeeBudgetLine, ApeeParent, ClassSubject } from '../../types';
import { DEFAULT_SCHOOL_LOGO } from '../../constants';
import { getApeeShortName, DEFAULT_SETTINGS } from '../../utils/apeeDb';
import { useLanguage } from '../../utils/TranslationContext';
import LanguageSelector from '../LanguageSelector';
import PaymentConfigurationForm from '../PaymentConfigurationForm';
import SmsConfigurationForm from './SmsConfigurationForm';

interface ApeeSettingsProps {
  settings: ApeeSettings;
  onSaveSettings: (settings: ApeeSettings) => Promise<boolean> | void;
  parents?: ApeeParent[];
}

export default function ApeeSettingsComp({ settings, onSaveSettings, parents = [] }: ApeeSettingsProps) {
  const { t, language } = useLanguage();
  const [associationName, setAssociationName] = useState(settings.associationName || '');
  const [shortName, setShortName] = useState(settings.shortName || '');
  const [schoolYear, setSchoolYear] = useState(settings.schoolYear || '');
  const [logoUrl, setLogoUrl] = useState(settings.logoUrl || '');
  const [expectedStudents, setExpectedStudents] = useState<number>(settings.expectedStudents || 100);
  const [honoraryContributions, setHonoraryContributions] = useState<number>(settings.honoraryContributions || 0);
  const [subventionsAndAids, setSubventionsAndAids] = useState<number>(settings.subventionsAndAids || 0);
  const [actualHonoraryContributions, setActualHonoraryContributions] = useState<number>(settings.actualHonoraryContributions || 0);
  const [actualSubventionsAndAids, setActualSubventionsAndAids] = useState<number>(settings.actualSubventionsAndAids || 0);
  const [syncIntervalSeconds, setSyncIntervalSeconds] = useState<number>(settings.syncIntervalSeconds || 30);
  
  // Country & Currency addition inputs
  const [country, setCountry] = useState(settings.country || 'Cameroun');
  const [currency, setCurrency] = useState(settings.currency || 'FCFA');
  const [financialObligations, setFinancialObligations] = useState(() => settings.financialObligations || []);

  // Payment config state
  const [cardEnabled, setCardEnabled] = useState(settings.paymentConfig?.cardEnabled ?? false);
  const [stripePublicKey, setStripePublicKey] = useState(settings.paymentConfig?.stripePublicKey || '');
  const [stripeSecretKey, setStripeSecretKey] = useState(settings.paymentConfig?.stripeSecretKey || '');

  const [mtnEnabled, setMtnEnabled] = useState(settings.paymentConfig?.mtnEnabled ?? false);
  const [mtnPhoneNumber, setMtnPhoneNumber] = useState(settings.paymentConfig?.mtnPhoneNumber || '');
  const [mtnMerchantName, setMtnMerchantName] = useState(settings.paymentConfig?.mtnMerchantName || '');
  const [mtnClientId, setMtnClientId] = useState(settings.paymentConfig?.mtnClientId || '');
  const [mtnClientSecret, setMtnClientSecret] = useState(settings.paymentConfig?.mtnClientSecret || '');

  const [orangeEnabled, setOrangeEnabled] = useState(settings.paymentConfig?.orangeEnabled ?? false);
  const [orangePhoneNumber, setOrangePhoneNumber] = useState(settings.paymentConfig?.orangePhoneNumber || '');
  const [orangeMerchantName, setOrangeMerchantName] = useState(settings.paymentConfig?.orangeMerchantName || '');
  const [orangeMerchantKey, setOrangeMerchantKey] = useState(settings.paymentConfig?.orangeMerchantKey || '');
  const [orangeClientId, setOrangeClientId] = useState(settings.paymentConfig?.orangeClientId || '');
  const [orangeClientSecret, setOrangeClientSecret] = useState(settings.paymentConfig?.orangeClientSecret || '');

  const [waveEnabled, setWaveEnabled] = useState(settings.paymentConfig?.waveEnabled ?? false);
  const [wavePhoneNumber, setWavePhoneNumber] = useState(settings.paymentConfig?.wavePhoneNumber || '');
  const [waveMerchantName, setWaveMerchantName] = useState(settings.paymentConfig?.waveMerchantName || '');
  const [waveApiKey, setWaveApiKey] = useState(settings.paymentConfig?.waveApiKey || '');

  // Key hide/show states
  const [showStripeSecret, setShowStripeSecret] = useState(false);
  const [showMtnSecret, setShowMtnSecret] = useState(false);
  const [showOrangeSecret, setShowOrangeSecret] = useState(false);
  const [showWaveSecret, setShowWaveSecret] = useState(false);

  // Inline additions state for obligations
  const [newOblName, setNewOblName] = useState('');
  const [newOblAmount, setNewOblAmount] = useState<number>(0);
  const [newOblType, setNewOblType] = useState<'per_student' | 'per_parent'>('per_student');
  const [newOblDesc, setNewOblDesc] = useState('');
  const [editingOblId, setEditingOblId] = useState<string | null>(null);

  // Dynamic calculations according to client instructions:
  // We list all obligations and calculate the parent cotisations and goal.
  const totalObligationsPerStudent = financialObligations
    .filter(o => o.type === 'per_student')
    .reduce((sum, o) => sum + o.amount, 0);

  const totalObligationsPerParent = financialObligations
    .filter(o => o.type === 'per_parent')
    .reduce((sum, o) => sum + o.amount, 0);

  // Parent cotisations (expected total) = expectedStudents * totalObligationsPerStudent + expectedStudents * totalObligationsPerParent
  const parentCotisations = (expectedStudents * totalObligationsPerStudent) + (expectedStudents * totalObligationsPerParent);

  const calculatedFinancialGoal = parentCotisations + honoraryContributions + subventionsAndAids;

  // Financial Manager credentials states
  const [finManagerName, setFinManagerName] = useState(settings.finManagerName || '');
  const [finManagerPhone, setFinManagerPhone] = useState(settings.finManagerPhone || '');
  const [finManagerPassword, setFinManagerPassword] = useState(settings.finManagerPassword || '');
  const [showPassword, setShowPassword] = useState(false);

  // Pedagogical Manager credentials states
  const [pedManagerName, setPedManagerName] = useState(settings.pedManagerName || '');
  const [pedManagerPhone, setPedManagerPhone] = useState(settings.pedManagerPhone || '');
  const [pedManagerPassword, setPedManagerPassword] = useState(settings.pedManagerPassword || '');
  const [showPedPassword, setShowPedPassword] = useState(false);

  // Principal Administrators states
  const [directorName, setDirectorName] = useState(settings.directorName || '');
  const [directorPhone, setDirectorPhone] = useState(settings.directorPhone || '');
  const [directorEmail, setDirectorEmail] = useState(settings.directorEmail || '');

  const [surveillantName, setSurveillantName] = useState(settings.surveillantName || '');
  const [surveillantPhone, setSurveillantPhone] = useState(settings.surveillantPhone || '');

  const [censeurName, setCenseurName] = useState(settings.censeurName || '');
  const [censeurPhone, setCenseurPhone] = useState(settings.censeurPhone || '');

  // Class Teachers (teachers mapping list)
  const [classTeachers, setClassTeachers] = useState(() => {
    const defaultClassrooms = [
      { classRoom: '6ème', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: '5ème', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: '4ème ALL', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: '4ème ESP', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: '3ème ALL', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: '3ème ESP', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: '2nde', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: '1ère', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: 'Tle', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: 'CM2-A', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: 'CE2-B', teacherName: '', teacherPhone: '', teacherEmail: '' },
      { classRoom: 'CM1-A', teacherName: '', teacherPhone: '', teacherEmail: '' },
    ];
    const saved = settings.classTeachers || [];
    const savedMapped = saved.map(s => ({
      classRoom: s.classRoom,
      teacherName: s.teacherName || '',
      teacherPhone: s.teacherPhone || '',
      teacherEmail: s.teacherEmail || '',
    }));
    const missingPredefined = defaultClassrooms.filter(d => !saved.some(s => s.classRoom === d.classRoom));
    return [...savedMapped, ...missingPredefined];
  });

  // Class Subjects state
  const [classSubjects, setClassSubjects] = useState<ClassSubject[]>(() => {
    return settings.classSubjects || DEFAULT_SETTINGS.classSubjects || [];
  });
  const [newSubjName, setNewSubjName] = useState('');
  const [newSubjClass, setNewSubjClass] = useState('Toutes les classes');
  const [newSubjCoef, setNewSubjCoef] = useState<number>(2);
  const [newSubjCategory, setNewSubjCategory] = useState<string>('Scientifique');
  const [newSubjTeacher, setNewSubjTeacher] = useState('');
  const [editingSubjId, setEditingSubjId] = useState<string | null>(null);
  const [subjClassFilter, setSubjClassFilter] = useState<string>('all');

  // Synchronize local states with settings props when they load/change
  React.useEffect(() => {
    if (settings) {
      setAssociationName(settings.associationName || '');
      setShortName(settings.shortName || '');
      setSchoolYear(settings.schoolYear || '');
      setCountry(settings.country || 'Cameroun');
      setCurrency(settings.currency || 'FCFA');
      setFinancialObligations(settings.financialObligations || []);
      setLogoUrl(settings.logoUrl || '');
      setExpectedStudents(settings.expectedStudents || 100);
      setHonoraryContributions(settings.honoraryContributions || 0);
      setSubventionsAndAids(settings.subventionsAndAids || 0);
      setActualHonoraryContributions(settings.actualHonoraryContributions || 0);
      setActualSubventionsAndAids(settings.actualSubventionsAndAids || 0);
      setFinManagerName(settings.finManagerName || '');
      setFinManagerPhone(settings.finManagerPhone || '');
      setFinManagerPassword(settings.finManagerPassword || '');
      setPedManagerName(settings.pedManagerName || '');
      setPedManagerPhone(settings.pedManagerPhone || '');
      setPedManagerPassword(settings.pedManagerPassword || '');
      setDirectorName(settings.directorName || '');
      setDirectorPhone(settings.directorPhone || '');
      setDirectorEmail(settings.directorEmail || '');
      setSurveillantName(settings.surveillantName || '');
      setSurveillantPhone(settings.surveillantPhone || '');
      setCenseurName(settings.censeurName || '');
      setCenseurPhone(settings.censeurPhone || '');
      if (settings.classTeachers && settings.classTeachers.length > 0) {
        const defaultClassrooms = [
          { classRoom: '6ème', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: '5ème', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: '4ème ALL', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: '4ème ESP', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: '3ème ALL', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: '3ème ESP', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: '2nde', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: '1ère', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: 'Tle', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: 'CM2-A', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: 'CE2-B', teacherName: '', teacherPhone: '', teacherEmail: '' },
          { classRoom: 'CM1-A', teacherName: '', teacherPhone: '', teacherEmail: '' },
        ];
        const savedMapped = settings.classTeachers.map(s => ({
          classRoom: s.classRoom,
          teacherName: s.teacherName || '',
          teacherPhone: s.teacherPhone || '',
          teacherEmail: s.teacherEmail || '',
        }));
        const missingPredefined = defaultClassrooms.filter(d => !settings.classTeachers!.some(s => s.classRoom === d.classRoom));
        setClassTeachers([...savedMapped, ...missingPredefined]);
      }
      if (settings.classSubjects && settings.classSubjects.length > 0) {
        setClassSubjects(settings.classSubjects);
      }
      
      const pCfg = settings.paymentConfig;
      setCardEnabled(pCfg?.cardEnabled ?? false);
      setStripePublicKey(pCfg?.stripePublicKey || '');
      setStripeSecretKey(pCfg?.stripeSecretKey || '');
      setMtnEnabled(pCfg?.mtnEnabled ?? false);
      setMtnPhoneNumber(pCfg?.mtnPhoneNumber || '');
      setMtnMerchantName(pCfg?.mtnMerchantName || '');
      setMtnClientId(pCfg?.mtnClientId || '');
      setMtnClientSecret(pCfg?.mtnClientSecret || '');
      setOrangeEnabled(pCfg?.orangeEnabled ?? false);
      setOrangePhoneNumber(pCfg?.orangePhoneNumber || '');
      setOrangeMerchantName(pCfg?.orangeMerchantName || '');
      setOrangeMerchantKey(pCfg?.orangeMerchantKey || '');
      setOrangeClientId(pCfg?.orangeClientId || '');
      setOrangeClientSecret(pCfg?.orangeClientSecret || '');
      setWaveEnabled(pCfg?.waveEnabled ?? false);
      setWavePhoneNumber(pCfg?.wavePhoneNumber || '');
      setWaveMerchantName(pCfg?.waveMerchantName || '');
      setWaveApiKey(pCfg?.waveApiKey || '');
      setSyncIntervalSeconds(settings.syncIntervalSeconds || 30);
    }
  }, [settings]);

  // Budget lines states
  const [editingLineId, setEditingLineId] = useState<string | null>(null);
  const [lineName, setLineName] = useState('');
  const [lineAmount, setLineAmount] = useState<number>(0);
  const [lineDescription, setLineDescription] = useState('');
  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);

  // Deletion confirmation state
  const [lineToDelete, setLineToDelete] = useState<{ id: string; name: string } | null>(null);
  const [classToDeleteIdx, setClassToDeleteIdx] = useState<number | null>(null);
  const [classToDeleteRoom, setClassToDeleteRoom] = useState<string>('');

  // Success indicators
  const [newClassName, setNewClassName] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('Paramètres enregistrés avec succès !');

  const handleSaveWithExtra = async (extra: Partial<ApeeSettings> = {}, successMsg = "Paramètres enregistrés avec succès !") => {
    try {
      const result = await onSaveSettings({
        associationName: (associationName || '').trim(),
        shortName: (shortName || '').trim(),
        schoolYear: (schoolYear || '').trim(),
        cotisationAmount: totalObligationsPerStudent,
        financialGoal: calculatedFinancialGoal,
        budgetLines: settings.budgetLines || [],
        finManagerName: (finManagerName || '').trim(),
        finManagerPhone: (finManagerPhone || '').trim(),
        finManagerPassword: (finManagerPassword || '').trim(),
        pedManagerName: (pedManagerName || '').trim(),
        pedManagerPhone: (pedManagerPhone || '').trim(),
        pedManagerPassword: (pedManagerPassword || '').trim(),
        logoUrl: logoUrl || '',
        directorName: (directorName || '').trim(),
        directorPhone: (directorPhone || '').trim(),
        directorEmail: (directorEmail || '').trim(),
        surveillantName: (surveillantName || '').trim(),
        surveillantPhone: (surveillantPhone || '').trim(),
        censeurName: (censeurName || '').trim(),
        censeurPhone: (censeurPhone || '').trim(),
        classTeachers: classTeachers || [],
        classSubjects: extra.classSubjects !== undefined ? extra.classSubjects : (classSubjects || []),
        honoraryContributions: honoraryContributions || 0,
        subventionsAndAids: subventionsAndAids || 0,
        actualHonoraryContributions: actualHonoraryContributions || 0,
        actualSubventionsAndAids: actualSubventionsAndAids || 0,
        expectedStudents: expectedStudents || 100,
        country,
        currency,
        financialObligations,
        syncIntervalSeconds,
        paymentConfig: {
          cardEnabled,
          stripePublicKey: (stripePublicKey || '').trim(),
          stripeSecretKey: (stripeSecretKey || '').trim(),
          mtnEnabled,
          mtnPhoneNumber: (mtnPhoneNumber || '').trim(),
          mtnMerchantName: (mtnMerchantName || '').trim(),
          mtnClientId: (mtnClientId || '').trim(),
          mtnClientSecret: (mtnClientSecret || '').trim(),
          orangeEnabled,
          orangePhoneNumber: (orangePhoneNumber || '').trim(),
          orangeMerchantName: (orangeMerchantName || '').trim(),
          orangeMerchantKey: (orangeMerchantKey || '').trim(),
          orangeClientId: (orangeClientId || '').trim(),
          orangeClientSecret: (orangeClientSecret || '').trim(),
          waveEnabled,
          wavePhoneNumber: (wavePhoneNumber || '').trim(),
          waveMerchantName: (waveMerchantName || '').trim(),
          waveApiKey: (waveApiKey || '').trim(),
          
          campayEnabled: settings.paymentConfig?.campayEnabled,
          campayAppId: settings.paymentConfig?.campayAppId,
          campayAppUsername: settings.paymentConfig?.campayAppUsername,
          campayAppPassword: settings.paymentConfig?.campayAppPassword,
          campayToken: settings.paymentConfig?.campayToken,
          campayWebhookKey: settings.paymentConfig?.campayWebhookKey,
        },
        smsConfig: settings.smsConfig,
        ...extra
      });

      if (result !== false) {
        setSuccessMessage(successMsg);
        setShowSuccess(true);
        setTimeout(() => {
          setShowSuccess(false);
        }, 3500);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!(associationName || '').trim() || !(schoolYear || '').trim() || calculatedFinancialGoal <= 0) {
      alert(language === 'en' ? "Please fill in all mandatory fields correctly." : "Veuillez renseigner correctement l'ensemble des champs obligatoires.");
      return;
    }

    handleSaveWithExtra({}, language === 'en' ? "General administrative configurations saved successfully!" : "Paramètres généraux d'administration sauvegardés avec succès !");
  };

  const handleSaveBudgetLine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lineName.trim() || lineAmount <= 0) {
      alert("Veuillez saisir un libellé valide et un montant alloué supérieur à 0.");
      return;
    }

    const currentLines = settings.budgetLines || [];
    let updatedLines = [...currentLines];

    if (editingLineId) {
      updatedLines = updatedLines.map(l => 
        l.id === editingLineId 
          ? { id: l.id, name: lineName.trim(), allocatedAmount: lineAmount, description: lineDescription.trim() || undefined }
          : l
      );
      setSuccessMessage("Ligne budgétaire modifiée avec succès.");
    } else {
      const newLine: ApeeBudgetLine = {
        id: 'bl_' + Date.now(),
        name: lineName.trim(),
        allocatedAmount: lineAmount,
        description: lineDescription.trim() || undefined
      };
      updatedLines.push(newLine);
      setSuccessMessage("Nouvelle ligne budgétaire enregistrée.");
    }

    handleSaveWithExtra({ budgetLines: updatedLines });

    // Reset budget form and close modal
    setEditingLineId(null);
    setLineName('');
    setLineAmount(0);
    setLineDescription('');
    setIsBudgetModalOpen(false);

    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3500);
  };

  const handleStartEditLine = (line: ApeeBudgetLine) => {
    setEditingLineId(line.id);
    setLineName(line.name);
    setLineAmount(line.allocatedAmount);
    setLineDescription(line.description || '');
    setIsBudgetModalOpen(true);
  };

  const handleCancelEditLine = () => {
    setEditingLineId(null);
    setLineName('');
    setLineAmount(0);
    setLineDescription('');
    setIsBudgetModalOpen(false);
  };

  const handleDeleteLine = (id: string, name: string) => {
    setLineToDelete({ id, name });
  };

  const handleConfirmDeleteLine = () => {
    if (!lineToDelete) return;
    const { id } = lineToDelete;
    const currentLines = settings.budgetLines || [];
    const updatedLines = currentLines.filter(l => l.id !== id);

    handleSaveWithExtra({ budgetLines: updatedLines });

    setSuccessMessage("Ligne budgétaire supprimée de la planification annuelle.");
    setShowSuccess(true);
    setLineToDelete(null);
    setTimeout(() => setShowSuccess(false), 3500);
  };

  const handleConfirmDeleteClass = () => {
    if (classToDeleteIdx === null) return;
    setClassTeachers(classTeachers.filter((_, idxFilter) => idxFilter !== classToDeleteIdx));
    setClassToDeleteIdx(null);
    setClassToDeleteRoom('');
  };

  // Calculations for budget consumption status
  const budgetLinesList = settings.budgetLines || [];
  const totalAllocated = budgetLinesList.reduce((acc, curr) => acc + curr.allocatedAmount, 0);
  const percentAllocated = Math.min(100, Math.round((totalAllocated / calculatedFinancialGoal) * 100)) || 0;

  return (
    <div id="content_apee_settings" className="space-y-6">

      <div className="border-b border-slate-150 pb-4">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">⚙️ {t('set.title')}</h2>
        <p className="text-xs text-gray-500 font-medium">
          {t('set.subtitle')}
        </p>
      </div>

      {showSuccess && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs px-4 py-3 rounded-xl flex items-center gap-2 font-semibold animate-fade-in">
          <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left column: main config form */}
        <form onSubmit={handleSubmit} className="lg:col-span-7 bg-white border border-slate-150 rounded-2xl p-4 md:p-5 space-y-4">
          <div className="border-b pb-2 text-xs font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide border-slate-100 select-none">
            <Settings className="h-4 w-4 text-indigo-500 animate-spin" style={{ animationDuration: '6s' }} /> Configuration Administrative et Tarifaire
          </div>

          <div className="space-y-4">
            
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-600 uppercase">Nom Officiel de l'Institution <span className="text-red-500">*</span></label>
              <input
                type="text"
                required
                value={associationName}
                onChange={(e) => setAssociationName(e.target.value)}
                placeholder="Ex: APEE CES d'Ekali 1 - MFOU"
                className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-505 font-medium"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-600 uppercase">Nom Court de l'Institution</label>
              <input
                type="text"
                value={shortName}
                onChange={(e) => setShortName(e.target.value.substring(0, 15))}
                maxLength={15}
                placeholder="Ex: APEE"
                className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-505 font-medium"
              />
              <p className="text-[9.5px] text-slate-450 italic">Nom abrégé réduit (max. 15 lettres - e.g. APEE, AGE, etc.). Si non spécifié, il sera auto-généré à partir du nom officiel.</p>
            </div>

            {/* Logo de l'établissement */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-600 uppercase block">Logo de l'Établissement (Visuel En-tête)</label>
              <div className="flex gap-3 items-center bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="h-14 w-14 bg-white rounded-lg border-2 border-dashed border-slate-300 flex items-center justify-center shrink-0 overflow-hidden relative shadow-3xs text-center">
                  {logoUrl ? (
                    <>
                      <img src={logoUrl} alt="Logo" className="h-full w-full object-contain p-0.5" referrerPolicy="no-referrer" />
                      <button
                        type="button"
                        onClick={() => setLogoUrl('')}
                        className="absolute top-0 right-0 p-0.5 bg-red-150 hover:bg-red-250 text-red-700 rounded-bl-lg cursor-pointer transition shadow-4xs"
                        title="Supprimer le logo (Rétablir le logo par défaut)"
                      >
                        <X className="h-2.5 w-2.5 shrink-0" />
                      </button>
                    </>
                  ) : (
                    <div className="h-full w-full relative flex flex-col items-center justify-center p-0.5 bg-slate-50">
                      <img src={DEFAULT_SCHOOL_LOGO} alt="Logo par défaut" className="h-full w-full object-contain rounded-md" referrerPolicy="no-referrer" />
                      <span className="absolute bottom-0 inset-x-0 text-[7px] font-black uppercase text-indigo-900 bg-white/90 backdrop-blur-xs py-0.5 text-center border-t border-slate-200">Par défaut</span>
                    </div>
                  )}
                </div>
                <div className="flex-1 space-y-1.5">
                  <div className="relative overflow-hidden inline-block bg-white hover:bg-slate-50 transition border border-slate-350 px-3 py-1 rounded-lg text-[10px] font-black text-slate-800 cursor-pointer">
                    Télécharger une image...
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          if (file.size > 1 * 1024 * 1024) {
                            alert("🔴 Image trop volumineuse. Veuillez choisir un fichier de moins de 1 Mo.");
                            return;
                          }
                          const reader = new FileReader();
                          reader.onload = () => {
                            setLogoUrl(reader.result as string);
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                      className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                    />
                  </div>
                  <p className="text-[9px] text-slate-400 font-medium">Se synchronise instantanément avec la barre d'en-tête globale.</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase block">Pays de l'Établissement <span className="text-red-500">*</span></label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-550 font-medium"
                >
                  <option value="Cameroun">🇨🇲 Cameroun</option>
                  <option value="Sénégal">🇸🇳 Sénégal</option>
                  <option value="Côte d'Ivoire">🇨🇮 Côte d'Ivoire</option>
                  <option value="Burkina Faso">🇧🇫 Burkina Faso</option>
                  <option value="Niger">🇳🇪 Niger</option>
                  <option value="Bénin">🇧🇯 Bénin</option>
                  <option value="Togo">🇹🇬 Togo</option>
                  <option value="Mali">🇲🇱 Mali</option>
                  <option value="Gabon">🇬🇦 Gabon</option>
                  <option value="Congo">🇨🇬 Congo-Brazzaville</option>
                  <option value="RDC">🇨🇩 RDC Congo</option>
                  <option value="Tchad">🇹🇩 Tchad</option>
                  <option value="Guinée">🇬🇳 Guinée</option>
                  <option value="Centrafrique">🇨🇫 Centrafrique</option>
                  <option value="France">🇫🇷 France (Europe)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase block">Devise / Monnaie <span className="text-red-500">*</span></label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-550 font-bold font-mono"
                >
                  <option value="FCFA">FCFA (XAF / XOF)</option>
                  <option value="EUR">Euro (€)</option>
                  <option value="USD">Dollar US ($)</option>
                  <option value="GNF">Franc Guinéen (GNF)</option>
                  <option value="CDF">Franc Congolais (CDF)</option>
                  <option value="CAD">Dollar Canadien (C$)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase block">Année Scolaire Active <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  required
                  value={schoolYear}
                  onChange={(e) => setSchoolYear(e.target.value)}
                  placeholder="Ex: 2025/2026"
                  className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-550 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase block">Nombre d'Élèves Attendus <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  min="1"
                  required
                  value={expectedStudents || ''}
                  onChange={(e) => setExpectedStudents(Number(e.target.value))}
                  placeholder="Ex: 100"
                  className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-550 font-mono text-right"
                />
              </div>
            </div>

            {/* Rubriques d'Obligations Financières */}
            <div className="border border-indigo-100 bg-indigo-50/20 rounded-xl p-3 space-y-3">
              <div className="flex justify-between items-center border-b border-indigo-100 pb-1.5">
                <div>
                  <h4 className="text-[11px] font-black text-indigo-950 uppercase tracking-wider flex items-center gap-1.5">
                    💳 Obligations Financières de l'Établissement
                  </h4>
                  <p className="text-[9px] text-slate-500 font-medium leading-relaxed">
                    Définir et lister toutes les obligations exigibles par parent ou par élève.
                  </p>
                </div>
              </div>

              {/* Obligations list */}
              {financialObligations.length === 0 ? (
                <div className="text-center py-4 bg-white border border-dashed border-slate-205 text-slate-400 text-[10px] rounded-lg">
                  Aucune obligation active. Veuillez en configurer une ci-dessous.
                </div>
              ) : (
                <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1">
                  {financialObligations.map((obl: any) => (
                    <div key={obl.id} className="bg-white border text-[11px] rounded-lg p-2 flex justify-between items-center shadow-3xs hover:bg-slate-50 transition">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-slate-800">{obl.name}</span>
                          <span className={`px-1.5 py-0.2 text-[8px] font-black rounded-full uppercase tracking-wider ${obl.type === 'per_student' ? 'bg-blue-50 text-blue-600 border border-blue-105' : 'bg-emerald-55 text-emerald-600 border border-emerald-105'}`}>
                            {obl.type === 'per_student' ? 'Par élève' : 'Par parent'}
                          </span>
                        </div>
                        {obl.description && <p className="text-[9.5px] text-slate-400 font-medium leading-tight">{obl.description}</p>}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="font-mono font-bold text-slate-700 bg-slate-50 border px-2 py-0.5 rounded text-[11px]">
                          {obl.amount.toLocaleString()} {currency}
                        </span>
                        <div className="flex shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingOblId(obl.id);
                              setNewOblName(obl.name);
                              setNewOblAmount(obl.amount);
                              setNewOblType(obl.type);
                              setNewOblDesc(obl.description || '');
                            }}
                            className="p-1 hover:text-indigo-600 text-slate-400 rounded transition cursor-pointer"
                            title="Modifier"
                          >
                            <Edit2 className="h-3 w-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const updated = financialObligations.filter((o: any) => o.id !== obl.id);
                              setFinancialObligations(updated);
                            }}
                            className="p-1 hover:text-red-700 text-slate-400 rounded transition cursor-pointer"
                            title="Supprimer"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Add / Edit Inline Section */}
              <div className="bg-white border border-indigo-100 rounded-xl p-2.5 space-y-2.5 shadow-2xs">
                <span className="text-[10px] font-black text-indigo-750 uppercase tracking-wide block">
                  {editingOblId ? '✏️ Modifier l\'obligation' : '➕ Ajouter une Obligation Financière (Frais d\'inscription, pension, transport, cantine...)'}
                </span>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-0.5 col-span-2 sm:col-span-1">
                    <label className="text-[8.5px] font-bold text-slate-500 uppercase block">Intitulé de l'obligation</label>
                    <input
                      type="text"
                      placeholder="Ex: Frais d'inscription, Scolarité..."
                      value={newOblName}
                      onChange={(e) => setNewOblName(e.target.value)}
                      className="w-full px-2 py-1 text-xs border rounded-lg focus:outline-indigo-500 font-medium"
                    />
                  </div>

                  <div className="space-y-0.5 col-span-2 sm:col-span-1">
                    <label className="text-[8.5px] font-bold text-slate-500 uppercase block">Montant ({currency})</label>
                    <input
                      type="number"
                      placeholder="Montant"
                      value={newOblAmount || ''}
                      onChange={(e) => setNewOblAmount(Number(e.target.value))}
                      className="w-full px-2 py-1 text-xs border rounded-lg focus:outline-indigo-500 font-mono text-right font-semibold"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-0.5 col-span-2 sm:col-span-1">
                    <label className="text-[8.5px] font-bold text-slate-500 uppercase block">Type d'Application</label>
                    <select
                      value={newOblType}
                      onChange={(e) => setNewOblType(e.target.value as 'per_student' | 'per_parent')}
                      className="w-full px-2 py-1 text-xs border rounded-lg focus:outline-indigo-505 font-bold text-slate-750"
                    >
                      <option value="per_student">Par élève inscrit (Dû × nb élèves)</option>
                      <option value="per_parent">Par foyer parent (Frais fixe unique)</option>
                    </select>
                  </div>

                  <div className="space-y-0.5 col-span-2 sm:col-span-1">
                    <label className="text-[8.5px] font-bold text-slate-500 uppercase block">Description / Notes</label>
                    <input
                      type="text"
                      placeholder="Ex: Frais annuels obligatoires"
                      value={newOblDesc}
                      onChange={(e) => setNewOblDesc(e.target.value)}
                      className="w-full px-2 py-1 text-xs border rounded-lg focus:outline-indigo-500 font-medium"
                    />
                  </div>
                </div>

                <div className="flex gap-2 justify-end pt-1">
                  {editingOblId && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingOblId(null);
                        setNewOblName('');
                        setNewOblAmount(0);
                        setNewOblType('per_student');
                        setNewOblDesc('');
                      }}
                      className="px-2.5 py-1 text-[9.5px] font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded transition cursor-pointer"
                    >
                      Annuler
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      if (!newOblName.trim()) {
                        alert("🔴 L'intitulé est requis");
                        return;
                      }
                      if (newOblAmount <= 0) {
                        alert("🔴 Le montant doit être supérieur à 0");
                        return;
                      }

                      if (editingOblId) {
                        setFinancialObligations((prev: any) => prev.map((o: any) => o.id === editingOblId ? {
                          ...o,
                          name: newOblName.trim(),
                          amount: newOblAmount,
                          type: newOblType,
                          description: newOblDesc.trim() || undefined
                        } : o));
                        setEditingOblId(null);
                      } else {
                        const newObl = {
                          id: `obl_${Date.now()}`,
                          name: newOblName.trim(),
                          amount: newOblAmount,
                          type: newOblType,
                          description: newOblDesc.trim() || undefined
                        };
                        setFinancialObligations((prev: any) => [...prev, newObl]);
                      }

                      setNewOblName('');
                      setNewOblAmount(0);
                      setNewOblType('per_student');
                      setNewOblDesc('');
                    }}
                    className="px-3 py-1 text-[9.5px] font-extrabold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition cursor-pointer flex items-center gap-1.5"
                  >
                    {editingOblId ? 'Valider modification' : 'Enregistrer cette obligation'}
                  </button>
                </div>
              </div>
            </div>

            {/* SECTION: Calculated Annual Budget Goal Breakdowns */}
            <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-4.5 space-y-3 shadow-3xs">
              <span className="text-[10px] text-indigo-950 font-extrabold uppercase tracking-wider block">
                📐 Synthèse & Total du Budget Prévisionnel (Objectif)
              </span>
              
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center bg-white/70 px-3 py-2 rounded-xl border border-indigo-100/40">
                  <span className="text-slate-600 font-bold">1. Cotisations attendues des parents :</span>
                  <div className="text-right">
                    <span className="font-mono font-bold text-slate-800 block">{parentCotisations.toLocaleString()} {currency}</span>
                    <span className="text-[9.5px] text-indigo-600 font-bold block">
                      ({expectedStudents} élèves × {totalObligationsPerStudent.toLocaleString()} {currency} + per-parent {totalObligationsPerParent.toLocaleString()} {currency})
                    </span>
                  </div>
                </div>
                
                <div className="flex justify-between items-center bg-white/70 px-3 py-2 rounded-xl border border-indigo-100/40">
                  <span className="text-slate-600 font-bold">2. Contributions des membres d'honneur :</span>
                  <span className="font-mono font-bold text-slate-800">{honoraryContributions.toLocaleString()} {currency}</span>
                </div>
                
                <div className="flex justify-between items-center bg-white/70 px-3 py-2 rounded-xl border border-indigo-100/40">
                  <span className="text-slate-600 font-bold">3. Subventions & autres aides (A.D.S) :</span>
                  <span className="font-mono font-bold text-slate-800">{subventionsAndAids.toLocaleString()} {currency}</span>
                </div>
                
                <div className="border-t border-indigo-200/60 my-2 pt-2 flex justify-between items-center">
                  <span className="text-indigo-950 font-black uppercase text-[10px]">Total du Budget Prévisionnel :</span>
                  <span className="font-mono font-black text-sm text-indigo-700">{calculatedFinancialGoal.toLocaleString()} {currency}</span>
                </div>
              </div>
              <p className="text-[8.5px] text-indigo-700/80 leading-normal font-medium">
                * Note : Ce montant prévisionnel total sert de base de calcul pour les jauges de recouvrement, les statistiques et le découpage de vos lignes d'allocations de dépenses. Le budget est équilibré en recettes et en dépenses à {calculatedFinancialGoal.toLocaleString()} {currency}.
              </p>
            </div>

            {/* Other Revenue streams */}
            <div className="border-t border-slate-100 pt-4 mt-4 space-y-4">
              <div className="flex items-center gap-2 select-none">
                <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wider block">1. Autres Sources de Recettes (Prévues/Budget)</span>
                <span className="h-px bg-slate-100 flex-1" />
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-600 uppercase">Contributions Membres d'Honneur ({currency})</label>
                  <input
                    type="number"
                    min="0"
                    value={honoraryContributions || ''}
                    onChange={(e) => setHonoraryContributions(Number(e.target.value))}
                    placeholder="Ex: 500000"
                    className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-550 font-mono text-right"
                  />
                  <p className="text-[8.5px] text-gray-400 leading-tight">Contributions financières prévues pour les parents d'honneur et conseillers.</p>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-600 uppercase">Aides, Dons et Subventions ({currency})</label>
                  <input
                    type="number"
                    min="0"
                    value={subventionsAndAids || ''}
                    onChange={(e) => setSubventionsAndAids(Number(e.target.value))}
                    placeholder="Ex: 1000000"
                    className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-550 font-mono text-right"
                  />
                  <p className="text-[8.5px] text-gray-400 leading-tight">Subventions ministérielles ou dons de municipalités prévus.</p>
                </div>

              </div>
            </div>

            {/* Sync interval configurations */}
            <div className="border-t border-slate-100 pt-4 mt-4 space-y-3">
              <div className="flex items-center gap-2 select-none">
                <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wider block">2. Fréquence de Synchronisation / Sync Interval</span>
                <span className="h-px bg-slate-100 flex-1" />
              </div>
              
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase block">Intervalle de mise à jour des données (Poll Interval)</label>
                <select
                  value={syncIntervalSeconds}
                  onChange={(e) => setSyncIntervalSeconds(Number(e.target.value))}
                  className="w-full px-3 py-1.5 text-xs border rounded-lg focus:outline-indigo-550 font-bold font-mono text-slate-750"
                >
                  <option value={10}>10 secondes (Ultra-rapide)</option>
                  <option value={30}>30 secondes (Défaut / Default)</option>
                  <option value={60}>1 minute</option>
                  <option value={120}>2 minutes</option>
                  <option value={300}>5 minutes</option>
                  <option value={600}>10 minutes</option>
                  <option value={900}>15 minutes</option>
                  <option value={1800}>30 minutes</option>
                </select>
                <p className="text-[8.5px] text-gray-400 leading-tight">
                  {language === 'en' 
                    ? "Defines how often the application requests and synchronizes school updates (grades, homework, billing, etc.) in the background."
                    : "Définit la fréquence à laquelle l'application interroge le serveur et synchronise les notes, devoirs, factures et nouveautés en arrière-plan."
                  }
                </p>
              </div>
            </div>

            {/* Language Selector in Settings */}
            <div className="border-t border-slate-100 pt-4 mt-4 space-y-3">
              <div className="flex items-center gap-2 select-none">
                <span className="text-[11px] font-bold text-slate-800 uppercase tracking-wider block">3. Langue d'Affichage / Display Language</span>
                <span className="h-px bg-slate-100 flex-1" />
              </div>
              
              <div className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-xl p-3">
                <div className="space-y-0.5">
                  <div className="text-xs font-black text-slate-800">
                    {t('header.select_lang')} / Multilingual Mode
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Sélecteur instantané : Français, English, Español, Deutsch
                  </div>
                </div>

                <LanguageSelector />
              </div>
            </div>

          </div>

          <button
            type="submit"
            className="w-full mt-2 py-2.5 bg-slate-900 border border-slate-800 hover:border-black hover:bg-black text-white rounded-xl text-xs font-bold uppercase tracking-wide flex items-center justify-center gap-1.5 cursor-pointer transition shadow-2xs"
          >
            <Save className="h-4 w-4 text-emerald-400" /> Enregistrer les Configurations
          </button>
        </form>

        {/* Right column: help notes & Financial Manager Profile */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-50 border border-slate-150 rounded-2xl p-4.5 space-y-4 ">
            <h3 className="text-xs font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wide border-b pb-2">
              <Info className="h-4 w-4 text-sky-500" /> Planification Budgétaire
            </h3>

            <div className="text-xs text-gray-500 space-y-3 leading-relaxed font-normal">
              <p>
                Les cotisations scolaires APEE sont capitalisées à hauteur de la prévision globale. Il est conseillé de répartir cet objectif en **lignes budgétaires** strictes pour chaque type de dépenses (Didactique, Réparations, Fonctionnement COGE).
              </p>
              <p>
                En liant chaque dépense saisie sous <strong>Régie Financière</strong> à sa ligne budgétaire associée, le système calcule automatiquement les <strong>taux de consommation budgétaire</strong> en temps réel.
              </p>
              <hr className="border-slate-200" />
              <div className="bg-sky-50 text-sky-900 p-3 rounded-lg flex gap-2 items-start text-[10px]">
                <Shield className="h-4 w-4 shrink-0 text-sky-600 mt-0.5" />
                <div>
                  <strong>Allocation d'Enveloppe :</strong>
                  <p className="mt-1">Veillez à ce que la somme des montants alloués ne dépasse pas l'objectif budgétaire prévisionnel pour conserver l'équilibre financier de l'école.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-150 rounded-2xl p-4.5 space-y-4 shadow-3xs">
            <h3 className="text-xs font-bold text-slate-850 flex items-center gap-1.5 uppercase tracking-wide border-b pb-2 select-none">
              <Shield className="h-4 w-4 text-indigo-500" /> Responsable Financier & Restreindre
            </h3>

            <div className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase">Nom Complet <span className="text-red-500">*</span></label>
                <div className="relative">
                  <span className="absolute left-2.5 top-2 text-slate-400">👤</span>
                  <input
                    type="text"
                    required
                    value={finManagerName}
                    onChange={(e) => setFinManagerName(e.target.value)}
                    placeholder="Ex: M. Jean-Pierre Atangana"
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-indigo-500 font-medium text-slate-800"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase">Téléphone <span className="text-red-500">*</span></label>
                <div className="relative">
                  <span className="absolute left-2.5 top-2 text-slate-400">📞</span>
                  <input
                    type="text"
                    required
                    value={finManagerPhone}
                    onChange={(e) => setFinManagerPhone(e.target.value)}
                    placeholder="Ex: +237 6xx xx xx xx"
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-indigo-500 font-mono text-slate-800"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase">Mot de passe de contrôle <span className="text-red-500">*</span></label>
                <div className="relative">
                  <span className="absolute left-2.5 top-2 text-slate-400">🔑</span>
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={finManagerPassword}
                    onChange={(e) => setFinManagerPassword(e.target.value)}
                    placeholder="Saisir un mot de passe vigile"
                    className="w-full pl-8 pr-12 py-1.5 text-xs bg-slate-50 border border-slate-250 rounded-lg focus:outline-indigo-500 font-mono text-slate-800 font-bold"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-1.5 text-[9px] text-gray-500 hover:text-indigo-650 cursor-pointer p-0.5 font-bold uppercase"
                  >
                    {showPassword ? "Masquer" : "Afficher"}
                  </button>
                </div>
              </div>

              {/* Status Indicator */}
              <div className={`p-3 rounded-xl flex gap-2.5 items-start text-[10px] border leading-normal ${
                finManagerPassword ? 'bg-emerald-50 text-emerald-950 border-emerald-250' : 'bg-amber-50 text-amber-950 border-amber-250'
              }`}>
                {finManagerPassword ? (
                  <>
                    <Lock className="h-4 w-4 shrink-0 text-emerald-600 mt-0.5" />
                    <div>
                      <strong>Contrôle d'accès actif (Verrouillé)</strong>
                      <p className="mt-1 font-normal text-slate-600">
                        La création ou suppression des parents, reçus et dépenses exigera le mot de passe de {finManagerName || "M. le Responsable"}.
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <Unlock className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
                    <div>
                      <strong>Sécurité désactivée</strong>
                      <p className="mt-1 font-normal text-slate-600">
                        Aucun vigile configuré. N'importe quel utilisateur connecté peut librement ajouter et supprimer des données dans l'espace APEE.
                      </p>
                    </div>
                  </>
                )}
              </div>

              <button
                type="button"
                onClick={() => {
                  if (!finManagerName.trim() || !finManagerPhone.trim() || !finManagerPassword.trim()) {
                    alert("Veuillez renseigner tous les champs du Responsable Financier (Nom, Téléphone et Mot de passe).");
                    return;
                  }
                  handleSaveWithExtra({
                    finManagerName: finManagerName.trim(),
                    finManagerPhone: finManagerPhone.trim(),
                    finManagerPassword: finManagerPassword.trim(),
                  }, "Accès du Responsable Financier enregistrés avec succès !");
                }}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold uppercase tracking-wide flex items-center justify-center gap-1 cursor-pointer transition shadow-2xs"
              >
                <UserCheck className="h-4 w-4" /> Sauvegarder les accès
              </button>
            </div>
          </div>

          {/* Pedagogical Manager Profile */}
          <div className="bg-white border border-slate-150 rounded-2xl p-4.5 space-y-4 shadow-3xs">
            <h3 className="text-xs font-bold text-slate-850 flex items-center gap-1.5 uppercase tracking-wide border-b pb-2 select-none">
              <Shield className="h-4 w-4 text-emerald-500" /> Responsable Pédagogique & Administratif
            </h3>

            <div className="space-y-3.5 text-xs">
              <p className="text-[10px] text-slate-500 leading-normal">
                Configurez l'autorité pédagogique officielle (Censeur ou Surveillant Général) seule habilitée à introduire et modifier les informations de scolarité (bulletins, notes, assiduité, devoirs et communiqués).
              </p>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase">Nom Complet (Censeur / SG) <span className="text-red-500">*</span></label>
                <div className="relative">
                  <span className="absolute left-2.5 top-2 text-slate-400">👤</span>
                  <input
                    type="text"
                    required
                    value={pedManagerName}
                    onChange={(e) => setPedManagerName(e.target.value)}
                    placeholder="Ex: M. François Bidzogo (Censeur)"
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-emerald-500 font-medium text-slate-800"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase">Téléphone <span className="text-red-500">*</span></label>
                <div className="relative">
                  <span className="absolute left-2.5 top-2 text-slate-400">📞</span>
                  <input
                    type="text"
                    required
                    value={pedManagerPhone}
                    onChange={(e) => setPedManagerPhone(e.target.value)}
                    placeholder="Ex: +237 6xx xx xx xx"
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-emerald-500 font-mono text-slate-800"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-600 uppercase">Mot de Passe Vigile <span className="text-red-500">*</span></label>
                <div className="relative">
                  <span className="absolute left-2.5 top-2 text-slate-400">🔑</span>
                  <input
                    type={showPedPassword ? "text" : "password"}
                    required
                    value={pedManagerPassword}
                    onChange={(e) => setPedManagerPassword(e.target.value)}
                    placeholder="Mot de passe d'administration académique"
                    className="w-full pl-8 pr-12 py-1.5 text-xs bg-slate-50 border border-slate-250 rounded-lg focus:outline-emerald-500 font-mono text-slate-800 font-bold"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPedPassword(!showPedPassword)}
                    className="absolute right-2.5 top-1.5 text-[9px] text-gray-500 hover:text-emerald-650 cursor-pointer p-0.5 font-bold uppercase select-none"
                  >
                    {showPedPassword ? "Masquer" : "Afficher"}
                  </button>
                </div>
              </div>

              {/* Status Indicator */}
              <div className={`p-3 rounded-xl flex gap-2.5 items-start text-[10px] border leading-normal ${
                pedManagerPassword ? 'bg-emerald-50 text-emerald-950 border-emerald-250' : 'bg-amber-50 text-amber-950 border-amber-250'
              }`}>
                {pedManagerPassword ? (
                  <>
                    <Lock className="h-4 w-4 shrink-0 text-emerald-600 mt-0.5" />
                    <div>
                      <strong>Contrôle académique strict activé</strong>
                      <p className="mt-1 font-normal text-slate-600">
                        La modification des notes, devoirs, fiches d'assiduité et publication d'actualités exige le mot de passe de {pedManagerName || "l'autorité pédagogique"}.
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <Unlock className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
                    <div>
                      <strong>Accès libre (Saisie non sécurisée)</strong>
                      <p className="mt-1 font-normal text-slate-600">
                        Aucun responsable académique enregistré. N'importe quel visiteur connecté de l'ENT peut introduire et réinitialiser les données scolaires.
                      </p>
                    </div>
                  </>
                )}
              </div>

              <button
                type="button"
                onClick={() => {
                  if (!pedManagerName.trim() || !pedManagerPhone.trim() || !pedManagerPassword.trim()) {
                    alert("Veuillez renseigner tous les champs du Responsable Pédagogique (Nom, Téléphone et Mot de passe).");
                    return;
                  }
                  handleSaveWithExtra({
                    pedManagerName: pedManagerName.trim(),
                    pedManagerPhone: pedManagerPhone.trim(),
                    pedManagerPassword: pedManagerPassword.trim(),
                  }, "Accès du Responsable Pédagogique enregistrés avec succès !");
                }}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wide flex items-center justify-center gap-1 cursor-pointer transition shadow-2xs"
              >
                <UserCheck className="h-4 w-4" /> Sauvegarder les accès scolaires
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* SECTION: School Administrators and Class Titular Teachers */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        {/* Card 1: Principal Administrators */}
        <div className="xl:col-span-5 bg-white border border-slate-150 rounded-2xl p-4 md:p-5 space-y-4 shadow-3xs">
          <div className="border-b pb-2 select-none">
            <h3 className="text-xs font-bold text-slate-850 flex items-center gap-1.5 uppercase tracking-wide">
              <GraduationCap className="h-4 w-4 text-indigo-500" /> Responsibles d'Établissement
            </h3>
            <p className="text-[10px] text-gray-400 mt-0.5">Saisir les contacts officiels de l'administration scolaire.</p>
          </div>

          <div className="space-y-4.5 text-xs">
            {/* Directeur */}
            <div className="p-3 bg-slate-50/50 border border-slate-100 rounded-xl space-y-2.5">
              <span className="font-bold text-slate-800 text-[11px] block">Directorat (Le Directeur)</span>
              <div className="space-y-2">
                <div>
                  <label className="text-[9px] font-bold text-slate-550 uppercase">Nom complet du Directeur</label>
                  <div className="relative mt-0.5">
                    <User className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                    <input
                      type="text"
                      className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white"
                      placeholder="Nom et prénoms du Directeur"
                      value={directorName}
                      onChange={(e) => setDirectorName(e.target.value)}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[9px] font-bold text-slate-550 uppercase">Téléphone</label>
                    <div className="relative mt-0.5">
                      <Phone className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                      <input
                        type="text"
                        className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white"
                        placeholder="Ex: +237 6xx..."
                        value={directorPhone}
                        onChange={(e) => setDirectorPhone(e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-550 uppercase">Email / Contact</label>
                    <div className="relative mt-0.5">
                      <Mail className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                      <input
                        type="text"
                        className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white"
                        placeholder="Ex: secretariat@ecole..."
                        value={directorEmail}
                        onChange={(e) => setDirectorEmail(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Surveillant Général */}
            <div className="p-3 bg-slate-50/50 border border-slate-100 rounded-xl space-y-2.5">
              <span className="font-bold text-slate-800 text-[11px] block">Surveillance Générale (Le Surveillant)</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] font-bold text-slate-550 uppercase">Nom du Surveillant</label>
                  <div className="relative mt-0.5">
                    <User className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                    <input
                      type="text"
                      className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white"
                      placeholder="Nom complet"
                      value={surveillantName}
                      onChange={(e) => setSurveillantName(e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-550 uppercase">Téléphone</label>
                  <div className="relative mt-0.5">
                    <Phone className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                    <input
                      type="text"
                      className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white"
                      placeholder="Numéro de téléphone"
                      value={surveillantPhone}
                      onChange={(e) => setSurveillantPhone(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Censeur */}
            <div className="p-3 bg-slate-50/50 border border-slate-100 rounded-xl space-y-2.5">
              <span className="font-bold text-slate-800 text-[11px] block">Censeur Principal (L'Inspecteur/Censeur)</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] font-bold text-slate-550 uppercase">Nom du Censeur</label>
                  <div className="relative mt-0.5">
                    <User className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                    <input
                      type="text"
                      className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white"
                      placeholder="Nom complet"
                      value={censeurName}
                      onChange={(e) => setCenseurName(e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-550 uppercase">Téléphone</label>
                  <div className="relative mt-0.5">
                    <Phone className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                    <input
                      type="text"
                      className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white"
                      placeholder="Numéro de téléphone"
                      value={censeurPhone}
                      onChange={(e) => setCenseurPhone(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                handleSaveWithExtra({
                  directorName: directorName.trim(),
                  directorPhone: directorPhone.trim(),
                  directorEmail: directorEmail.trim(),
                  surveillantName: surveillantName.trim(),
                  surveillantPhone: surveillantPhone.trim(),
                  censeurName: censeurName.trim(),
                  censeurPhone: censeurPhone.trim(),
                }, "Responsables administratifs enregistrés avec succès !");
              }}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold uppercase tracking-wide flex items-center justify-center gap-1.5 cursor-pointer transition shadow-2xs mt-2"
            >
              <Save className="h-4 w-4" /> Enregistrer les Responsables
            </button>
          </div>
        </div>

        {/* Card 2: Per-Class Titular Teachers */}
        <div className="xl:col-span-7 bg-white border border-slate-150 rounded-2xl p-4 md:p-5 space-y-4 shadow-3xs">
          <div className="border-b pb-2 select-none flex justify-between items-center">
            <div>
              <h3 className="text-xs font-bold text-slate-850 flex items-center gap-1.5 uppercase tracking-wide">
                <UserCheck className="h-4 w-4 text-emerald-500" /> Professeurs Titulaires par Classe
              </h3>
              <p className="text-[10px] text-gray-400 mt-0.5">Associer chaque niveau de classe à un enseignant titulaire attitré.</p>
            </div>
            <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded-full font-bold text-slate-600">
              {classTeachers.length} classes configurées
            </span>
          </div>

          <div className="space-y-4">
            {/* Scrollable teachers inputs list */}
            <div className="max-h-[380px] overflow-y-auto pr-2 divide-y divide-slate-100 space-y-4">
              {classTeachers.map((teach, idx) => (
                <div key={idx} className="pt-4 first:pt-0 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10.5px] font-black bg-indigo-50 border border-indigo-100 text-indigo-700 px-2.5 py-0.5 rounded-lg">
                        {teach.classRoom}
                      </span>
                      <span className="text-[10px] font-semibold text-slate-500 italic">Enseignant Titulaire</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setClassToDeleteIdx(idx);
                        setClassToDeleteRoom(teach.classRoom);
                      }}
                      className="p-1 text-slate-400 hover:text-rose-500 hover:bg-rose-50 rounded-md transition cursor-pointer"
                      title={`Supprimer la classe ${teach.classRoom}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                    <div>
                      <label className="text-[9px] font-bold text-slate-400 uppercase">Nom complet</label>
                      <input
                        type="text"
                        className="w-full px-2.5 py-1 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 mt-0.5"
                        placeholder="Ex: M. Jean Picard"
                        value={teach.teacherName}
                        onChange={(e) => {
                          const updated = classTeachers.map((t, i) =>
                            i === idx ? { ...t, teacherName: e.target.value } : t
                          );
                          setClassTeachers(updated);
                        }}
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-slate-400 uppercase">Téléphone</label>
                      <input
                        type="text"
                        className="w-full px-2.5 py-1 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 mt-0.5"
                        placeholder="Ex: +237 6xx..."
                        value={teach.teacherPhone || ''}
                        onChange={(e) => {
                          const updated = classTeachers.map((t, i) =>
                            i === idx ? { ...t, teacherPhone: e.target.value } : t
                          );
                          setClassTeachers(updated);
                        }}
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-slate-400 uppercase">Email / Contact</label>
                      <input
                        type="text"
                        className="w-full px-2.5 py-1 text-xs border border-slate-200 rounded-lg focus:outline-indigo-500 mt-0.5 text-slate-650"
                        placeholder="Ex: jean.picard@ecole..."
                        value={teach.teacherEmail || ''}
                        onChange={(e) => {
                          const updated = classTeachers.map((t, i) =>
                            i === idx ? { ...t, teacherEmail: e.target.value } : t
                          );
                          setClassTeachers(updated);
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Form to add a new classroom division */}
            <div className="bg-slate-50 border border-slate-150 rounded-xl p-3 flex gap-2 items-end">
              <div className="flex-1 space-y-1">
                <label className="text-[9px] font-bold text-slate-600 uppercase">Ajouter une classe sur-mesure</label>
                <input
                  type="text"
                  placeholder="Ex: 6ème A, 4ème ALL 2, CM2..."
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-indigo-500"
                />
              </div>
              <button
                type="button"
                onClick={() => {
                  if (!newClassName.trim()) {
                    alert("Le nom de la classe ne peut pas être vide.");
                    return;
                  }
                  if (classTeachers.some(t => t.classRoom.trim().toLowerCase() === newClassName.trim().toLowerCase())) {
                    alert("Cette classe existe déjà dans la liste.");
                    return;
                  }
                  setClassTeachers([
                    ...classTeachers,
                    { classRoom: newClassName.trim(), teacherName: '', teacherPhone: '', teacherEmail: '' }
                  ]);
                  setNewClassName('');
                }}
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer shrink-0"
              >
                <Plus className="h-3.5 w-3.5" /> Ajouter
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                handleSaveWithExtra({
                  classTeachers: classTeachers,
                }, "Liste des professeurs titulaires mise à jour !");
              }}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold uppercase tracking-wide flex items-center justify-center gap-1.5 cursor-pointer transition shadow-2xs mt-2"
            >
              <Save className="h-4 w-4" /> Mettre à jour les Professeurs
            </button>
          </div>
        </div>
      </div>

      {/* SECTION: Custom Subjects & Curricula by Class */}
      <div className="bg-white border border-slate-150 rounded-2xl p-4 md:p-6 space-y-5 shadow-3xs">
        <div className="border-b border-slate-150 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BookOpen className="h-4.5 w-4.5 text-indigo-600" /> Configuration des Matières & Disciplines par Classe
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Introduisez et adaptez le programme de matières selon chaque niveau de classe (6ème, 5ème, 4ème, 3ème, 2nde, 1ère, Tle, etc.).
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                if (window.confirm("Voulez-vous charger la liste standard des matières officielles (Maths, Français, SVT, Physique, Anglais, Histo-Géo, Info, ECM, LV2, Philo) ?")) {
                  const defaultList: ClassSubject[] = [
                    { id: 'subj_' + Date.now() + '_1', name: 'Mathématiques', classRoom: 'Toutes les classes', coef: 4, category: 'Scientifique' },
                    { id: 'subj_' + Date.now() + '_2', name: 'Français', classRoom: 'Toutes les classes', coef: 4, category: 'Littéraire' },
                    { id: 'subj_' + Date.now() + '_3', name: 'Anglais', classRoom: 'Toutes les classes', coef: 3, category: 'Langues' },
                    { id: 'subj_' + Date.now() + '_4', name: 'Sciences de la Vie et de la Terre (SVT)', classRoom: 'Toutes les classes', coef: 3, category: 'Scientifique' },
                    { id: 'subj_' + Date.now() + '_5', name: 'Physique-Chimie', classRoom: '4ème, 3ème, 2nde, 1ère, Tle', coef: 3, category: 'Scientifique' },
                    { id: 'subj_' + Date.now() + '_6', name: 'Histoire-Géographie', classRoom: 'Toutes les classes', coef: 2, category: 'Sciences Humaines' },
                    { id: 'subj_' + Date.now() + '_7', name: 'Informatique', classRoom: 'Toutes les classes', coef: 2, category: 'Technique & Arts' },
                    { id: 'subj_' + Date.now() + '_8', name: 'Éducation à la Citoyenneté et à la Morale (ECM)', classRoom: 'Toutes les classes', coef: 2, category: 'Sciences Humaines' },
                    { id: 'subj_' + Date.now() + '_9', name: 'Allemand / Espagnol (LV2)', classRoom: '4ème, 3ème, 2nde, 1ère, Tle', coef: 2, category: 'Langues' },
                    { id: 'subj_' + Date.now() + '_10', name: 'Philosophie', classRoom: '1ère, Tle', coef: 4, category: 'Littéraire' },
                  ];
                  setClassSubjects(defaultList);
                  handleSaveWithExtra({ classSubjects: defaultList }, "Matières par défaut rechargées !");
                }
              }}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg flex items-center gap-1.5 transition cursor-pointer"
            >
              <RefreshCw className="h-3.5 w-3.5 text-slate-500" /> Programme Officiel Standard
            </button>
            <span className="text-xs bg-indigo-50 border border-indigo-150 px-2.5 py-1 rounded-full font-bold text-indigo-700">
              {classSubjects.length} Matière(s)
            </span>
          </div>
        </div>

        {/* Filter Pills by Class */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mr-1 flex items-center gap-1">
            <Filter className="h-3 w-3" /> Filtrer:
          </span>
          {['all', 'Toutes les classes', '6ème', '5ème', '4ème', '3ème', '2nde', '1ère', 'Tle'].map((cls) => {
            const label = cls === 'all' ? 'Toutes les matières' : cls;
            const isSelected = subjClassFilter === cls;
            return (
              <button
                key={cls}
                type="button"
                onClick={() => setSubjClassFilter(cls)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* Add / Edit Form Card */}
        <div className="p-4 bg-indigo-50/60 border border-indigo-150 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-indigo-950 uppercase tracking-wide flex items-center gap-1.5">
              {editingSubjId ? <Edit2 className="h-3.5 w-3.5 text-indigo-600" /> : <Plus className="h-3.5 w-3.5 text-indigo-600" />}
              {editingSubjId ? 'Modifier la matière' : 'Ajouter une nouvelle matière selon la classe'}
            </h4>
            {editingSubjId && (
              <button
                type="button"
                onClick={() => {
                  setEditingSubjId(null);
                  setNewSubjName('');
                  setNewSubjClass('Toutes les classes');
                  setNewSubjCoef(2);
                  setNewSubjCategory('Scientifique');
                  setNewSubjTeacher('');
                }}
                className="text-[10px] text-slate-500 hover:text-slate-800 font-bold underline cursor-pointer"
              >
                Annuler la modification
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 text-xs">
            <div className="md:col-span-4 space-y-1">
              <label className="text-[10px] font-bold text-slate-600 uppercase">
                Intitulé de la Matière <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="Ex: Informatique, ECM, Droit, Philosophie..."
                value={newSubjName}
                onChange={(e) => setNewSubjName(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white font-medium"
              />
            </div>

            <div className="md:col-span-3 space-y-1">
              <label className="text-[10px] font-bold text-slate-600 uppercase">
                Classe / Niveau Concerné <span className="text-red-500">*</span>
              </label>
              <select
                value={newSubjClass}
                onChange={(e) => setNewSubjClass(e.target.value)}
                className="w-full px-2 py-1.5 border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white font-medium"
              >
                <option value="Toutes les classes">Toutes les classes</option>
                <option value="6ème">6ème</option>
                <option value="5ème">5ème</option>
                <option value="4ème">4ème</option>
                <option value="3ème">3ème</option>
                <option value="2nde">2nde</option>
                <option value="2nde A">2nde A (Littéraire)</option>
                <option value="2nde C">2nde C (Scientifique)</option>
                <option value="1ère">1ère</option>
                <option value="1ère A">1ère A</option>
                <option value="1ère C">1ère C</option>
                <option value="1ère D">1ère D</option>
                <option value="Tle">Terminale (Tle)</option>
                <option value="Tle A">Tle A</option>
                <option value="Tle C">Tle C</option>
                <option value="Tle D">Tle D</option>
                <option value="CM2">CM2 / Primaire</option>
              </select>
            </div>

            <div className="md:col-span-2 space-y-1">
              <label className="text-[10px] font-bold text-slate-600 uppercase">
                Coefficient
              </label>
              <input
                type="number"
                min={1}
                max={10}
                value={newSubjCoef}
                onChange={(e) => setNewSubjCoef(Number(e.target.value) || 1)}
                className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white font-bold text-center"
              />
            </div>

            <div className="md:col-span-3 space-y-1">
              <label className="text-[10px] font-bold text-slate-600 uppercase">
                Domaine / Groupe
              </label>
              <select
                value={newSubjCategory}
                onChange={(e) => setNewSubjCategory(e.target.value)}
                className="w-full px-2 py-1.5 border border-slate-200 rounded-lg focus:outline-indigo-500 bg-white font-medium"
              >
                <option value="Scientifique">Sciences & Maths</option>
                <option value="Littéraire">Lettres & Philosophie</option>
                <option value="Langues">Langues Vivantes</option>
                <option value="Sciences Humaines">Histoire-Géo & ECM</option>
                <option value="Technique & Arts">Informatique & Arts</option>
                <option value="Général">Général / Autre</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="button"
              onClick={() => {
                if (!newSubjName.trim()) {
                  alert("Veuillez saisir l'intitulé de la matière.");
                  return;
                }
                if (editingSubjId) {
                  const updated = classSubjects.map(s => s.id === editingSubjId ? {
                    ...s,
                    name: newSubjName.trim(),
                    classRoom: newSubjClass,
                    coef: newSubjCoef,
                    category: newSubjCategory,
                    teacherName: newSubjTeacher.trim() || undefined,
                  } : s);
                  setClassSubjects(updated);
                  setEditingSubjId(null);
                } else {
                  const newObj: ClassSubject = {
                    id: 'subj_' + Date.now(),
                    name: newSubjName.trim(),
                    classRoom: newSubjClass,
                    coef: newSubjCoef,
                    category: newSubjCategory,
                    teacherName: newSubjTeacher.trim() || undefined,
                  };
                  setClassSubjects([...classSubjects, newObj]);
                }
                setNewSubjName('');
                setNewSubjClass('Toutes les classes');
                setNewSubjCoef(2);
                setNewSubjCategory('Scientifique');
                setNewSubjTeacher('');
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
            >
              {editingSubjId ? <Save className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
              {editingSubjId ? 'Enregistrer les modifications' : 'Ajouter cette matière'}
            </button>
          </div>
        </div>

        {/* List of Configured Subjects */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {classSubjects
            .filter(s => {
              if (subjClassFilter === 'all') return true;
              return s.classRoom === subjClassFilter || s.classRoom === 'Toutes les classes';
            })
            .map((subj) => {
              let catBg = 'bg-blue-50 text-blue-700 border-blue-200';
              if (subj.category === 'Littéraire') catBg = 'bg-purple-50 text-purple-700 border-purple-200';
              if (subj.category === 'Langues') catBg = 'bg-emerald-50 text-emerald-700 border-emerald-200';
              if (subj.category === 'Sciences Humaines') catBg = 'bg-amber-50 text-amber-700 border-amber-200';
              if (subj.category === 'Technique & Arts') catBg = 'bg-cyan-50 text-cyan-700 border-cyan-200';

              return (
                <div
                  key={subj.id}
                  className="p-3 bg-white border border-slate-200 rounded-xl hover:border-indigo-300 transition shadow-3xs flex flex-col justify-between space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`px-2 py-0.5 text-[9px] font-extrabold rounded-full border ${catBg}`}>
                          {subj.category || 'Général'}
                        </span>
                        <span className="text-[10px] font-bold bg-slate-100 border border-slate-200 text-slate-700 px-2 py-0.5 rounded-md">
                          Coef. {subj.coef || 1}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 leading-snug">
                        {subj.name}
                      </h4>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingSubjId(subj.id);
                          setNewSubjName(subj.name);
                          setNewSubjClass(subj.classRoom || 'Toutes les classes');
                          setNewSubjCoef(subj.coef || 2);
                          setNewSubjCategory(subj.category || 'Scientifique');
                          setNewSubjTeacher(subj.teacherName || '');
                        }}
                        className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition cursor-pointer"
                        title="Modifier"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm(`Supprimer la matière ${subj.name} ?`)) {
                            const filtered = classSubjects.filter(s => s.id !== subj.id);
                            setClassSubjects(filtered);
                          }
                        }}
                        className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition cursor-pointer"
                        title="Supprimer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-[10px] font-medium text-slate-500">
                    <span className="flex items-center gap-1">
                      <Layers className="h-3 w-3 text-slate-400" />
                      Niveau : <strong className="text-slate-800 font-bold">{subj.classRoom}</strong>
                    </span>
                    {subj.teacherName && (
                      <span className="truncate max-w-[110px] text-indigo-600 font-semibold">
                        👤 {subj.teacherName}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
        </div>

        <button
          type="button"
          onClick={() => {
            handleSaveWithExtra({ classSubjects }, "Liste des matières et disciplines mise à jour avec succès !");
          }}
          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold uppercase tracking-wide flex items-center justify-center gap-1.5 cursor-pointer transition shadow-2xs"
        >
          <Save className="h-4 w-4" /> Enregistrer la Liste des Matières Pédagogiques
        </button>
      </div>

      {/* NEW SECTION: Annual Budget Lines Allocation */}
      <div className="bg-white border border-slate-150 rounded-2xl p-4 md:p-6 space-y-6">
        <div className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none">
          <div className="space-y-0.5">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="h-4.5 w-4.5 text-indigo-500" /> Répartition du Budget Annuel de l'Établissement
            </h3>
            <p className="text-[10px] text-gray-400">Définissez les enveloppes allouées par rubrique de dépenses pour l'exercice {schoolYear}.</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-lg text-right">
              <div className="text-[9px] font-bold text-slate-500">Allocation Budgétaire Totale</div>
              <div className="font-mono text-xs font-black text-slate-800">
                {totalAllocated.toLocaleString()} FCFA <span className="text-[10px] font-medium text-gray-400">/ {calculatedFinancialGoal.toLocaleString()} FCFA</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setEditingLineId(null);
                setLineName('');
                setLineAmount(0);
                setLineDescription('');
                setIsBudgetModalOpen(true);
              }}
              className="py-2 px-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-3xs hover:shadow-2xs"
            >
              <Plus className="h-4 w-4" /> Ajouter une Rubrique
            </button>
          </div>
        </div>

        {/* Visual progress allocated */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-center text-[10px] font-semibold">
            <span className="text-slate-600">Pourcentage alloué de l'enveloppe globale</span>
            <span className={percentAllocated > 100 ? "text-rose-600" : "text-indigo-600"}>{percentAllocated}% alloués</span>
          </div>
          <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                percentAllocated > 100 ? "bg-rose-500" : percentAllocated === 100 ? "bg-emerald-500" : "bg-indigo-500"
              }`}
              style={{ width: `${percentAllocated}%` }}
            />
          </div>
        </div>

        {/* List of budget lines */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold text-slate-700 px-1 border-l-2 border-indigo-500 select-none">
            Rubriques Enregistrées ({budgetLinesList.length})
          </h4>

          {budgetLinesList.length === 0 ? (
            <div className="border border-dashed border-slate-200 bg-slate-50/50 rounded-xl p-8 text-center text-xs text-slate-400">
              Aucune rubrique budgétaire n'est enregistrée pour cette année académique. 
              Cliquez sur le bouton "Ajouter une Rubrique" ci-dessus pour découper l'objectif global en centres de dépenses.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {budgetLinesList.map((line) => {
                const percentOfTotal = Math.round((line.allocatedAmount / calculatedFinancialGoal) * 100) || 0;
                return (
                  <div 
                    key={line.id} 
                    className={`border p-4 rounded-xl space-y-3 transition-all duration-200 flex flex-col justify-between ${
                      editingLineId === line.id 
                        ? 'border-indigo-500 bg-indigo-50/20 shadow-xs' 
                        : 'border-slate-150 bg-white hover:border-slate-350 hover:shadow-2xs'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-start gap-2">
                        <h5 className="text-xs font-bold text-slate-850 line-clamp-1">{line.name}</h5>
                        <span className="text-[9px] font-sans font-extrabold bg-slate-100 text-slate-705 px-1.5 rounded shrink-0">
                          {percentOfTotal}% du budget
                        </span>
                      </div>
                      {line.description ? (
                        <p className="text-[10px] text-gray-400 line-clamp-2 leading-relaxed min-h-[32px]">
                          {line.description}
                        </p>
                      ) : (
                        <p className="text-[10px] text-slate-300 italic min-h-[32px]">
                          Aucune description fournie
                        </p>
                      )}
                    </div>

                    <div className="flex items-center justify-between border-t border-slate-50 pt-2 shrink-0">
                      <div className="font-mono text-xs font-black text-indigo-650">
                        {line.allocatedAmount.toLocaleString()} FCFA
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleStartEditLine(line)}
                          title="Modifier cette rubrique"
                          className="p-1 px-1.5 bg-slate-50 hover:bg-slate-100 text-slate-400 hover:text-indigo-600 rounded transition cursor-pointer"
                        >
                          <Edit2 className="h-3 w-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteLine(line.id, line.name)}
                          title="Supprimer cette rubrique"
                          className="p-1 px-1.5 bg-slate-50 hover:bg-slate-100 text-slate-400 hover:text-rose-600 rounded transition cursor-pointer"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* SECTION: Electronic Payment Gateways Parameters Form */}
      <div className="bg-white border border-slate-150 rounded-2xl p-4 md:p-6 space-y-6">
        <div className="border-b border-slate-100 pb-3 select-none">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <CreditCard className="h-4.5 w-4.5 text-indigo-500" /> Configuration des Passerelles de Paiement Électronique
          </h3>
          <p className="text-[10px] text-gray-400 mt-0.5 animate-none">
            Activez et configurez les paramètres des passerelles de paiement par cartes bancaires (Stripe) et Mobile Money (MTN / Orange / Wave) pour les parents d'élèves de l'établissement.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Mobile Money MTN & Orange Cameroon */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5 uppercase tracking-wide border-b pb-1 select-none">
              <Smartphone className="h-4 w-4 text-amber-500" /> Mobile Money (Cameroun / Zone Afrique)
            </h4>

            {/* MTN Mobile Money */}
            <div className={`p-4 rounded-xl border transition-all duration-250 ${mtnEnabled ? 'border-amber-400 bg-amber-50/5' : 'border-slate-150 bg-slate-50/50'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-400 flex items-center justify-center font-black text-slate-950 text-xs shadow-3xs select-none">
                    MTN
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-800">MTN MoMo API</h5>
                    <p className="text-[9px] text-gray-400">Passerelle Mobile Money MTN Cameroun</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={mtnEnabled} 
                    onChange={(e) => setMtnEnabled(e.target.checked)} 
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              {mtnEnabled && (
                <div className="mt-3.5 space-y-3 text-xs animate-fade-in">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-550 uppercase">Nom du Marchand Agréé</label>
                      <input 
                        type="text" 
                        value={mtnMerchantName} 
                        onChange={(e) => setMtnMerchantName(e.target.value)} 
                        placeholder="Ex: APEE CES EKALI" 
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-amber-500 text-slate-805"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-550 uppercase">N° Téléphone du Marchand</label>
                      <input 
                        type="text" 
                        value={mtnPhoneNumber} 
                        onChange={(e) => setMtnPhoneNumber(e.target.value)} 
                        placeholder="Ex: +237 677 xxx xxx" 
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-amber-500 font-mono text-slate-805"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-550 uppercase">MTN Client ID (User API)</label>
                    <input 
                      type="text" 
                      value={mtnClientId} 
                      onChange={(e) => setMtnClientId(e.target.value)} 
                      placeholder="Ex: d1882d4c-xxxx-xxxx" 
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-amber-500 font-mono text-slate-805"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-555 uppercase">MTN API Secret / Client Secret</label>
                    <div className="relative">
                      <input 
                        type={showMtnSecret ? "text" : "password"} 
                        value={mtnClientSecret} 
                        onChange={(e) => setMtnClientSecret(e.target.value)} 
                        placeholder="Clé secrète MTN MoMo" 
                        className="w-full pl-3 pr-16 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-amber-500 font-mono text-slate-805 font-bold"
                      />
                      <button
                        type="button"
                        onClick={() => setShowMtnSecret(!showMtnSecret)}
                        className="absolute right-2 top-1 text-[9px] text-gray-400 hover:text-slate-800 p-1 uppercase font-bold"
                      >
                        {showMtnSecret ? "Cacher" : "Afficher"}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Orange Money */}
            <div className={`p-4 rounded-xl border transition-all duration-250 ${orangeEnabled ? 'border-orange-450 bg-orange-50/5' : 'border-slate-150 bg-slate-50/50'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-orange-500 flex items-center justify-center font-black text-white text-xs shadow-3xs select-none">
                    OM
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-800">Orange Money API</h5>
                    <p className="text-[9px] text-gray-400">Passerelle Orange Money Web Payment</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={orangeEnabled} 
                    onChange={(e) => setOrangeEnabled(e.target.checked)} 
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-orange-500"></div>
                </label>
              </div>

              {orangeEnabled && (
                <div className="mt-3.5 space-y-3 text-xs animate-fade-in">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-550 uppercase">Nom du Marchand Agréé</label>
                      <input 
                        type="text" 
                        value={orangeMerchantName} 
                        onChange={(e) => setOrangeMerchantName(e.target.value)} 
                        placeholder="Ex: APEE CES EKALI" 
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-orange-500 text-slate-805"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-550 uppercase">N° Téléphone du Marchand</label>
                      <input 
                        type="text" 
                        value={orangePhoneNumber} 
                        onChange={(e) => setOrangePhoneNumber(e.target.value)} 
                        placeholder="Ex: +237 699 xxx xxx" 
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-orange-500 font-mono text-slate-805"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-550 uppercase">Orange Client ID</label>
                      <input 
                        type="text" 
                        value={orangeClientId} 
                        onChange={(e) => setOrangeClientId(e.target.value)} 
                        placeholder="Ex: OTM_c729x..." 
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-orange-500 font-mono text-slate-805"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-550 uppercase">Orange Merchant Key</label>
                      <input 
                        type="text" 
                        value={orangeMerchantKey} 
                        onChange={(e) => setOrangeMerchantKey(e.target.value)} 
                        placeholder="Ex: 504629d..." 
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-orange-500 font-mono text-slate-805"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-555 uppercase">Orange Client Secret (API Key)</label>
                    <div className="relative">
                      <input 
                        type={showOrangeSecret ? "text" : "password"} 
                        value={orangeClientSecret} 
                        onChange={(e) => setOrangeClientSecret(e.target.value)} 
                        placeholder="Clé secrète Orange Web Payment" 
                        className="w-full pl-3 pr-16 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-orange-500 font-mono text-slate-805 font-bold"
                      />
                      <button
                        type="button"
                        onClick={() => setShowOrangeSecret(!showOrangeSecret)}
                        className="absolute right-2 top-1 text-[9px] text-gray-400 hover:text-slate-800 p-1 uppercase font-bold"
                      >
                        {showOrangeSecret ? "Cacher" : "Afficher"}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

          </div>

          {/* Card & Wave payments */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-slate-700 flex items-center gap-1.5 uppercase tracking-wide border-b pb-1 select-none">
              <CreditCard className="h-4 w-4 text-indigo-500" /> Cartes Bancaires & Portefeuilles
            </h4>

            {/* Carte Bancaire - Stripe */}
            <div className={`p-4 rounded-xl border transition-all duration-250 ${cardEnabled ? 'border-indigo-400 bg-indigo-50/5' : 'border-slate-150 bg-slate-50/50'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-black text-xs shadow-3xs select-none">
                    💳
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-800">Cartes Bancaires (Stripe)</h5>
                    <p className="text-[9px] text-gray-400">Paiement international par Visa, MasterCard</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={cardEnabled} 
                    onChange={(e) => setCardEnabled(e.target.checked)} 
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              {cardEnabled && (
                <div className="mt-3.5 space-y-3 text-xs animate-fade-in">
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-550 uppercase">Clé Publique Stripe (Stripe Publishable Key)</label>
                    <input 
                      type="text" 
                      value={stripePublicKey} 
                      onChange={(e) => setStripePublicKey(e.target.value)} 
                      placeholder="Ex: pk_test_51Px..." 
                      className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-indigo-500 font-mono text-slate-805"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-555 uppercase">Clé Secrète Stripe (Stripe Secret Key)</label>
                    <div className="relative">
                      <input 
                        type={showStripeSecret ? "text" : "password"} 
                        value={stripeSecretKey} 
                        onChange={(e) => setStripeSecretKey(e.target.value)} 
                        placeholder="Ex: sk_test_51Px..." 
                        className="w-full pl-3 pr-16 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-indigo-500 font-mono text-slate-805 font-bold"
                      />
                      <button
                        type="button"
                        onClick={() => setShowStripeSecret(!showStripeSecret)}
                        className="absolute right-2 top-1 text-[9px] text-gray-400 hover:text-slate-800 p-1 uppercase font-bold"
                      >
                        {showStripeSecret ? "Cacher" : "Afficher"}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Wave Senegal/Cote d'Ivoire */}
            <div className={`p-4 rounded-xl border transition-all duration-250 ${waveEnabled ? 'border-sky-400 bg-sky-50/5' : 'border-slate-150 bg-slate-50/50'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-sky-400 flex items-center justify-center font-black text-white text-xs shadow-3xs select-none">
                    🌊
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-800">Wave Wallet</h5>
                    <p className="text-[9px] text-gray-400">Portefeuille mobile Wave Sénégal / Côte d'Ivoire</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={waveEnabled} 
                    onChange={(e) => setWaveEnabled(e.target.checked)} 
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-sky-500"></div>
                </label>
              </div>

              {waveEnabled && (
                <div className="mt-3.5 space-y-3 text-xs animate-fade-in">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-550 uppercase">Nom du Marchand Agréé</label>
                      <input 
                        type="text" 
                        value={waveMerchantName} 
                        onChange={(e) => setWaveMerchantName(e.target.value)} 
                        placeholder="Ex: APEE CES EKALI" 
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-sky-500 text-slate-805"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-slate-550 uppercase">N° Téléphone Wave</label>
                      <input 
                        type="text" 
                        value={wavePhoneNumber} 
                        onChange={(e) => setWavePhoneNumber(e.target.value)} 
                        placeholder="Ex: +221 77 xxx xx xx" 
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-sky-500 font-mono text-slate-805"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-555 uppercase">Clé d'API Wave (Wave API Key)</label>
                    <div className="relative">
                      <input 
                        type={showWaveSecret ? "text" : "password"} 
                        value={waveApiKey} 
                        onChange={(e) => setWaveApiKey(e.target.value)} 
                        placeholder="Clé API Wave" 
                        className="w-full pl-3 pr-16 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-sky-500 font-mono text-slate-805 font-bold"
                      />
                      <button
                        type="button"
                        onClick={() => setShowWaveSecret(!showWaveSecret)}
                        className="absolute right-2 top-1 text-[9px] text-gray-400 hover:text-slate-800 p-1 uppercase font-bold"
                      >
                        {showWaveSecret ? "Cacher" : "Afficher"}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>

        <button
          type="button"
          onClick={() => {
            handleSaveWithExtra({}, "Paramètres des passerelles de paiements électroniques sauvegardés avec succès !");
          }}
          className="w-full py-2.5 bg-indigo-650 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold uppercase tracking-wide flex items-center justify-center gap-1.5 cursor-pointer transition shadow-2xs mt-2"
        >
          <Save className="h-4 w-4 text-emerald-400" /> Sauvegarder les configurations de paiement
        </button>
      </div>

      {/* SECTION: Campay Mobile Money Payment Integration Form */}
      <PaymentConfigurationForm
        settings={settings}
        onSaveSettings={onSaveSettings}
      />

      {/* SECTION: SMS Gateway Configuration & Test Form */}
      <SmsConfigurationForm
        settings={settings}
        onSaveSettings={onSaveSettings}
      />

      {/* MODAL: Define / Edit Budget Line */}
      {isBudgetModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in" id="budget_line_modal">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 max-w-md w-full overflow-hidden animate-scale-in">
            <div className="border-b border-slate-100 px-5 py-4 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                {editingLineId ? <Edit2 className="h-4 w-4 text-indigo-500" /> : <Plus className="h-4 w-4 text-indigo-500" />}
                {editingLineId ? 'Modifier la Ligne Budgétaire' : 'Nouvelle Ligne Budgétaire'}
              </h3>
              <button
                type="button"
                onClick={handleCancelEditLine}
                className="p-1 px-2.5 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 rounded-lg text-xs font-bold font-mono transition cursor-pointer"
              >
                X
              </button>
            </div>

            <form onSubmit={handleSaveBudgetLine} className="p-5 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-655 uppercase block">Nom de la Ligne Budgétaire <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  required
                  value={lineName}
                  onChange={(e) => setLineName(e.target.value)}
                  placeholder="Ex: Didactique et Craies"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-indigo-500 font-medium text-slate-800"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-655 uppercase block">Montant Alloué (FCFA) <span className="text-red-500">*</span></label>
                <div className="relative">
                  <span className="absolute left-3 text-[10px] top-2.5 font-bold text-slate-450">FCFA</span>
                  <input
                    type="number"
                    min="1000"
                    required
                    value={lineAmount || ''}
                    onChange={(e) => setLineAmount(Number(e.target.value))}
                    placeholder="Ex: 500000"
                    className="w-full pl-14 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-indigo-500 font-mono text-slate-800 text-right font-bold bg-slate-50/20"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-650 uppercase block">Description / Détails d'usage</label>
                <textarea
                  value={lineDescription}
                  onChange={(e) => setLineDescription(e.target.value)}
                  placeholder="Ex: Achat de rames de papier, agendas pédagogiques, stylos pour enseignants..."
                  rows={3}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-indigo-500 font-medium text-slate-800 resize-none animate-none"
                />
              </div>

              <div className="flex gap-2 p-3 mt-4 border-t border-slate-100 shrink-0">
                {editingLineId && (
                  <button
                    type="button"
                    onClick={() => {
                      if (editingLineId) {
                        handleDeleteLine(editingLineId, lineName);
                        setIsBudgetModalOpen(false);
                      }
                    }}
                    className="px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold rounded-xl transition uppercase tracking-wide cursor-pointer text-center flex items-center justify-center gap-1.5 shrink-0"
                    title="Supprimer cette rubrique budgétaire"
                  >
                    <Trash2 className="h-3.5 w-3.5 text-red-600 shrink-0" /> Supprimer
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleCancelEditLine}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition uppercase tracking-wide cursor-pointer text-center"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="flex-1 py-1 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition uppercase tracking-wide cursor-pointer text-center"
                >
                  {editingLineId ? 'Sauvegarder' : 'Ajouter'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Custom Confirmation Modal for Budget Line */}
      {lineToDelete && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-[9999] no-print animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-150 w-full max-w-md max-h-[90vh] flex flex-col overflow-hidden text-slate-800 animate-in fade-in zoom-in duration-200">
            {/* Header warning zone */}
            <div className="bg-red-50 p-6 flex flex-col items-center gap-3 text-center border-b border-red-100 shrink-0">
              <div className="p-3 bg-red-100 text-red-655 rounded-full animate-pulse">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-red-900 tracking-tight">Supprimer la Rubrique</h3>
              </div>
            </div>
            
            {/* Body details info */}
            <div className="p-6 overflow-y-auto flex-1 min-h-0 text-center sm:text-left">
              <p className="text-sm text-slate-655 leading-relaxed mb-4">
                Voulez-vous vraiment supprimer définitivement cette rubrique budgétaire ?
              </p>
              
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-4 mb-4 text-left">
                <div className="text-[10px] font-bold text-slate-400 uppercase select-none">Rubrique</div>
                <div className="text-sm font-bold text-slate-800 tracking-tight mt-0.5">{lineToDelete.name}</div>
              </div>

              <div className="text-xs text-slate-655 flex items-start gap-2 bg-amber-50 text-amber-850 p-3.5 rounded-xl border border-amber-200 text-left">
                <span className="shrink-0 mt-0.5 font-bold">⚠️ Important:</span>
                <span>Les dépenses et les écritures comptables déjà exécutées sous cette rubrique perdront leur étiquette d'imputation budgétaire (affectation au budget).</span>
              </div>
            </div>

            {/* Actions */}
            <div className="bg-slate-50 border-t border-slate-100 p-4 flex gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => setLineToDelete(null)}
                className="flex-1 px-4 py-2.5 text-xs font-semibold text-slate-705 bg-white border border-slate-250 hover:bg-slate-50 rounded-xl cursor-pointer transition select-none"
              >
                Conserver la rubrique
              </button>
              
              <button
                type="button"
                onClick={handleConfirmDeleteLine}
                className="flex-1 px-4 py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl cursor-pointer transition select-none flex items-center justify-center gap-1.5 shadow-xs min-w-[130px]"
              >
                <Trash2 className="h-3.5 w-3.5 text-white shrink-0" />
                Confirmer la suppression
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Confirmation Modal for Classroom configuration */}
      {classToDeleteIdx !== null && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-[9999] no-print animate-fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-150 w-full max-w-md max-h-[90vh] flex flex-col overflow-hidden text-slate-800 animate-in fade-in zoom-in duration-200">
            {/* Header warning zone */}
            <div className="bg-red-50 p-6 flex flex-col items-center gap-3 text-center border-b border-red-100 shrink-0">
              <div className="p-3 bg-red-100 text-red-655 rounded-full animate-bounce">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-red-900 tracking-tight">Supprimer la Configuration</h3>
              </div>
            </div>
            
            {/* Body details info */}
            <div className="p-6 overflow-y-auto flex-1 min-h-0 text-center sm:text-left">
              <p className="text-sm text-slate-655 leading-relaxed mb-4">
                Voulez-vous vraiment supprimer la configuration de l'enseignant titulaire pour cette classe ?
              </p>
              
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-4 mb-4 text-left">
                <div className="text-[10px] font-bold text-slate-400 uppercase select-none">Classe</div>
                <div className="text-sm font-bold text-slate-800 tracking-tight mt-0.5">{classToDeleteRoom}</div>
              </div>

              <div className="text-xs text-slate-655 flex items-start gap-2 bg-slate-50 text-slate-705 p-3.5 rounded-xl border border-slate-200 text-left">
                <span className="shrink-0 mt-0.5 font-bold">💡 Information:</span>
                <span>Cette action va réinitialiser le nom, le téléphone et l'e-mail de l'enseignant de cette division. Aucun bulletin existant ne sera détruit. Pratique pour repartir à zéro.</span>
              </div>
            </div>

            {/* Actions */}
            <div className="bg-slate-50 border-t border-slate-100 p-4 flex gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setClassToDeleteIdx(null);
                  setClassToDeleteRoom('');
                }}
                className="flex-1 px-4 py-2.5 text-xs font-semibold text-slate-705 bg-white border border-slate-250 hover:bg-slate-50 rounded-xl cursor-pointer transition select-none"
              >
                Conserver la classe
              </button>
              
              <button
                type="button"
                onClick={handleConfirmDeleteClass}
                className="flex-1 px-4 py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl cursor-pointer transition select-none flex items-center justify-center gap-1.5 shadow-xs min-w-[130px]"
              >
                <Trash2 className="h-3.5 w-3.5 text-white shrink-0" />
                Confirmer la suppression
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
