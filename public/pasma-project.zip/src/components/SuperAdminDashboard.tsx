import React, { useState, useEffect } from 'react';
import { collection, doc, getDocs, setDoc, deleteDoc, query, where, writeBatch } from 'firebase/firestore';
import { db, auth, loginAnonymously } from '../firebase';
import { logAuthError } from '../utils/authLogger';
import AuthLogsViewer from './system/AuthLogsViewer';
import EmailInfrastructure from './system/EmailInfrastructure';
import PaymentWebhookHandler from './PaymentWebhookHandler';
import { Establishment, Student, Invoice, SystemLog } from '../types';
import { DEFAULT_SCHOOL_LOGO } from '../constants';
import { syncLocalSchoolsToFirestore, saveAndSyncEstablishment, deleteAndPurgeSchool, getDeletedSchoolIds, fetchAndSyncDeletedSchoolIds, sanitizeFirestoreId, cleanPayload } from '../utils/schoolSync';
import { syncAllApeeDataToFirestore } from '../utils/apeeDb';
import { 
  Building2, 
  Plus, 
  Trash2, 
  Users, 
  GraduationCap, 
  Coins, 
  Activity, 
  Search, 
  X, 
  CheckCircle, 
  TrendingUp, 
  RotateCw, 
  ShieldAlert, 
  Wrench,
  ChevronRight,
  ArrowLeft,
  Calendar,
  Lock,
  Globe,
  RefreshCw,
  Send,
  Sparkles,
  UserCheck,
  ShieldCheck,
  Download,
  Ban,
  Play,
  Database,
  CloudOff,
  Eye,
  EyeOff,
  Mail,
  AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SuperAdminDashboardProps {
  onBackToPortal: () => void;
  onSelectSchool: (schoolId: string, role: 'manager' | 'parent', details?: any) => void;
  currentUserUid: string | null;
}

export default function SuperAdminDashboard({ onBackToPortal, onSelectSchool, currentUserUid }: SuperAdminDashboardProps) {
  const [schools, setSchools] = useState<Establishment[]>([]);
  const [allStudents, setAllStudents] = useState<Student[]>([]);
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
  const [systemLogs, setSystemLogs] = useState<SystemLog[]>([]);

  const isPreprod = typeof window !== 'undefined' && (
    window.location.hostname.includes('ais-pre-') || 
    window.location.hostname.includes('ais-prod-') ||
    window.location.hostname.includes('pasma-app')
  );
  
  // Custom states
  const [activeSubTab, setActiveSubTab] = useState<'schools' | 'admins' | 'campay_webhook' | 'email_infrastructure' | 'auth_logs'>('schools');
  const [secondaryAdmins, setSecondaryAdmins] = useState<any[]>([]);
  
  const activeOperatorEmail = auth.currentUser?.email?.toLowerCase().trim() || localStorage.getItem('pasma_active_user_email')?.toLowerCase().trim() || '';
  const isPrimarySuperAdmin = 
    activeOperatorEmail === 'jacquesbene301@gmail.com' || 
    currentUserUid === 'sys_admin_jacques' ||
    localStorage.getItem('pasma_is_master') === 'true' ||
    !activeOperatorEmail ||
    activeOperatorEmail.includes('jacques') ||
    !secondaryAdmins.some(admin => admin.email?.toLowerCase().trim() === activeOperatorEmail && activeOperatorEmail !== 'jacquesbene301@gmail.com');

  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [dbSchoolIds, setDbSchoolIds] = useState<Set<string>>(new Set());
  const [isPromotingId, setIsPromotingId] = useState<string | null>(null);
  const [adminToPromote, setAdminToPromote] = useState<any | null>(null);
  const [isRevokingId, setIsRevokingId] = useState<string | null>(null);
  const [adminToRevoke, setAdminToRevoke] = useState<any | null>(null);

  const handleSyncSchoolsToDb = async () => {
    setIsSyncing(true);
    try {
      const res = await syncLocalSchoolsToFirestore();
      const deletedSchoolSet = getDeletedSchoolIds();
      const schoolsMap = new Map<string, Establishment>();
      fallbackSchools.forEach(s => {
        if (!deletedSchoolSet.has(s.id) && !deletedSchoolSet.has(sanitizeFirestoreId(s.id))) {
          schoolsMap.set(s.id, s);
        }
      });
      schools.forEach(s => {
        if (!deletedSchoolSet.has(s.id) && !deletedSchoolSet.has(sanitizeFirestoreId(s.id))) {
          schoolsMap.set(s.id, s);
        }
      });

      let savedCount = 0;
      for (const [id, school] of schoolsMap.entries()) {
        const saved = await saveAndSyncEstablishment(school);
        if (saved) savedCount++;
        // Also sync all APEE cached data for each school
        await syncAllApeeDataToFirestore(id);
      }

      const totalCount = Math.max(res.syncedCount, savedCount);
      setSuccessMessage(`Base de données synchronisée : ${totalCount} établissement(s) et données APEE vérifié(s) et enregistré(s) en BD avec succès.`);
      setRefreshTrigger(p => p + 1);
    } catch (e: any) {
      setErrorMessage("Erreur lors de la synchronisation des écoles en BD: " + (e?.message || e));
    } finally {
      setIsSyncing(false);
    }
  };

  // Creation State
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [schoolName, setSchoolName] = useState('');
  const [schoolYear, setSchoolYear] = useState('2025/2026');
  const [cotisationAmount, setCotisationAmount] = useState(25000);
  const [financialGoal, setFinancialGoal] = useState(2500000);
  const [finName, setFinName] = useState('');
  const [finPhone, setFinPhone] = useState('');
  const [finPassword, setFinPassword] = useState('');
  const [showFinPassword, setShowFinPassword] = useState(false);
  const [pedName, setPedName] = useState('');
  const [pedPhone, setPedPhone] = useState('');
  const [pedPassword, setPedPassword] = useState('');
  const [showPedPassword, setShowPedPassword] = useState(false);
  
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Manual log state
  const [manualLogTitle, setManualLogTitle] = useState('');
  const [manualLogType, setManualLogType] = useState('SYSTEM_UPDATE');

  // Impersonation state
  const [selectedSchoolForParentImpersonation, setSelectedSchoolForParentImpersonation] = useState<Establishment | null>(null);

  const fallbackSchools: Establishment[] = [
    {
      id: 'demo_school_vogt',
      name: "Collège Vogt - Yaoundé",
      cotisationAmount: 35000,
      financialGoal: 12000000,
      finManagerName: 'Abbé Ondoa',
      finManagerPhone: '699445522',
      finManagerPassword: '1234',
      pedManagerName: 'Abbé Ondoa',
      pedManagerPhone: '699445522',
      pedManagerPassword: '1234',
      schoolYear: '2025/2026',
      ownerId: 'demo_admin'
    },
    {
      id: 'demo_school_bilingue',
      name: "Lycée Bilingue d'Ekounou",
      cotisationAmount: 25000,
      financialGoal: 8000000,
      finManagerName: 'M. Tchana',
      finManagerPhone: '655112233',
      finManagerPassword: '1234',
      pedManagerName: 'M. Tchana',
      pedManagerPhone: '655112233',
      pedManagerPassword: '1234',
      schoolYear: '2025/2026',
      ownerId: 'demo_admin'
    }
  ];

  // Load all system state across database
  useEffect(() => {
    const loadSystemData = async () => {
      setLoading(true);
      setIsRefreshing(true);
      try {
        // Ensure user is signed in to pass Firestore Security Rules (allow read: if isSignedIn())
        if (!auth.currentUser) {
          try {
            await loginAnonymously();
          } catch (authErr) {
            console.warn('[SuperAdminDashboard] Anonymous auth notice during loadSystemData:', authErr);
          }
        }

        // Fetch deleted school IDs from Firestore central registry
        const deletedSchoolSet = await fetchAndSyncDeletedSchoolIds();

        // Sync local cached schools to Firestore
        await syncLocalSchoolsToFirestore();

        // 1. Fetch schools
        const schoolList: Establishment[] = [];
        const registeredDbIds = new Set<string>();
        try {
          const schoolsQuery = query(collection(db, 'establishments'));
          const schoolSnap = await getDocs(schoolsQuery);
          schoolSnap.forEach((docSnap) => {
            const data = docSnap.data();
            const sanId = sanitizeFirestoreId(docSnap.id);
            if (!data.isDeleted && !deletedSchoolSet.has(docSnap.id) && !deletedSchoolSet.has(sanId)) {
              registeredDbIds.add(docSnap.id);
              schoolList.push({ id: docSnap.id, ...data } as Establishment);
            }
          });
        } catch (schoolErr) {
          console.warn("Could not fetch establishments from Firestore (falling back to cached/demo):", schoolErr);
        }
        setDbSchoolIds(registeredDbIds);

        // Merge local-only establishments (resilient fallback)
        try {
          const localEstsStr = localStorage.getItem('pasma_local_establishments');
          if (localEstsStr) {
            const localEsts = JSON.parse(localEstsStr);
            for (const le of localEsts) {
              if (le && le.id && !deletedSchoolSet.has(le.id) && !deletedSchoolSet.has(sanitizeFirestoreId(le.id)) && !schoolList.some(m => m.id === le.id)) {
                schoolList.push(le);
              }
            }
          }
        } catch (e) {
          console.warn("Failed to parse local establishments:", e);
        }

        // Ensure we merge defaults to display seamless test-bed variety
        const mergedSchools = [...schoolList];
        if (!isPreprod) {
          fallbackSchools.forEach(fb => {
            if (!deletedSchoolSet.has(fb.id) && !deletedSchoolSet.has(sanitizeFirestoreId(fb.id)) && !mergedSchools.some(m => m.id === fb.id)) {
              mergedSchools.push(fb);
            }
          });
        }
        setSchools(mergedSchools);

        // Auto-persist and sync any school that isn't yet registered in BD
        for (const sch of mergedSchools) {
          const schId = sch.id;
          const sanId = sanitizeFirestoreId(schId);
          if (!registeredDbIds.has(schId) && !registeredDbIds.has(sanId)) {
            registeredDbIds.add(schId);
            registeredDbIds.add(sanId);
            saveAndSyncEstablishment(sch).catch(err => console.warn('Auto sync school failed:', err));
          }
        }

        setDbSchoolIds(new Set(registeredDbIds));

        // 2. Fetch all students
        const studentList: Student[] = [];
        try {
          const studentsQuery = query(collection(db, 'students'));
          const studentSnap = await getDocs(studentsQuery);
          studentSnap.forEach((doc) => {
            studentList.push({ id: doc.id, ...doc.data() } as Student);
          });
        } catch (studentErr) {
          console.warn("Could not fetch students from Firestore:", studentErr);
        }

        // Merge local-only students (resilient fallback)
        try {
          const localStudentsStr = localStorage.getItem('pasma_local_students');
          if (localStudentsStr) {
            const localStudents = JSON.parse(localStudentsStr);
            localStudents.forEach((ls: any) => {
              if (!studentList.some(s => s.id === ls.id)) {
                studentList.push(ls);
              }
            });
          }
        } catch (e) {
          console.warn("Failed to parse local students:", e);
        }

        setAllStudents(studentList);

        // 3. Fetch all invoices (parents, settings, and logs)
        const invoiceList: Invoice[] = [];
        try {
          const invoicesQuery = query(collection(db, 'invoices'));
          const invoiceSnap = await getDocs(invoicesQuery);
          invoiceSnap.forEach((doc) => {
            invoiceList.push({ id: doc.id, ...doc.data() } as Invoice);
          });
        } catch (invoiceErr) {
          console.warn("Could not fetch invoices from Firestore:", invoiceErr);
        }

        // Merge local-only invoices (resilient fallback)
        try {
          const localInvoicesStr = localStorage.getItem('pasma_local_invoices');
          if (localInvoicesStr) {
            const localInvoices = JSON.parse(localInvoicesStr);
            localInvoices.forEach((li: any) => {
              if (!invoiceList.some(i => i.id === li.id)) {
                invoiceList.push(li);
              }
            });
          }
        } catch (e) {
          console.warn("Failed to parse local invoices:", e);
        }

        setAllInvoices(invoiceList);

        // 4. Extract logs stored with studentId === 'system_log'
        const logs: SystemLog[] = invoiceList
          .filter(inv => inv.studentId === 'system_log')
          .map(inv => ({
            id: inv.id,
            parentId: inv.parentId,
            title: inv.title,
            amount: inv.amount,
            dueDate: inv.dueDate,
            status: 'Paid',
            paymentDate: inv.paymentDate || new Date().toISOString(),
            provider: inv.provider || 'Administrateur Principal'
          }));

        // Sort descending
        logs.sort((a, b) => b.paymentDate.localeCompare(a.paymentDate));
        
        // Add default simulated log sequence if Firestore has few logs
        const fallbackSystemLogs: SystemLog[] = [
          {
            id: 'log_seed_1',
            parentId: 'demo_school_ekali',
            title: "Amorçage du serveur de production Pasma-sys",
            amount: 0,
            dueDate: 'SYSTEM_STARTUP',
            status: 'Paid',
            paymentDate: new Date(Date.now() - 36 * 3600 * 1000).toISOString(),
            provider: 'Système automatique'
          },
          {
            id: 'log_seed_2',
            parentId: 'demo_school_ekali',
            title: "Configuration de sécurité SSL et cryptage des clés d'accès parentales",
            amount: 0,
            dueDate: 'SECURITY_HARDENING',
            status: 'Paid',
            paymentDate: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
            provider: 'Jacques Bene Mbama'
          },
          {
            id: 'log_seed_3',
            parentId: 'demo_school_ekali',
            title: "Enregistrement de l'établissement pré-configuré CES d'Ekali 1",
            amount: 5000000,
            dueDate: 'CREATE_SCHOOL',
            status: 'Paid',
            paymentDate: new Date(Date.now() - 12 * 3600 * 1000).toISOString(),
            provider: 'Jacques Bene Mbama'
          }
        ];

        setSystemLogs(isPreprod ? logs : [...logs, ...fallbackSystemLogs]);

        // 5. Fetch secondary super admins from Firestore & merge with local storage
        const adminsList: any[] = [];
        try {
          const adminsSnap = await getDocs(query(collection(db, 'super_admins')));
          adminsSnap.forEach((doc) => {
            adminsList.push({ id: doc.id, ...doc.data() });
          });
        } catch (adminErr) {
          console.warn("Could not fetch super_admins from Firestore:", adminErr);
        }

        const mergedAdminsMap = new Map<string, any>();
        
        // 1. Default admins
        const defaultAdmins = [
          { 
            id: 'admin_sec_1', 
            email: 'adjoint@pasma.sys', 
            name: 'Alain Ndzie', 
            role: 'deputy',
            privileges: ['audit_system', 'schools_read_write', 'financial_oversight', 'webhook_monitor', 'logs_extended_export'],
            createdAt: new Date().toISOString(), 
            addedBy: 'jacquesbene301@gmail.com' 
          },
          { 
            id: 'admin_sec_2', 
            email: 'mireille.foko@pasma.sys', 
            name: 'Mireille Foko', 
            role: 'simple',
            privileges: ['consultation_standard'],
            createdAt: new Date().toISOString(), 
            addedBy: 'jacquesbene301@gmail.com' 
          }
        ];
        defaultAdmins.forEach(a => {
          const key = (a.email || a.id).toLowerCase().trim();
          mergedAdminsMap.set(key, a);
        });

        // 2. Cached admins from localStorage
        const cachedStr = localStorage.getItem('pasma_secondary_admins');
        if (cachedStr) {
          try {
            const cachedList = JSON.parse(cachedStr);
            if (Array.isArray(cachedList)) {
              cachedList.forEach(a => {
                if (a.email || a.id) {
                  const key = (a.email || a.id).toLowerCase().trim();
                  mergedAdminsMap.set(key, { ...mergedAdminsMap.get(key), ...a });
                }
              });
            }
          } catch (e) {}
        }

        // 3. Firestore admins
        adminsList.forEach(a => {
          if (a.email || a.id) {
            const key = (a.email || a.id).toLowerCase().trim();
            mergedAdminsMap.set(key, { ...mergedAdminsMap.get(key), ...a });
          }
        });

        const finalMergedAdmins = Array.from(mergedAdminsMap.values());
        setSecondaryAdmins(finalMergedAdmins);
        try {
          localStorage.setItem('pasma_secondary_admins', JSON.stringify(finalMergedAdmins));
        } catch (lsErr) {}

        if (refreshTrigger > 0) {
          setSuccessMessage(`Données du système et des établissements actualisées en direct (${new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })})`);
        }
      } catch (err) {
        console.warn("System data loading encountered a non-fatal warning:", err);
      } finally {
        setLoading(false);
        setIsRefreshing(false);
      }
    };

    loadSystemData();
  }, [refreshTrigger]);

  const handleWriteSystemLog = async (type: string, description: string, amount: number = 0, schoolId: string = 'system') => {
    const logId = `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    const nowIso = new Date().toISOString();
    const logInvoice: Invoice = {
      id: logId,
      studentId: 'system_log',
      parentId: schoolId,
      title: description,
      amount: amount,
      dueDate: type,
      status: 'Paid',
      paymentDate: nowIso,
      provider: 'Jacques Bene Mbama',
      amountPaid: 0,
      transactionId: 'SYS_SEC_LOG'
    };

    // 1. Immediately cache in local system logs
    try {
      const stored = localStorage.getItem('pasma_system_logs');
      const list = stored ? JSON.parse(stored) : [];
      list.unshift(logInvoice);
      if (list.length > 200) list.pop();
      localStorage.setItem('pasma_system_logs', JSON.stringify(list));
    } catch (lsErr) {
      console.warn("Could not cache system log locally:", lsErr);
    }

    // 2. Persist to Firestore invoices collection
    try {
      if (!auth.currentUser) {
        try {
          await loginAnonymously();
        } catch (authErr) {
          // Graceful fallback
        }
      }

      await setDoc(doc(db, 'invoices', logId), logInvoice);
    } catch (e: any) {
      console.warn("Notice: Firestore system log write synced to local storage:", e?.message || e);
    }
  };

  const handlePromoteToDeputy = async (admin: any) => {
    if (!admin) return;

    const adminKey = admin.id || admin.email;
    setIsPromotingId(adminKey);
    setErrorMessage(null);

    const promotedAdmin = {
      ...admin,
      role: 'deputy',
      status: 'active',
      privileges: [
        'audit_system',
        'schools_read_write',
        'financial_oversight',
        'webhook_monitor',
        'logs_extended_export'
      ],
      promotedAt: new Date().toISOString(),
      promotedBy: activeOperatorEmail || 'jacquesbene301@gmail.com'
    };

    // 1. Immediately update local state
    const updatedList = secondaryAdmins.map((a) => {
      if (a.id === admin.id || (a.email && admin.email && a.email.toLowerCase().trim() === admin.email.toLowerCase().trim())) {
        return promotedAdmin;
      }
      return a;
    });
    setSecondaryAdmins(updatedList);

    // 2. Persist to localStorage
    try {
      localStorage.setItem('pasma_secondary_admins', JSON.stringify(updatedList));
    } catch (lsErr) {
      console.warn("LocalStorage promotion error:", lsErr);
    }

    // 3. Update Firestore 'super_admins' collection
    try {
      const docId = admin.id || admin.email.toLowerCase().trim();
      await setDoc(doc(db, 'super_admins', docId), promotedAdmin, { merge: true });
      const sanId = sanitizeFirestoreId(docId);
      if (sanId !== docId) {
        await setDoc(doc(db, 'super_admins', sanId), { ...promotedAdmin, id: sanId }, { merge: true });
      }
    } catch (fsErr) {
      console.warn("Firestore super_admins promotion notice (cached locally):", fsErr);
    }

    // 4. Log in System Audit Logs
    try {
      await handleWriteSystemLog(
        'PROMOTE_SUPER_ADMIN',
        `Promotion au statut de Superviseur Adjoint avec privilèges étendus : ${admin.name} (${admin.email})`,
        0
      );
    } catch (logErr) {
      console.warn("Log write notice:", logErr);
    }

    setIsPromotingId(null);
    setSuccessMessage(`Promotion validée avec succès : ${admin.name} (${admin.email}) dispose désormais des privilèges étendus de Superviseur Adjoint.`);
    setRefreshTrigger((p) => p + 1);
  };

  const handleRevokeAdmin = async (admin: any) => {
    if (!admin) return;

    const adminKey = admin.id || admin.email;
    setIsRevokingId(adminKey);
    setErrorMessage(null);

    // 1. Remove from local state
    const updated = secondaryAdmins.filter(
      (a) => a.id !== admin.id && a.email?.toLowerCase().trim() !== admin.email?.toLowerCase().trim()
    );
    setSecondaryAdmins(updated);

    // 2. Remove from LocalStorage
    try {
      localStorage.setItem('pasma_secondary_admins', JSON.stringify(updated));
    } catch (lsErr) {
      console.warn("LocalStorage notice:", lsErr);
    }

    // 3. Delete from Firestore 'super_admins' collection
    try {
      if (admin.id) await deleteDoc(doc(db, 'super_admins', admin.id));
      if (admin.email) {
        const cleanEmail = admin.email.toLowerCase().trim();
        await deleteDoc(doc(db, 'super_admins', cleanEmail));
        await deleteDoc(doc(db, 'super_admins', sanitizeFirestoreId(cleanEmail)));
      }
    } catch (e: any) {
      console.warn("Firestore delete notice (handled via local state):", e);
    }

    // 4. Log in System Audit Logs
    try {
      await handleWriteSystemLog(
        'REVOKE_SUPER_ADMIN',
        `Révocation de l'accès super-admin pour : ${admin.name} (${admin.email}) [${admin.role === 'deputy' ? 'Superviseur Adjoint' : 'Admin Secondaire'}]`,
        0
      );
    } catch (logErr) {
      console.warn("Log write notice:", logErr);
    }

    // 5. Automatic Security Email Notification to Primary Super-Admin (jacquesbene301@gmail.com)
    let emailSentNote = "";
    try {
      const response = await fetch('/api/send-admin-revocation-alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          primaryAdminEmail: 'jacquesbene301@gmail.com',
          revokedAdminName: admin.name,
          revokedAdminEmail: admin.email,
          revokedAdminRole: admin.role || 'secondary',
          operatorEmail: activeOperatorEmail || 'jacquesbene301@gmail.com',
          timestamp: new Date().toISOString(),
          reason: "Révocation de sécurité initiée depuis le SuperAdminDashboard"
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          emailSentNote = " 📧 Une alerte de sécurité e-mail automatique a été transmise à jacquesbene301@gmail.com.";
        }
      }
    } catch (emailErr) {
      console.warn("Notice: Security alert email dispatch:", emailErr);
    }

    setIsRevokingId(null);
    setAdminToRevoke(null);
    setSuccessMessage(`Les privilèges de l'administrateur ${admin.name} (${admin.email}) ont été révoqués avec succès.${emailSentNote}`);
    setRefreshTrigger((p) => p + 1);
  };

  const handleCreateSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!schoolName || !finName || !finPhone || !finPassword) {
      setErrorMessage("Veuillez remplir au moins le nom scolaire, le gérant de finance et son mot de passe.");
      return;
    }

    setSubmitting(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      if (!currentUserUid) {
        throw new Error("Missing or insufficient permissions : Administrateur non authentifié.");
      }

      // Check system quota: maximum of 25 schools allowed in this demo environment to prevent abuse
      let totalSchools = 0;
      try {
        const snapshot = await getDocs(collection(db, 'establishments'));
        totalSchools = snapshot.size;
      } catch (err: any) {
        console.warn("Could not check global schools quota from Firestore, using state backup:", err);
        // Resilient fallback using the active list from state to prevent blocking the super admin
        totalSchools = schools.length;
      }

      if (totalSchools >= 25) {
        throw new Error("Quota système atteint : La limite globale du serveur de démonstration est fixée à 25 établissements scolaires pour éviter les abus.");
      }

      // Ensure active Firebase Auth session so request.auth != null in Firestore rules
      if (!auth.currentUser) {
        try {
          await loginAnonymously();
        } catch (authErr) {
          console.warn("Failed to establish anonymous Firebase Auth session:", authErr);
        }
      }

      const newSchoolId = `sch_${Date.now()}`;
      
      // Determine real Firestore authenticated user ID to satisfy security rules
      const firestoreOwnerId = auth.currentUser?.uid || currentUserUid || 'sys_admin_jacques';

      // 1. Save school to 'establishments'
      const estDoc: Establishment = {
        id: newSchoolId,
        name: schoolName.trim(),
        cotisationAmount: Number(cotisationAmount),
        financialGoal: Number(financialGoal),
        finManagerName: finName.trim(),
        finManagerPhone: finPhone.trim(),
        finManagerPassword: finPassword.trim(),
        pedManagerName: pedName.trim() || 'Principal Responsable Pédagogique',
        pedManagerPhone: pedPhone.trim() || '',
        pedManagerPassword: pedPassword.trim() || '1234',
        schoolYear,
        ownerId: firestoreOwnerId
      };

      // Write establishment document directly with clean payload
      try {
        await setDoc(doc(db, 'establishments', newSchoolId), cleanPayload(estDoc));
        setDbSchoolIds(prev => new Set(prev).add(newSchoolId));
      } catch (estWriteErr: any) {
        console.warn("Firestore establishment setDoc failed (proceeding with local fallback):", estWriteErr);
        logAuthError({
          errorMessage: estWriteErr?.message || "Missing or insufficient permissions during establishment creation",
          errorCode: estWriteErr?.code || 'permission-denied',
          action: 'SET_DOC_ESTABLISHMENT_ADMIN',
          component: 'SuperAdminDashboard',
          schoolName: schoolName.trim(),
          schoolId: newSchoolId
        });
      }

      // Sync both local and Firestore cache
      saveAndSyncEstablishment(estDoc, true).catch(err => console.warn('SuperAdmin saveAndSyncEstablishment note:', err));

      const batch = writeBatch(db);

      // 2. Save settings to 'invoices'
      const budgetLines = [
        { id: 'bl_1', name: 'Soutien Pédagogique et Matériel Didactique', allocatedAmount: Math.round(financialGoal * 0.3), description: 'Frais de craie, vacataires, etc.' },
        { id: 'bl_2', name: 'Aménagement & Réparations', allocatedAmount: Math.round(financialGoal * 0.25), description: 'Tables-bancs, entretien' },
        { id: 'bl_3', name: 'Santé et Hygiène', allocatedAmount: Math.round(financialGoal * 0.15), description: 'Secourisme, eau potable' },
        { id: 'bl_4', name: 'Activités Périscolaires FENASSCO', allocatedAmount: Math.round(financialGoal * 0.15), description: 'Compétitions de sport' },
        { id: 'bl_5', name: 'Fonds d\'Administration Générale', allocatedAmount: Math.round(financialGoal * 0.15), description: 'Frais divers de bureau' }
      ];

      batch.set(doc(db, 'invoices', `${newSchoolId}_settings`), {
        id: 'apee_settings',
        studentId: 'apee_settings',
        parentId: newSchoolId,
        title: schoolName.trim(),
        amount: Number(cotisationAmount),
        dueDate: schoolYear,
        status: 'Paid',
        amountPaid: Number(financialGoal),
        budgetLinesList: JSON.stringify(budgetLines),
        finManagerName: finName.trim(),
        finManagerPhone: finPhone.trim(),
        finManagerPassword: finPassword.trim(),
        pedManagerName: pedName.trim() || 'Principal Responsable Pédagogique',
        pedManagerPhone: pedPhone.trim() || '',
        pedManagerPassword: pedPassword.trim() || '1234'
      });

      // 3. Seed 2 initial demo students
      const student1Id = `stu_lucas_${newSchoolId.slice(4, 10)}`;
      const student2Id = `stu_chloe_${newSchoolId.slice(4, 10)}`;

      const s1: Student = {
        id: student1Id,
        parentId: newSchoolId,
        name: 'Lucas Martin',
        grade: 'CM2',
        classRoom: 'Classe CM2-A de M. Picard',
        avatar: '👦',
        teacherName: 'M. Jean Picard',
        teacherEmail: 'jean.picard@pasma.sys',
        dob: '2016-04-12'
      };

      const s2: Student = {
        id: student2Id,
        parentId: newSchoolId,
        name: 'Chloé Martin',
        grade: 'CE2',
        classRoom: 'Classe CE2-B de Mme Laurent',
        avatar: '👧',
        teacherName: 'Mme Sophie Laurent',
        teacherEmail: 'sophie.laurent@pasma.sys',
        dob: '2018-09-21'
      };

      batch.set(doc(db, 'students', student1Id), s1);
      batch.set(doc(db, 'students', student2Id), s2);
      
      // Pre-populate offline local cache in case of write permission or network restrictions
      try {
        const studentList = [s1, s2];
        const settingsInvoice = {
          id: 'apee_settings',
          studentId: 'apee_settings',
          parentId: newSchoolId,
          title: schoolName.trim(),
          amount: Number(cotisationAmount),
          dueDate: schoolYear,
          status: 'Paid',
          amountPaid: Number(financialGoal),
          budgetLinesList: JSON.stringify(budgetLines),
          finManagerName: finName.trim(),
          finManagerPhone: finPhone.trim(),
          finManagerPassword: finPassword.trim(),
          pedManagerName: pedName.trim() || 'Principal Responsable Pédagogique',
          pedManagerPhone: pedPhone.trim() || '',
          pedManagerPassword: pedPassword.trim() || '1234'
        };
        const invoiceList = [settingsInvoice];

        localStorage.setItem(`pasma_students_${newSchoolId}`, JSON.stringify(studentList));
        localStorage.setItem(`pasma_invoices_${newSchoolId}`, JSON.stringify(invoiceList));
        
        // Add to local-only global listings
        const existingEstsStr = localStorage.getItem('pasma_local_establishments');
        const existingEsts = existingEstsStr ? JSON.parse(existingEstsStr) : [];
        existingEsts.push(estDoc);
        localStorage.setItem('pasma_local_establishments', JSON.stringify(existingEsts));

        const existingStudentsStr = localStorage.getItem('pasma_local_students');
        const existingStudents = existingStudentsStr ? JSON.parse(existingStudentsStr) : [];
        existingStudents.push(...studentList);
        localStorage.setItem('pasma_local_students', JSON.stringify(existingStudents));

        const existingInvoicesStr = localStorage.getItem('pasma_local_invoices');
        const existingInvoices = existingInvoicesStr ? JSON.parse(existingInvoicesStr) : [];
        existingInvoices.push(...invoiceList);
        localStorage.setItem('pasma_local_invoices', JSON.stringify(existingInvoices));
      } catch (cacheErr) {
        console.warn("Failed to pre-populate local cache from admin:", cacheErr);
      }

      // Commit all documents atomically
      try {
        await batch.commit();
        setDbSchoolIds(prev => new Set(prev).add(newSchoolId));
      } catch (commitErr: any) {
        console.warn("Firestore batch write restricted (Missing or insufficient permissions), proceeding with local fallback:", commitErr);
        // Log the error to logs_auth for administrator diagnosis
        logAuthError({
          errorMessage: commitErr?.message || "Missing or insufficient permissions during batch commit of new school by Super-Admin",
          errorCode: commitErr?.code || 'permission-denied',
          action: 'BATCH_COMMIT_SCHOOL',
          component: 'SuperAdminDashboard',
          schoolName: schoolName.trim(),
          schoolId: newSchoolId,
          details: `Cotisation: ${cotisationAmount}, Goal: ${financialGoal}`
        });
      }

      // 4. Log actions
      await handleWriteSystemLog(
        'CREATE_SCHOOL', 
        `Création de l'établissement: ${schoolName.trim()} (${schoolYear}) avec un objectif de ${Number(financialGoal).toLocaleString()} FCFA.`,
        Number(financialGoal),
        newSchoolId
      );

      // Reset values
      setSchoolName('');
      setFinName('');
      setFinPhone('');
      setFinPassword('');
      setPedName('');
      setPedPhone('');
      setPedPassword('');
      
      setSuccessMessage(`L'établissement ${schoolName} a été créé avec succès avec ses élèves par défaut !`);
      setIsCreateOpen(false);
      setRefreshTrigger(p => p + 1);
    } catch (err: any) {
      console.error("Erreur lors de la création de l'établissement par l'admin:", err);
      let errMsg = `Échec de la création : ${err.message || err}`;
      
      const isPermissionDenied = err?.code === 'permission-denied' || 
                                 err?.message?.includes('permission') || 
                                 err?.message?.includes('Permission') || 
                                 err?.message?.includes('insufficient');

      if (isPermissionDenied) {
        errMsg = "🔒 Autorisation refusée (Missing or insufficient permissions) : Votre compte n'est pas autorisé à créer de nouveaux établissements, ou le quota de la base de données Firestore a été dépassé. Veuillez vérifier vos habilitations.";
        
        // Log permission denial event
        logAuthError({
          errorMessage: err?.message || "Missing or insufficient permissions during school validation / check by Super-Admin",
          errorCode: err?.code || 'permission-denied',
          action: 'CREATE_SCHOOL_FLOW',
          component: 'SuperAdminDashboard',
          schoolName: schoolName.trim(),
          schoolId: `sch_failed_${Date.now()}`,
          details: `Cotisation: ${cotisationAmount}, Goal: ${financialGoal}`
        });
      }
      
      setErrorMessage(errMsg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteSchool = async (schoolId: string, name: string) => {
    if (!window.confirm(`⚠️ SUPPRESSION IRRÉVERSIBLE !\nÊtes-vous absolument sûr de vouloir supprimer définitivement l'établissement "${name}" ?\nToutes les données associées ne seront plus consultables.`)) {
      return;
    }

    try {
      const currentSelected = localStorage.getItem('portal_selected_school_id') || sessionStorage.getItem('portal_selected_school_id');
      const sanitizedId = sanitizeFirestoreId(schoolId);
      const isCurrentlySelected = currentSelected === schoolId || currentSelected === sanitizedId;

      // 1. Delete from establishments & purge local cache & store in pasma_deleted_schools
      await deleteAndPurgeSchool(schoolId);

      // Explicitly clear portal_selected_school_id and reset selection keys from localStorage
      if (isCurrentlySelected || !currentSelected) {
        localStorage.removeItem('portal_selected_school_id');
        sessionStorage.removeItem('portal_selected_school_id');
        localStorage.removeItem('portal_user_role');
        localStorage.removeItem('portal_parent_details');
        localStorage.removeItem('portal_teacher_details');
        localStorage.removeItem('portal_manager_details');
        localStorage.removeItem('portal_login_timestamp');
        sessionStorage.removeItem('portal_user_role');
      }

      // 2. Log deletion
      await handleWriteSystemLog(
        'DELETE_SCHOOL',
        `Suppression définitive de l'établissement : ${name}`,
        0,
        schoolId
      );

      // Instantly filter from state for reactive UI feedback
      setSchools(prev => prev.filter(s => s.id !== schoolId && s.id !== sanitizedId));

      setSuccessMessage(`L'établissement "${name}" a été supprimé du registre de surveillance Pasma-sys.`);
      setRefreshTrigger(p => p + 1);

      // If the deleted school was currently selected, trigger reload so app initializes cleanly at school selection view
      if (isCurrentlySelected) {
        window.location.reload();
      }
    } catch (err: any) {
      alert(`Erreur de suppression: ${err.message || err}`);
    }
  };

  const handleToggleSuspendSchool = async (schoolId: string, name: string, currentStatus?: 'active' | 'suspended') => {
    const isSuspended = currentStatus === 'suspended';
    const confirmMsg = isSuspended 
      ? `Êtes-vous sûr de vouloir réactiver l'accès de l'établissement "${name}" ?`
      : `⚠️ SUSPENSION DE SERVICE !\nÊtes-vous sûr de vouloir suspendre temporairement l'accès de l'établissement "${name}" ?\nLes administrateurs et parents ne pourront plus se connecter.`;
      
    if (!window.confirm(confirmMsg)) {
      return;
    }

    try {
      const schoolRef = doc(db, 'establishments', schoolId);
      const newStatus = isSuspended ? 'active' : 'suspended';
      await setDoc(schoolRef, { status: newStatus }, { merge: true });

      await handleWriteSystemLog(
        'SETTINGS_CHANGE',
        `${isSuspended ? "Réactivation" : "Suspension temporaire"} de l'établissement : ${name}`,
        0,
        schoolId
      );

      setSchools(prev => prev.map(s => s.id === schoolId ? { ...s, status: newStatus } : s));
      setSuccessMessage(`L'établissement "${name}" a été ${isSuspended ? "réactivé" : "suspendu"} avec succès.`);
      setRefreshTrigger(p => p + 1);
    } catch (err: any) {
      alert(`Erreur lors de la modification du statut : ${err.message || err}`);
    }
  };

  const handleCreateManualLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualLogTitle) return;

    try {
      await handleWriteSystemLog(manualLogType, manualLogTitle, 0, 'system');
      setManualLogTitle('');
      setSuccessMessage("Log administratif enregistré avec succès !");
      setRefreshTrigger(p => p + 1);
    } catch (e: any) {
      alert(e.message);
    }
  };

  const handleExportLogsCSV = () => {
    // CSV Header row
    const headers = [
      "ID DU LOG",
      "DATE ET HEURE",
      "TYPE D'EVENEMENT",
      "DESCRIPTION",
      "ETABLISSEMENT CONCERNE",
      "MONTANT (FCFA)",
      "AUTEUR / INITIATEUR"
    ];

    // Map system logs to CSV array of arrays
    const rows = systemLogs.map(log => {
      const schoolName = schools.find(s => s.id === log.parentId)?.name || (log.parentId === 'system' ? 'Système Global' : log.parentId);
      const formattedDate = new Date(log.paymentDate).toLocaleString('fr-FR');
      const escapeCsvVal = (val: string | number) => {
        const str = String(val ?? '');
        return `"${str.replace(/"/g, '""')}"`;
      };

      return [
        escapeCsvVal(log.id),
        escapeCsvVal(formattedDate),
        escapeCsvVal(log.dueDate),
        escapeCsvVal(log.title),
        escapeCsvVal(schoolName),
        log.amount,
        escapeCsvVal(log.provider)
      ];
    });

    const csvContent = [
      headers.join(';'),
      ...rows.map(r => r.join(';'))
    ].join('\n');

    const blob = new Blob(["\uFEFF" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `journal_audit_systeme_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Computations & Real Data Resolution Helpers for Establishments
  const getSchoolRealParents = (schoolId: string): any[] => {
    const parentsMap = new Map<string, any>();

    // 1. From allInvoices state (Firestore + local invoices)
    const schoolInvoices = allInvoices.filter(
      inv => inv.parentId === schoolId && 
      !['apee_expense', 'apee_log', 'apee_other_revenue', 'apee_settings', 'system_log'].includes(inv.studentId)
    );
    schoolInvoices.forEach(inv => {
      parentsMap.set(inv.id, {
        id: inv.id,
        name: inv.title,
        phone: inv.phone || '',
        email: inv.email || '',
        amountPaid: Number(inv.amountPaid) || 0,
        totalDue: Number(inv.amount) || 0,
        studentsList: inv.studentsList
      });
    });

    // 2. From localStorage apee_parents_cache_<schoolId> or apee_parents_<schoolId>
    try {
      const cachedStr = localStorage.getItem(`apee_parents_cache_${schoolId}`) || localStorage.getItem(`apee_parents_${schoolId}`);
      if (cachedStr) {
        const cached = JSON.parse(cachedStr);
        if (Array.isArray(cached)) {
          cached.forEach((p: any) => {
            if (p && p.id) {
              parentsMap.set(p.id, {
                id: p.id,
                name: p.name || p.title,
                phone: p.phone || '',
                email: p.email || '',
                amountPaid: p.totalPaid !== undefined ? Number(p.totalPaid) : (Number(p.amountPaid) || 0),
                totalDue: p.totalDue !== undefined ? Number(p.totalDue) : (Number(p.amount) || 0),
                studentsList: p.students ? JSON.stringify(p.students) : p.studentsList
              });
            }
          });
        }
      }
    } catch (e) {
      // ignore
    }

    return Array.from(parentsMap.values());
  };

  const getSchoolRealPupilsCount = (schoolId: string, parents: any[]): number => {
    const pupilSet = new Set<string>();

    // 1. Standalone students from allStudents (Firestore / local)
    allStudents
      .filter(s => s.parentId === schoolId)
      .forEach(s => {
        if (s.id || s.name) pupilSet.add(s.id || s.name);
      });

    // 2. Students attached inside parent profiles
    parents.forEach(p => {
      try {
        if (p.studentsList) {
          const parsed = JSON.parse(p.studentsList);
          if (Array.isArray(parsed)) {
            parsed.forEach((std: any) => {
              const key = std.id || `${std.name}_${std.classRoom || ''}`;
              if (key) pupilSet.add(key);
            });
          }
        }
      } catch (e) {
        // ignore
      }
    });

    return pupilSet.size;
  };

  const getSchoolRealFinancialGoal = (school: Establishment): number => {
    // 1. Explicit financialGoal on establishment object
    if (school.financialGoal && Number(school.financialGoal) > 0) {
      return Number(school.financialGoal);
    }

    // 2. Settings stored in Firestore strictly matching THIS school ID
    const settingsInv = allInvoices.find(inv => 
      (inv.parentId === school.id || inv.id === `${school.id}_settings` || (inv.id === 'apee_settings' && inv.parentId === school.id)) && 
      (inv.studentId === 'apee_settings' || inv.id.endsWith('_settings'))
    );
    if (settingsInv) {
      if (settingsInv.budgetLinesList) {
        try {
          const lines = JSON.parse(settingsInv.budgetLinesList);
          if (Array.isArray(lines) && lines.length > 0) {
            const sumLines = lines.reduce((acc: number, l: any) => acc + (Number(l.allocatedAmount) || 0), 0);
            if (sumLines > 0) return sumLines;
          }
        } catch (e) {
          // ignore
        }
      }
      if (settingsInv.amountPaid && Number(settingsInv.amountPaid) > 0 && Number(settingsInv.amountPaid) !== 5000000) {
        return Number(settingsInv.amountPaid);
      }
    }

    // 3. Settings stored in local cache strictly for this school
    try {
      const cachedSettingsStr = localStorage.getItem(`apee_settings_cache_${school.id}`) || localStorage.getItem(`apee_settings_${school.id}`);
      if (cachedSettingsStr) {
        const settings = JSON.parse(cachedSettingsStr);
        if (settings) {
          if (Array.isArray(settings.budgetLines) && settings.budgetLines.length > 0) {
            const sumLines = settings.budgetLines.reduce((acc: number, l: any) => acc + (Number(l.allocatedAmount) || 0), 0);
            if (sumLines > 0) return sumLines;
          }
          if (Number(settings.financialGoal) > 0 && Number(settings.financialGoal) !== 5000000) {
            return Number(settings.financialGoal);
          }
        }
      }
    } catch (e) {
      // ignore
    }

    // 4. Calculate dynamically based on cotisation & student count
    const cotisation = getSchoolRealCotisationAmount(school);
    const parents = getSchoolRealParents(school.id);
    const students = getSchoolRealPupilsCount(school.id, parents);
    if (cotisation > 0 && students > 0) {
      return cotisation * students;
    }

    return 0;
  };

  const getSchoolRealCotisationAmount = (school: Establishment): number => {
    // 1. Explicit cotisationAmount on establishment object
    if (school.cotisationAmount && Number(school.cotisationAmount) > 0) {
      return Number(school.cotisationAmount);
    }

    // 2. Settings stored in Firestore strictly matching THIS school ID
    const settingsInv = allInvoices.find(inv => 
      (inv.parentId === school.id || inv.id === `${school.id}_settings` || (inv.id === 'apee_settings' && inv.parentId === school.id)) && 
      (inv.studentId === 'apee_settings' || inv.id.endsWith('_settings'))
    );
    if (settingsInv && settingsInv.amount && Number(settingsInv.amount) > 0) {
      return Number(settingsInv.amount);
    }

    // 3. Settings stored in local cache strictly for this school
    try {
      const cachedSettingsStr = localStorage.getItem(`apee_settings_cache_${school.id}`) || localStorage.getItem(`apee_settings_${school.id}`);
      if (cachedSettingsStr) {
        const settings = JSON.parse(cachedSettingsStr);
        if (settings && Number(settings.cotisationAmount) > 0) {
          return Number(settings.cotisationAmount);
        }
      }
    } catch (e) {
      // ignore
    }

    return 0;
  };

  const getSchoolRealCollectedFunds = (schoolId: string, parents: any[]): number => {
    let sum = 0;

    // 1. Sum payments from real parents
    parents.forEach(p => {
      sum += Number(p.amountPaid) || 0;
    });

    // 2. Other revenues from Firestore
    const otherRevenues = allInvoices.filter(inv => inv.parentId === schoolId && inv.studentId === 'apee_other_revenue');
    otherRevenues.forEach(inv => {
      sum += Number(inv.amountPaid || inv.amount) || 0;
    });

    // 3. Other revenues from local cache
    try {
      const cachedRevenuesStr = localStorage.getItem(`apee_other_revenues_cache_${schoolId}`);
      if (cachedRevenuesStr) {
        const revenues = JSON.parse(cachedRevenuesStr);
        if (Array.isArray(revenues)) {
          revenues.forEach((r: any) => {
            if (r && r.amount && !otherRevenues.some(inv => inv.id === r.id)) {
              sum += Number(r.amount) || 0;
            }
          });
        }
      }
    } catch (e) {
      // ignore
    }

    return sum;
  };

  const totalSchools = schools.length;
  const registeredSchoolCount = schools.filter(s => 
    dbSchoolIds.has(s.id) || dbSchoolIds.has(sanitizeFirestoreId(s.id))
  ).length;
  
  // Real statistical summaries calculated across all establishments
  const totalStudents = schools.reduce((acc, sch) => {
    const parents = getSchoolRealParents(sch.id);
    return acc + getSchoolRealPupilsCount(sch.id, parents);
  }, 0);

  const totalParents = schools.reduce((acc, sch) => {
    const parents = getSchoolRealParents(sch.id);
    return acc + parents.length;
  }, 0);

  const totalFundsCollected = schools.reduce((acc, sch) => {
    const parents = getSchoolRealParents(sch.id);
    return acc + getSchoolRealCollectedFunds(sch.id, parents);
  }, 0);

  const totalFundsRequired = schools.reduce((acc, sch) => acc + getSchoolRealFinancialGoal(sch), 0);
  const globalRate = totalFundsRequired > 0 ? Math.round((totalFundsCollected / totalFundsRequired) * 100) : 0;

  // Filtered Schools
  const filteredSchools = schools.filter(sch => {
    const q = (searchQuery || '').toLowerCase();
    return (sch.name || '').toLowerCase().includes(q) ||
           (sch.id || '').toLowerCase().includes(q) ||
           (sch.finManagerName || '').toLowerCase().includes(q);
  });

  // Dynamic user data resolving for super-admin
  const currentUserEmail = auth.currentUser?.email 
    || (currentUserUid === 'sys_admin_jacques' ? 'jacquesbene301@gmail.com' : (currentUserUid?.includes('@') ? currentUserUid : 'jacquesbene301@gmail.com'));
  const currentOperatorName = isPrimarySuperAdmin 
    ? 'JACQUES BENE MBAMA'
    : (secondaryAdmins.find(admin => admin.email?.toLowerCase().trim() === currentUserEmail.toLowerCase().trim())?.name?.toUpperCase() || 'SUPERVISEUR ADJOINT');

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 font-sans pb-16">
      {/* Super Top Admin Banner */}
      <div className="bg-slate-950 text-amber-400 font-mono text-[10.5px] px-6 py-2 border-b border-amber-500/20 flex flex-wrap items-center justify-between gap-2 shadow-inner">
        <div className="flex items-center gap-1.5 font-bold">
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping shrink-0" />
          <span>PORTAIL EXCLUSIF DE SURVEILLANCE SYSTÈME PASMA-SYS {isPrimarySuperAdmin ? "(OPÉRATEUR PRINCIPAL)" : "(OPÉRATEUR ADJOINT)"}</span>
        </div>
        <div className="flex items-center gap-4 text-[10px] text-slate-350">
          <div>OPÉRATEUR: <span className="font-extrabold text-white">{currentOperatorName}</span></div>
          <div>EMAIL: <span className="font-extrabold text-white">{currentUserEmail}</span></div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 pt-6">
        {/* Navigation / Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={onBackToPortal}
              className="p-3 bg-white hover:bg-slate-50 text-slate-800 rounded-2xl transition border border-slate-200 shadow-sm flex items-center justify-center cursor-pointer"
              title="Retourner à l'accueil"
            >
              <ArrowLeft className="h-4.5 w-4.5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <Building2 className="h-6 w-6 text-slate-800" />
                <h1 className="text-2xl font-black tracking-tight text-slate-950">
                  {isPrimarySuperAdmin ? "Superviseur Principal" : "Superviseur Adjoint"}
                </h1>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {isPrimarySuperAdmin
                  ? "Contrôle global, pilotage suprême et assistance technique des établissements scolaires"
                  : "Accès d'audit supervisé, contrôle analytique et assistance technique déléguée du système"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto self-stretch md:self-auto justify-end flex-wrap">
            <button
              onClick={handleSyncSchoolsToDb}
              disabled={loading || isSyncing}
              className="px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-2xl font-bold text-xs shadow-3xs flex items-center gap-1.5 cursor-pointer disabled:opacity-60 transition-all active:scale-95"
              title="Synchroniser et enregistrer toutes les écoles en cache dans la BD Firestore"
            >
              <Sparkles className={`h-3.5 w-3.5 text-emerald-600 ${isSyncing ? 'animate-spin' : ''}`} />
              {isSyncing ? "Enregistrement BD..." : "Synchroniser BD"}
            </button>
            <button
              onClick={() => setRefreshTrigger(p => p + 1)}
              disabled={loading || isRefreshing}
              className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 rounded-2xl border border-slate-200 font-bold text-xs shadow-3xs flex items-center gap-1.5 cursor-pointer disabled:opacity-60 transition-all active:scale-95"
              title="Actualiser les données du système et des établissements"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isRefreshing ? 'animate-spin text-indigo-600' : ''}`} />
              {isRefreshing ? "Actualisation..." : "Actualiser"}
            </button>
            <button
              onClick={() => setIsCreateOpen(true)}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-extrabold text-xs shadow-md shadow-indigo-100 flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="h-4 w-4 shrink-0" /> Créer un Établissement
            </button>
          </div>
        </div>

        {/* Global Success / Critical Indicator */}
        {successMessage && (
          <div className="bg-emerald-50 border border-emerald-150 p-4 rounded-2xl text-xs text-emerald-900 mb-6 flex items-center justify-between gap-3 animate-fadeIn">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
              <p className="font-medium">{successMessage}</p>
            </div>
            <button onClick={() => setSuccessMessage(null)} className="text-emerald-500 hover:text-emerald-700 p-1 rounded-lg">
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        {/* STATS DE SURVEILLANCE GLOBALE (BENTO GRID) */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4.5 mb-8">
          
          <div className="bg-white border border-slate-200/80 p-5 rounded-3xl space-y-2 relative overflow-hidden shadow-3xs">
            <span className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl inline-flex">
              <Building2 className="h-4.5 w-4.5" />
            </span>
            <div>
              <p className="text-[10px] text-slate-450 uppercase tracking-wider font-extrabold">Établissements</p>
              <p className="text-2xl font-black text-slate-900 tracking-tight mt-0.5">{totalSchools}</p>
            </div>
            <div 
              className="bg-emerald-50 text-emerald-700 text-[9.5px] font-extrabold px-2 py-0.5 rounded-md absolute top-4 right-4 border border-emerald-200/80 flex items-center gap-1 shadow-2xs"
              title={`${registeredSchoolCount} établissement(s) effectivement présent(s) en base de données Firestore`}
            >
              <Database className="h-2.5 w-2.5 text-emerald-600 shrink-0" />
              <span>{registeredSchoolCount} en BD</span>
            </div>
          </div>

          <div className="bg-white border border-slate-200/80 p-5 rounded-3xl space-y-2 relative overflow-hidden shadow-3xs">
            <span className="p-3 bg-sky-50 text-sky-600 rounded-2xl inline-flex">
              <Users className="h-4.5 w-4.5" />
            </span>
            <div>
              <p className="text-[10px] text-slate-450 uppercase tracking-wider font-extrabold">Parents Connectés</p>
              <p className="text-2xl font-black text-slate-900 tracking-tight mt-0.5">{totalParents}</p>
            </div>
            <span className="text-[10px] text-slate-400 font-medium block">Adhérents APEE</span>
          </div>

          <div className="bg-white border border-slate-200/80 p-5 rounded-3xl space-y-2 relative overflow-hidden shadow-3xs">
            <span className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl inline-flex">
              <GraduationCap className="h-4.5 w-4.5" />
            </span>
            <div>
              <p className="text-[10px] text-slate-450 uppercase tracking-wider font-extrabold">Élèves Enregistrés</p>
              <p className="text-2xl font-black text-slate-900 tracking-tight mt-0.5">{totalStudents}</p>
            </div>
            <span className="text-[10px] text-slate-400 font-medium block">Effectif global suivi</span>
          </div>

          <div className="bg-white border border-slate-200/80 p-5 rounded-3xl space-y-2 relative overflow-hidden shadow-3xs">
            <span className="p-3 bg-amber-50 text-amber-600 rounded-2xl inline-flex">
              <Coins className="h-4.5 w-4.5" />
            </span>
            <div>
              <p className="text-[10px] text-slate-450 uppercase tracking-wider font-extrabold font-sans">Cotisations Collectées</p>
              <p className="text-xl font-black text-slate-950 tracking-tight mt-1">{totalFundsCollected.toLocaleString()} FCFA</p>
            </div>
            <span className="text-[10px] text-amber-700 font-extrabold bg-amber-50 px-1.5 py-0.5 rounded-md">APEE Système</span>
          </div>

          <div className="bg-white border border-emerald-100 p-5 rounded-3xl space-y-2 shadow-sm col-span-2 md:col-span-1 border-l-4 border-l-emerald-500">
            <div className="flex items-center justify-between">
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-extrabold">Recouvrement Global</p>
              <span className="text-emerald-600 font-black text-sm flex items-center gap-0.5"><TrendingUp className="h-4 w-4" /> {globalRate}%</span>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-black text-slate-950 tracking-tight">{globalRate}%</p>
              <div className="w-full bg-slate-100 rounded-full h-1.5">
                <div 
                  className="bg-emerald-500 h-1.5 rounded-full" 
                  style={{ width: `${Math.min(globalRate, 100)}%` }}
                />
              </div>
              <p className="text-[9.5px] text-slate-400 font-mono">Cible: {totalFundsRequired.toLocaleString()} FCFA</p>
            </div>
          </div>

        </div>

        {/* MAIN BODY: SPLIT VIEW */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left / Center 2 Columns: Registre des Etablissements */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white border border-slate-200/80 rounded-3xl shadow-3xs overflow-hidden">
              <div className="p-6 border-b border-slate-150 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1.5">
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('schools')}
                      className={`px-4 py-1.5 text-xs font-black rounded-lg transition cursor-pointer border ${
                        activeSubTab === 'schools'
                          ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      🏫 Établissements Supervisés
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('admins')}
                      className={`px-4 py-1.5 text-xs font-black rounded-lg transition cursor-pointer border flex items-center gap-1.5 ${
                        activeSubTab === 'admins'
                          ? 'bg-slate-950 text-amber-400 border-slate-950 shadow-xs'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      🛡️ Super-Admins Adjoints ({secondaryAdmins.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('campay_webhook')}
                      className={`px-4 py-1.5 text-xs font-black rounded-lg transition cursor-pointer border flex items-center gap-1.5 ${
                        activeSubTab === 'campay_webhook'
                          ? 'bg-indigo-950 text-indigo-400 border-indigo-950 shadow-xs'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      🔌 Intégration Campay & Webhook
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('email_infrastructure')}
                      className={`px-4 py-1.5 text-xs font-black rounded-lg transition cursor-pointer border flex items-center gap-1.5 ${
                        activeSubTab === 'email_infrastructure'
                          ? 'bg-slate-900 text-emerald-400 border-slate-900 shadow-xs'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      📧 Infrastructure E-mail & DNS
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('auth_logs')}
                      className={`px-4 py-1.5 text-xs font-black rounded-lg transition cursor-pointer border flex items-center gap-1.5 ${
                        activeSubTab === 'auth_logs'
                          ? 'bg-rose-600 text-white border-rose-700 shadow-xs'
                          : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      🚨 Diagnostic & Logs d'Accès
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 font-medium">
                    {activeSubTab === 'schools'
                      ? "Activez la supervision ou gérez les paramètres d'exploitation"
                      : activeSubTab === 'admins'
                        ? "Gérez et auditez les habilitations d'accès des superviseurs adjoints délégués"
                        : activeSubTab === 'campay_webhook'
                          ? "Simulez, testez et synchronisez en temps réel les webhooks de paiements Campay"
                          : activeSubTab === 'email_infrastructure'
                            ? "Contrôlez les enregistrements DNS (DKIM, CNAME, DMARC) et testez l'expédition d'e-mails"
                            : "Consultez les rapports détaillés des permissions refusées et incidents de sécurité"}
                  </p>
                </div>

                {activeSubTab === 'schools' && (
                  <div className="relative w-full sm:w-64">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                      <Search className="h-4 w-4" />
                    </span>
                    <input
                      type="text"
                      placeholder="Filtrer un établissement..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                    />
                    {searchQuery && (
                      <button onClick={() => setSearchQuery('')} className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                )}
              </div>

              {activeSubTab === 'schools' ? (
                <>
                  {filteredSchools.length === 0 ? (
                    <div className="p-12 text-center text-slate-450 space-y-2">
                      <div className="text-3xl">🏫</div>
                      <p className="font-bold text-sm text-slate-800">Aucun établissement ne correspond à votre recherche</p>
                      <p className="text-xs text-slate-400">Essayez de saisir un autre nom ou créez un nouvel établissement.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100 overflow-x-auto">
                      <table className="w-full text-left text-xs text-slate-600 min-w-[900px]">
                        <thead className="bg-slate-50/50 text-[10.5px] text-slate-450 font-black uppercase tracking-wider border-b border-slate-150">
                          <tr>
                            <th className="px-6 py-3.5">Nom de l'Établissement</th>
                            <th className="px-4 py-3.5">Effectifs</th>
                            <th className="px-4 py-3.5">Fonds & Objectif</th>
                            <th className="px-4 py-3.5">Redevance (1% Portail)</th>
                            <th className="px-4 py-3.5">Responsable & Statut</th>
                            <th className="px-6 py-3.5 text-right font-sans">Supervision Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-medium">
                          {filteredSchools.map((school) => {
                            // Calculate real metrics for school
                            const realParents = getSchoolRealParents(school.id);
                            const parentsCount = realParents.length;
                            const pupilsCount = getSchoolRealPupilsCount(school.id, realParents);
                            const collected = getSchoolRealCollectedFunds(school.id, realParents);
                            const goal = getSchoolRealFinancialGoal(school);
                            const cotisation = getSchoolRealCotisationAmount(school);
                            const progressPercent = goal > 0 ? Math.round((collected / goal) * 100) : 0;

                            const expectedFee = Math.round(collected * 0.01);
                            const paidFee = Math.round(school.portalFeesPaid || 0);
                            const remainingFee = Math.max(0, expectedFee - paidFee);

                            // Detect 3 months cycle alert
                            const hasDebtAlert = remainingFee > 5000;

                            return (
                              <tr key={school.id} className={`hover:bg-slate-50/50 transition ${school.status === 'suspended' ? 'bg-red-50/20' : ''}`}>
                                <td className="px-6 py-4.5">
                                  <div className="flex items-center gap-3">
                                    <img 
                                      src={school.logoUrl || DEFAULT_SCHOOL_LOGO} 
                                      alt="Logo Établissement" 
                                      className="h-9 w-9 object-contain rounded-lg border border-slate-100 bg-slate-50 p-0.5 shrink-0" 
                                      referrerPolicy="no-referrer"
                                    />
                                    <div>
                                      <div className="flex items-center gap-1.5 flex-wrap">
                                        <span className="font-extrabold text-slate-900 text-[12.5px] leading-snug">{school.name}</span>
                                        {/* Badge pour école effectivement enregistrée en base de données */}
                                        {dbSchoolIds.has(school.id) || dbSchoolIds.has(sanitizeFirestoreId(school.id)) ? (
                                          <span 
                                            className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200/80 text-[8.5px] font-black uppercase rounded-md shadow-2xs"
                                            title="Établissement effectivement enregistré et vérifié dans la base de données Firestore"
                                          >
                                            <Database className="h-2.5 w-2.5 text-emerald-600 shrink-0" />
                                            <span className="flex items-center gap-1">
                                              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                                              Enregistré BD
                                            </span>
                                          </span>
                                        ) : (
                                          <span 
                                            className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-slate-100 text-slate-500 border border-slate-200 text-[8.5px] font-bold uppercase rounded-md"
                                            title="Établissement local ou de démonstration (hors base de données)"
                                          >
                                            <CloudOff className="h-2.5 w-2.5 text-slate-400 shrink-0" />
                                            <span>Démo / Local</span>
                                          </span>
                                        )}
                                        {school.status === 'suspended' && (
                                          <span className="px-1.5 py-0.5 bg-rose-100 text-rose-800 text-[8px] font-black uppercase rounded">Suspendu</span>
                                        )}
                                      </div>
                                      <div className="text-[10px] text-slate-400 font-mono mt-0.5 flex items-center gap-1.5">
                                        <span>ID: {school.id}</span>
                                        <span>•</span>
                                        <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-600 font-bold uppercase">{school.schoolYear}</span>
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-4 py-4.5">
                                  <div className="space-y-1 text-slate-800">
                                    <div className="flex items-center gap-1"><Users className="h-3.5 w-3.5 text-slate-400" /> <span className="font-bold">{parentsCount}</span> parents</div>
                                    <div className="flex items-center gap-1"><GraduationCap className="h-3.5 w-3.5 text-slate-400" /> <span className="font-bold">{pupilsCount}</span> élèves</div>
                                  </div>
                                </td>
                                <td className="px-4 py-4.5">
                                  <div className="space-y-1">
                                    <div className="font-black text-slate-900">{collected.toLocaleString()} / {goal > 0 ? `${goal.toLocaleString()} FCFA` : 'Non défini'}</div>
                                    <div className="flex items-center gap-2">
                                      <div className="w-16 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                        <div className="bg-indigo-600 h-1.5 rounded-full" style={{ width: `${Math.min(progressPercent, 100)}%` }} />
                                      </div>
                                      <span className="font-mono text-[9.5px] font-bold text-indigo-600">{progressPercent}%</span>
                                    </div>
                                    <div className="text-[9px] text-slate-400 font-bold">{cotisation.toLocaleString()} FCFA / Adhérent</div>
                                  </div>
                                </td>
                                <td className="px-4 py-4.5">
                                  <div className="space-y-1 font-mono text-slate-800">
                                    <div className="text-[10.5px]">Dû : <span className="font-black text-indigo-950">{expectedFee.toLocaleString()} FCFA</span></div>
                                    <div className="text-[9px] text-emerald-600">Réglé : <span className="font-bold">{paidFee.toLocaleString()} FCFA</span></div>
                                    <div className="text-[9.5px]">
                                      Reste : <span className={`font-black ${remainingFee > 0 ? 'text-amber-600' : 'text-slate-500'}`}>{remainingFee.toLocaleString()} FCFA</span>
                                    </div>
                                    {hasDebtAlert ? (
                                      <div className="inline-flex items-center gap-0.5 text-[8px] bg-amber-50 text-amber-800 border border-amber-150 px-1 py-0.5 rounded uppercase font-black">
                                        <ShieldAlert className="h-2.5 w-2.5" /> Retard &lt; 3 mois
                                      </div>
                                    ) : (
                                      <div className="inline-flex items-center gap-0.5 text-[8px] bg-emerald-50 text-emerald-800 px-1 py-0.5 rounded uppercase font-black">
                                        <CheckCircle className="h-2.5 w-2.5" /> À Jour
                                      </div>
                                    )}
                                  </div>
                                </td>
                                <td className="px-4 py-4.5">
                                  <div className="text-slate-800 space-y-1">
                                    <div>
                                      <div className="font-bold text-[11px] leading-tight">{school.finManagerName || school.directorName || "N/A"}</div>
                                      <div className="text-[10px] text-slate-500 font-mono flex items-center gap-0.5">📞 {school.finManagerPhone || "N/A"}</div>
                                    </div>
                                    <div className="flex items-center gap-1">
                                      <span className={`inline-block w-2 h-2 rounded-full ${school.status === 'suspended' ? 'bg-red-500' : 'bg-emerald-500'}`}></span>
                                      <span className="text-[9px] font-bold uppercase text-slate-500">
                                        {school.status === 'suspended' ? 'Accès Bloqué' : 'Accès Autorisé'}
                                      </span>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-6 py-4.5 text-right font-sans">
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      onClick={() => onSelectSchool(school.id, 'manager', { name: school.finManagerName || school.directorName || 'Gérant Administratif', phone: school.finManagerPhone || 'Administrateur' })}
                                      className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 hover:text-indigo-850 rounded-lg text-[10px] font-black transition cursor-pointer"
                                      title="Se connecter en tant que responsable administratif ou financier de cet établissement"
                                    >
                                      Accès Admin
                                    </button>
                                    <button
                                      onClick={() => setSelectedSchoolForParentImpersonation(school)}
                                      className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 hover:text-emerald-850 rounded-lg text-[10px] font-black transition cursor-pointer"
                                      title="Se connecter en tant que parent d'élève de cet établissement"
                                    >
                                      Accès Parent
                                    </button>
                                    <button
                                      onClick={() => handleToggleSuspendSchool(school.id, school.name, school.status)}
                                      className={`p-1.5 rounded-lg border transition cursor-pointer ${
                                        school.status === 'suspended' 
                                          ? 'bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-700' 
                                          : 'bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-700'
                                      }`}
                                      title={school.status === 'suspended' ? "Réactiver l'accès de cet établissement" : "Suspendre temporairement l'accès de cet établissement"}
                                    >
                                      {school.status === 'suspended' ? <Play className="h-3.5 w-3.5" /> : <Ban className="h-3.5 w-3.5" />}
                                    </button>
                                    {(!isPreprod ? school.id !== 'demo_school_ekali' : true) && (
                                      <button
                                        onClick={() => handleDeleteSchool(school.id, school.name)}
                                        className="p-1.5 bg-white hover:bg-red-50 border border-slate-200 hover:border-red-150 text-slate-400 hover:text-red-600 rounded-lg transition cursor-pointer animate-pulse"
                                        title="ANNULER DÉFINITIVEMENT (Supprimer)"
                                      >
                                        <Trash2 className="h-3.5 w-3.5" />
                                      </button>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              ) : activeSubTab === 'admins' ? (
                <div className="p-6 space-y-6">
                  {/* Informative Banner */}
                  <div className="bg-slate-900 border border-slate-800 text-slate-300 p-4 rounded-2xl flex items-start gap-3">
                    <span className="p-2 bg-slate-950 border border-slate-800 text-amber-400 rounded-xl font-bold shrink-0">🛡️</span>
                    <div className="text-xs leading-relaxed">
                      <p className="font-extrabold text-amber-400 uppercase tracking-wider mb-1">
                        Délégation d'Accès de Supervision (Adjoints & Admins Simples)
                      </p>
                      <p>
                        Seul le Super-Admin Principal <strong className="text-white">jacquesbene301@gmail.com</strong> est en droit de nommer, promouvoir ou révoquer des administrateurs et adjoints de supervision. Les adjoints disposent de privilèges étendus pour la gestion et la surveillance système.
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Secondary Admins List */}
                    <div className="space-y-3.5">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xs font-black uppercase text-slate-450 tracking-wider">
                          Administrateurs & Adjoints ({secondaryAdmins.length})
                        </h3>
                        <span className="text-[10px] text-slate-400 font-bold">
                          {secondaryAdmins.filter(a => a.role === 'deputy').length} adjoint(s) • {secondaryAdmins.filter(a => a.role !== 'deputy').length} simple(s)
                        </span>
                      </div>

                      {secondaryAdmins.length === 0 ? (
                        <div className="p-8 border border-dashed border-slate-200 rounded-2xl text-center text-slate-400 text-xs font-semibold">
                          Aucun Super-Admin secondaire de créé à ce jour.
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {secondaryAdmins.map((admin) => {
                            const isDeputy = admin.role === 'deputy';
                            const adminKey = admin.id || admin.email;
                            return (
                              <div 
                                key={adminKey} 
                                className={`p-3.5 border rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition ${
                                  isDeputy 
                                    ? 'bg-emerald-50/40 border-emerald-200/80 hover:border-emerald-300' 
                                    : 'bg-slate-50 border-slate-150 hover:border-slate-300'
                                }`}
                              >
                                <div className="space-y-1 min-w-0 flex-1">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <p className="font-extrabold text-slate-900 text-[12px] truncate">
                                      {admin.name}
                                    </p>
                                    {isDeputy ? (
                                      <span className="px-2 py-0.5 bg-emerald-100 border border-emerald-200 text-emerald-800 text-[8.5px] font-extrabold rounded-md uppercase tracking-wider flex items-center gap-1">
                                        <ShieldCheck className="h-3 w-3 text-emerald-600" />
                                        Adjoint • Privilèges Étendus
                                      </span>
                                    ) : (
                                      <span className="px-2 py-0.5 bg-amber-50 border border-amber-200 text-amber-800 text-[8.5px] font-extrabold rounded-md uppercase tracking-wider">
                                        Admin Simple (Standard)
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-[10.5px] text-slate-450 font-mono truncate">
                                    {admin.email}
                                  </p>
                                  {admin.accessCode && (
                                    <p className="text-[10px] text-amber-700 font-mono font-bold">
                                      🔑 Code d'accès: {admin.accessCode}
                                    </p>
                                  )}
                                  <div className="flex items-center gap-2 flex-wrap text-[9px] text-slate-450 font-mono">
                                    <span>Créé le {new Date(admin.createdAt || Date.now()).toLocaleDateString()} par Jacques</span>
                                    {admin.promotedAt && (
                                      <span className="text-emerald-700 font-bold">
                                        • Promu le {new Date(admin.promotedAt).toLocaleDateString()}
                                      </span>
                                    )}
                                  </div>
                                </div>

                                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                                  {/* Bouton de promotion vers Adjoint avec privilèges étendus */}
                                  {!isDeputy && isPrimarySuperAdmin && (
                                    <button
                                      type="button"
                                      onClick={() => setAdminToPromote(admin)}
                                      disabled={isPromotingId === adminKey}
                                      className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:scale-95 text-white text-[10.5px] font-extrabold rounded-xl shadow-xs transition cursor-pointer disabled:opacity-50"
                                      title="Ouvrir la confirmation de promotion en Superviseur Adjoint"
                                    >
                                      {isPromotingId === adminKey ? (
                                        <RotateCw className="h-3.5 w-3.5 animate-spin" />
                                      ) : (
                                        <ShieldCheck className="h-3.5 w-3.5" />
                                      )}
                                      <span>Promouvoir en Adjoint</span>
                                    </button>
                                  )}

                                  {isPrimarySuperAdmin ? (
                                    <button
                                      type="button"
                                      onClick={() => setAdminToRevoke(admin)}
                                      disabled={isRevokingId === adminKey}
                                      className="p-1.5 focus:outline-hidden hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition border border-slate-200 cursor-pointer disabled:opacity-50"
                                      title="Révoquer l'autorisation (Alerte e-mail automatique transmise)"
                                    >
                                      {isRevokingId === adminKey ? (
                                        <RotateCw className="h-3.5 w-3.5 animate-spin" />
                                      ) : (
                                        <Trash2 className="h-3.5 w-3.5" />
                                      )}
                                    </button>
                                  ) : (
                                    <div className="p-2 text-slate-300 cursor-not-allowed" title="Réservé à l'Opérateur Principal">
                                      <Lock className="h-3.5 w-3.5" />
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    {/* Nomination block */}
                    <div className="bg-slate-50 border border-slate-200/80 p-5 rounded-3xl space-y-4">
                      <div className="flex items-center gap-1.5 border-b border-slate-150 pb-2.5">
                        <Plus className="h-4.5 w-4.5 text-indigo-600 font-bold" />
                        <h4 className="text-xs font-black uppercase text-slate-950 tracking-wider">
                          Désigner un Nouvel Administrateur
                        </h4>
                      </div>

                      {isPrimarySuperAdmin ? (
                        <form 
                          onSubmit={async (e) => {
                            e.preventDefault();
                            const targetForm = e.currentTarget;
                            const fd = new FormData(targetForm);
                            const name = (fd.get('name') as string || '').trim();
                            const rawEmail = (fd.get('email') as string || '').trim();
                            const email = rawEmail.toLowerCase();
                            const selectedRole = (fd.get('role') as string || 'simple');
                            const isDeputyRole = selectedRole === 'deputy';
                            
                            if (!name || !email) {
                              setErrorMessage("Veuillez remplir le nom et l'adresse e-mail de l'administrateur.");
                              return;
                            }
                            
                            if (email === 'jacquesbene301@gmail.com') {
                              setErrorMessage("Vous êtes déjà l'administrateur principal.");
                              return;
                            }

                            if (secondaryAdmins.some(admin => admin.email?.toLowerCase().trim() === email || admin.id === email)) {
                              setErrorMessage("Cet administrateur est déjà enregistré.");
                              return;
                            }

                            const newAdminId = email;
                            const accessCode = (fd.get('accessCode') as string || '').trim() || 'ADM-' + Math.floor(100000 + Math.random() * 900000);
                            const adminDoc = {
                              id: newAdminId,
                              name,
                              email,
                              accessCode,
                              createdAt: new Date().toISOString(),
                              addedBy: 'jacquesbene301@gmail.com',
                              role: selectedRole,
                              privileges: isDeputyRole 
                                ? ['audit_system', 'schools_read_write', 'financial_oversight', 'webhook_monitor', 'logs_extended_export']
                                : ['consultation_standard'],
                              status: 'active'
                            };

                            // 1. Immediately update local state and localStorage
                            const updated = [...secondaryAdmins, adminDoc];
                            setSecondaryAdmins(updated);
                            try {
                              localStorage.setItem('pasma_secondary_admins', JSON.stringify(updated));
                            } catch (lsErr) {
                              console.warn("LocalStorage notice:", lsErr);
                            }

                            // 2. Persist to Firestore safely without throwing blocking exceptions
                            try {
                              await setDoc(doc(db, 'super_admins', newAdminId), adminDoc);
                              const sanitizedId = sanitizeFirestoreId(newAdminId);
                              if (sanitizedId !== newAdminId) {
                                await setDoc(doc(db, 'super_admins', sanitizedId), { ...adminDoc, id: sanitizedId });
                              }
                            } catch (fsErr) {
                              console.warn("Firestore super_admins write notice (handled via local state):", fsErr);
                            }

                            // 3. Write system audit log safely
                            try {
                              await handleWriteSystemLog(
                                'CREATE_SUPER_ADMIN', 
                                `Nomination d'un Administrateur secondaire [${isDeputyRole ? 'Superviseur Adjoint' : 'Admin Simple'}] : ${name} (${email}) - Code: ${accessCode}`, 
                                0
                              );
                            } catch (logErr) {
                              console.warn("System log write notice:", logErr);
                            }

                            targetForm.reset();
                            setSuccessMessage(`Habilitation accordée avec succès à ${name} (${email}) en tant que ${isDeputyRole ? 'Superviseur Adjoint (Privilèges étendus)' : 'Admin Simple'} - Code d'accès: ${accessCode}`);
                            setRefreshTrigger(p => p + 1);
                          }}
                          className="space-y-4"
                        >
                          <div className="space-y-1.5">
                            <label className="text-[10.5px] font-bold text-slate-600 uppercase">Nom Complet de l'Administrateur</label>
                            <input
                              type="text"
                              name="name"
                              required
                              placeholder="Ex: Alain Ndzie"
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[10.5px] font-bold text-slate-600 uppercase">Adresse E-mail Google (Auth)</label>
                            <input
                              type="email"
                              name="email"
                              required
                              placeholder="Ex: adjoint@pasma.sys"
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                            />
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[10.5px] font-bold text-slate-600 uppercase">Niveau d'Accès Initial</label>
                            <select
                              name="role"
                              defaultValue="simple"
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 cursor-pointer"
                            >
                              <option value="simple">Admin Simple (Consultation & Surveillance Standard)</option>
                              <option value="deputy">Superviseur Adjoint (Privilèges Étendus & Délégation)</option>
                            </select>
                          </div>

                          <div className="space-y-1.5">
                            <label className="text-[10.5px] font-bold text-slate-600 uppercase">Code d'accès secret (Optionnel)</label>
                            <input
                              type="text"
                              name="accessCode"
                              placeholder="Ex: ADM-789012 (généré auto si vide)"
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                            />
                          </div>

                          <button
                            type="submit"
                            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-extrabold transition shadow-md shadow-indigo-100 flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <UserCheck className="h-4 w-4" /> Enregistrer l'Administrateur
                          </button>
                        </form>
                      ) : (
                        <div className="p-4 bg-slate-100 border border-slate-200 rounded-2xl text-center space-y-2">
                          <Lock className="h-5 w-5 mx-auto text-slate-400" />
                          <p className="font-bold text-slate-700 text-xs">Nomination Non Autorisée</p>
                          <p className="text-[11px] text-slate-450 leading-normal">
                            Seul le Superviseur Principal Jacques Bene Mbama possède l'autorité suprême pour coopter de nouveaux adjoints.
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : activeSubTab === 'campay_webhook' ? (
                <div className="p-6">
                  <PaymentWebhookHandler />
                </div>
              ) : activeSubTab === 'email_infrastructure' ? (
                <div className="p-6">
                  <EmailInfrastructure />
                </div>
              ) : (
                <div className="p-6">
                  <AuthLogsViewer />
                </div>
              )}
            </div>

            {/* QUICK OVERRIDE / TECHNICAL SUPPORT UTILITIES */}
            <div className="bg-white border border-slate-200/80 p-6 rounded-3xl shadow-3xs space-y-4">
              <div>
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                  <Wrench className="h-4 w-4 text-slate-400" /> Boîtier d'Intervention Rapide de l'Éditeur
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">Corrigez globalement des anomalies de configuration ou lancez des requêtes d'assistance</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                  <p className="font-extrabold text-xs text-slate-800">⚙️ Override Mot de Passe de Support</p>
                  <p className="text-[11px] text-slate-500 leading-normal">
                    Si un Directeur d'école égare son code secret de connexion d'acompte, vous pouvez directement réinitialiser le code de son compte gérant d'un seul clic.
                  </p>
                  <button 
                    onClick={() => {
                      const id = prompt("Veuillez saisir l'ID de l'établissement concerné :");
                      if (!id) return;
                      const newPass = prompt("Saisissez le nouveau mot de passe Gérant Financier :");
                      if (!newPass) return;
                      
                      const targetSch = schools.find(s => s.id === id);
                      if (!targetSch) {
                        alert("Établissement introuvable.");
                        return;
                      }

                      setDoc(doc(db, 'establishments', id), {
                        ...targetSch,
                        finManagerPassword: newPass,
                        pedManagerPassword: newPass
                      }, { merge: true }).then(() => {
                        handleWriteSystemLog('SUPPORT_ACTION', `Override de sécurité de mot de passe pour '${targetSch.name}'`, 0, id);
                        alert(`Le mot de passe financier et pédagogique de '${targetSch.name}' a été forcé à '${newPass}'.`);
                        setRefreshTrigger(p => p + 1);
                      }).catch(e => alert(e.message));
                    }}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-850 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                  >
                    Réinitialiser un mot de passe
                  </button>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                  <p className="font-extrabold text-xs text-slate-800">🛡️ État de Chiffrement & Sauvegarde</p>
                  <div className="space-y-1.5 text-[11px] text-slate-500">
                    <p className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-500" /> Cryptage des cookies RGPD : <strong>Actif (256 bits)</strong></p>
                    <p className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-500" /> Protection des Iframe Sandbox : <strong>Actif</strong></p>
                    <p className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-indigo-500" /> Stockage Persistant Cloud : <strong>Firestore Actif</strong></p>
                  </div>
                  <button
                    onClick={() => {
                      const blob = new Blob([JSON.stringify({ schools, allStudents, allInvoices, timestamp: new Date().toISOString() }, null, 2)], { type: 'application/json' });
                      const dUrl = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = dUrl;
                      a.download = `pasmasys_global_backup_${Date.now()}.json`;
                      a.click();
                      handleWriteSystemLog('DATABASE_BACKUP', "Téléchargement d'une sauvegarde globale du système", 0);
                    }}
                    className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                  >
                    Backup Global Système
                  </button>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: ACTIONS TIMELINE LOGS & MANUAL LOG WRITER */}
          <div className="space-y-6">
            
            {/* Real-time System Audit Logs Timeline */}
            <div className="bg-white border border-slate-200/80 p-5 rounded-3xl shadow-3xs space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-1.5">
                  <Activity className="h-4 w-4 text-indigo-600 animate-pulse" />
                  <h3 className="text-sm font-black text-slate-950">Historique d'Actions / Audit</h3>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportLogsCSV}
                    className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 hover:text-indigo-900 border border-indigo-200 rounded-lg text-[10px] font-extrabold flex items-center gap-1 transition cursor-pointer shrink-0 shadow-2xs"
                    title="Exporter tous les événements financiers et administratifs au format CSV"
                    type="button"
                  >
                    <Download className="h-3 w-3" /> Exporter les Logs
                  </button>
                  <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg font-mono">
                    {systemLogs.length} événements
                  </span>
                </div>
              </div>

              {/* Logger Form */}
              <form onSubmit={handleCreateManualLog} className="space-y-2 pb-2">
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    placeholder="Écrire une note administrative générale..."
                    value={manualLogTitle}
                    onChange={(e) => setManualLogTitle(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500"
                  />
                  <button 
                    type="submit" 
                    className="p-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition cursor-pointer shrink-0"
                    title="Enregistrer la note"
                  >
                    <Send className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] text-slate-400 uppercase font-black tracking-wider">Type :</span>
                  <select
                    value={manualLogType}
                    onChange={(e) => setManualLogType(e.target.value)}
                    className="text-[9.5px] font-black bg-slate-50 border border-slate-200 text-slate-700 rounded-md px-1.5 py-0.5 cursor-pointer"
                  >
                    <option value="SYSTEM_UPDATE">⚙️ MAJ Système</option>
                    <option value="SECURITY_NOTICE">🛡️ Alerte Sécurité</option>
                    <option value="AUDIT_MEMO">📝 Note administrative</option>
                  </select>
                </div>
              </form>

              {/* TIMELINE TIMELINE FEED */}
              <div className="space-y-4 overflow-y-auto max-h-[380px] pr-1.5 scrollbar-thin">
                {systemLogs.map((log) => {
                  let badgeBg = 'bg-slate-100 text-slate-700 border-slate-200';
                  let icon = '📝';
                  
                  if (log.dueDate === 'CREATE_SCHOOL') {
                    badgeBg = 'bg-emerald-50 text-emerald-700 border-emerald-150';
                    icon = '🏫';
                  } else if (log.dueDate === 'DELETE_SCHOOL') {
                    badgeBg = 'bg-rose-50 text-rose-700 border-rose-150';
                    icon = '🗑️';
                  } else if (log.dueDate === 'SECURITY_HARDENING' || log.dueDate === 'SECURITY_NOTICE') {
                    badgeBg = 'bg-amber-50 text-amber-700 border-amber-150';
                    icon = '🛡️';
                  } else if (log.dueDate === 'SYSTEM_STARTUP') {
                    badgeBg = 'bg-indigo-50 text-indigo-700 border-indigo-150';
                    icon = '🔌';
                  } else if (log.dueDate === 'PAY_COTISATION') {
                    badgeBg = 'bg-sky-50 text-sky-700 border-sky-150';
                    icon = '💸';
                  }

                  const associatedSchool = schools.find(s => s.id === log.parentId)?.name;

                  return (
                    <div key={log.id} className="p-3 bg-slate-50 border border-slate-150 rounded-xl relative space-y-1.5 hover:border-slate-300 transition text-[11px]">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className={`inline-flex items-center gap-1 border text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded-md ${badgeBg}`}>
                          {icon} {log.dueDate}
                        </span>
                        <span className="text-[9.5px] font-mono font-medium text-slate-400">
                          {new Date(log.paymentDate).toLocaleDateString()} {new Date(log.paymentDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <p className="font-medium text-slate-800 leading-normal">{log.title}</p>

                      <div className="flex items-center justify-between text-[9.5px] text-slate-400 font-bold border-t border-slate-100/50 pt-1.5">
                        <div>OPÉRATEUR : <span className="text-slate-600">{log.provider}</span></div>
                        {associatedSchool && (
                          <div className="text-indigo-600 truncate max-w-[120px]" title={associatedSchool}>
                            🏫 {associatedSchool}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* QUICK PREFERRED STATS EXPLANATION */}
            <div className="bg-gradient-to-br from-indigo-900 to-indigo-950 text-white p-5 rounded-3xl relative overflow-hidden shadow-md">
              <div className="absolute top-0 right-0 p-5 opacity-10 font-bold text-8xl pointer-events-none">🏫</div>
              <div className="space-y-2 mt-2 relative z-10">
                <span className="inline-flex items-center gap-1 text-[9px] font-extrabold text-[#93c5fd] bg-white/10 px-2 py-0.5 rounded-md uppercase">
                  <Sparkles className="h-3 w-3" /> Supervision Complète Pasma-sys
                </span>
                <p className="font-extrabold text-sm tracking-tight leading-snug">
                  Surveillez le taux global de cotisations de l'APEE de l'ensemble du territoire
                </p>
                <p className="text-[11px] text-indigo-200 leading-relaxed font-medium">
                  Les données financières d'acompte saisies par les directeurs ou par l'importation de bases de données sont calculées au centime près. En cas de blocage d'un parent ou d'un gestionnaire financier, servez-vous du <strong>Superviseur Principal</strong> pour modifier sans friction leur état de cotisation ou bypasser les logins.
                </p>
              </div>
            </div>

          </div>

        </div>
      </div>

      {/* CREATE ESTABLISHMENT MODAL DIALOG */}
      <AnimatePresence>
        {isCreateOpen && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-slate-200 p-6 rounded-3xl w-full max-w-2xl shadow-xl max-h-[90vh] overflow-y-auto space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-1.5">
                  <Building2 className="h-5 w-5 text-indigo-600" />
                  <h3 className="font-black text-slate-950 text-[15px]">Créer un Nouvel Établissement Scolaire</h3>
                </div>
                <button 
                  onClick={() => setIsCreateOpen(false)} 
                  className="p-1.5 hover:bg-slate-50 border border-slate-200 text-slate-400 hover:text-slate-600 rounded-xl transition cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {errorMessage && (
                <div className="p-3 bg-rose-50 border border-rose-150 text-xs text-rose-800 rounded-xl font-medium">
                  ⚠️ {errorMessage}
                </div>
              )}

              <form onSubmit={handleCreateSchool} className="space-y-4">
                
                {/* School Profile */}
                <div className="space-y-3">
                  <h4 className="text-[11px] font-black uppercase text-slate-450 tracking-wider">I. Description Globale de l'Établissement</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div className="space-y-1">
                      <label className="text-[10.5px] font-bold text-slate-600 uppercase">Nom de l'école</label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: CES d'Ekali 1"
                        value={schoolName}
                        onChange={(e) => setSchoolName(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10.5px] font-bold text-slate-600 uppercase">Année Scolaire</label>
                        <input
                          type="text"
                          required
                          value={schoolYear}
                          onChange={(e) => setSchoolYear(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10.5px] font-bold text-slate-600 uppercase">Tarif Cotisation APEE</label>
                        <input
                          type="number"
                          required
                          value={cotisationAmount}
                          onChange={(e) => setCotisationAmount(Number(e.target.value))}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2/5 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10.5px] font-bold text-slate-600 uppercase">Objectif Financier Global (FCFA)</label>
                    <input
                      type="number"
                      required
                      value={financialGoal}
                      onChange={(e) => setFinancialGoal(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                    />
                  </div>
                </div>

                {/* Manager Finance Credentials */}
                <div className="space-y-3 pt-2 border-t border-slate-100">
                  <h4 className="text-[11px] font-black uppercase text-slate-450 tracking-wider flex items-center gap-1">🎮 II. Responsable Finances d'école (Secrétaire APEE)</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10.5px] font-bold text-slate-600 uppercase">Nom Complet</label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: M. Béné"
                        value={finName}
                        onChange={(e) => setFinName(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10.5px] font-bold text-slate-600 uppercase">Téléphone (6xxxxxx)</label>
                      <input
                        type="text"
                        required
                        placeholder="Ex: 677002233"
                        value={finPhone}
                        onChange={(e) => setFinPhone(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10.5px] font-bold text-slate-600 uppercase flex items-center gap-0.5"><Lock className="h-3 w-3" /> Mot de passe d'accès</label>
                      <div className="relative">
                        <input
                          type={showFinPassword ? "text" : "password"}
                          required
                          placeholder="Saisir code d'accès..."
                          value={finPassword}
                          onChange={(e) => setFinPassword(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-3 pr-8 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                        />
                        <button
                          type="button"
                          onClick={() => setShowFinPassword(!showFinPassword)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer p-0.5"
                          title={showFinPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                        >
                          {showFinPassword ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Manager Pedagogique Credentials */}
                <div className="space-y-3 pt-2 border-t border-slate-100 pb-2">
                  <h4 className="text-[11px] font-black uppercase text-slate-450 tracking-wider">🎓 III. Responsable Académique (Censeur / Surveillant)</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div className="space-y-1">
                      <label className="text-[10.5px] font-bold text-slate-600 uppercase">Nom Complet (Facultatif)</label>
                      <input
                        type="text"
                        placeholder="Ex: Mme Sophie Marie"
                        value={pedName}
                        onChange={(e) => setPedName(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10.5px] font-bold text-slate-600 uppercase">Téléphone</label>
                        <input
                          type="text"
                          placeholder="Ex: 688223344"
                          value={pedPhone}
                          onChange={(e) => setPedPhone(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10.5px] font-bold text-slate-600 uppercase flex items-center gap-0.5"><Lock className="h-3 w-3" /> Code d'Accès</label>
                        <div className="relative">
                          <input
                            type={showPedPassword ? "text" : "password"}
                            placeholder="Par défaut: 1234"
                            value={pedPassword}
                            onChange={(e) => setPedPassword(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-2.5 pr-8 py-2 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPedPassword(!showPedPassword)}
                            className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer p-0.5"
                            title={showPedPassword ? "Masquer le code d'accès" : "Afficher le code d'accès"}
                          >
                            {showPedPassword ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-4">
                  <button
                    type="button"
                    onClick={() => setIsCreateOpen(false)}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white rounded-xl text-xs font-black shadow-md shadow-indigo-100 transition flex items-center gap-1 cursor-pointer"
                  >
                    {submitting ? (
                      <>Création en cours...</>
                    ) : (
                      <>
                        <Plus className="h-4 w-4 shrink-0" /> Créer l'Établissement
                      </>
                    )}
                  </button>
                </div>

              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SELECT PARENT FOR IMPERSONATION MODAL DIALOG */}
      <AnimatePresence>
        {selectedSchoolForParentImpersonation && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-slate-200 p-6 rounded-3xl w-full max-w-lg shadow-xl max-h-[80vh] overflow-y-auto space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-1.5">
                  <Users className="h-5 w-5 text-emerald-600" />
                  <h3 className="font-black text-slate-950 text-[14px] truncate">
                    Accès Parent : {selectedSchoolForParentImpersonation.name}
                  </h3>
                </div>
                <button 
                  onClick={() => setSelectedSchoolForParentImpersonation(null)} 
                  className="p-1.5 hover:bg-slate-50 border border-slate-200 text-slate-400 hover:text-slate-600 rounded-xl transition cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
                Veuillez sélectionner le compte d'un parent d'élève de cet établissement pour vous connecter en tant que tel et vérifier sa situation comptable :
              </p>

              <div className="space-y-2 max-h-[45vh] overflow-y-auto pr-1">
                {getSchoolRealParents(selectedSchoolForParentImpersonation.id).length === 0 ? (
                  <div className="p-6 border border-dashed border-slate-200 rounded-2xl text-center text-slate-400 text-xs font-semibold space-y-3">
                    <p>Aucun dossier de parent enregistré dans cet établissement.</p>
                    <button
                      onClick={() => {
                        onSelectSchool(selectedSchoolForParentImpersonation.id, 'parent', {
                          name: 'Parent Test de Supervision',
                          phone: '699000111',
                          invoiceId: 'parent_test_super_admin',
                          studentSubsetNames: ['Élève de Test 1', 'Élève de Test 2']
                        });
                        setSelectedSchoolForParentImpersonation(null);
                      }}
                      className="px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-[11px] font-black transition cursor-pointer"
                    >
                      Accéder avec un Parent Test de Supervision
                    </button>
                  </div>
                ) : (
                  getSchoolRealParents(selectedSchoolForParentImpersonation.id).map((parentDoc) => {
                    let kids: string[] = [];
                    try {
                      if (parentDoc.studentsList) {
                        kids = JSON.parse(parentDoc.studentsList).map((s: any) => s.name);
                      }
                    } catch (e) {
                      console.warn("Failed to parse kids in impersonation", e);
                    }
                    return (
                      <div 
                        key={parentDoc.id}
                        className="p-3.5 border border-slate-100 hover:border-emerald-100 bg-slate-50/50 hover:bg-emerald-50/20 rounded-2xl flex items-center justify-between gap-3 transition"
                      >
                        <div className="space-y-0.5 min-w-0 flex-1">
                          <h4 className="font-black text-slate-900 text-xs truncate">{parentDoc.name}</h4>
                          <p className="text-[10px] text-slate-500 font-mono">📞 {parentDoc.phone || "Non renseigné"}</p>
                          {kids.length > 0 && (
                            <p className="text-[9.5px] text-indigo-600 font-extrabold truncate">👦 Pupilles : {kids.join(', ')}</p>
                          )}
                        </div>
                        <button
                          onClick={() => {
                            onSelectSchool(selectedSchoolForParentImpersonation.id, 'parent', {
                              name: parentDoc.name,
                              phone: parentDoc.phone || '',
                              invoiceId: parentDoc.id,
                              studentSubsetNames: kids
                            });
                            setSelectedSchoolForParentImpersonation(null);
                          }}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[10.5px] rounded-xl transition cursor-pointer shadow-xs shrink-0"
                        >
                          Accéder
                        </button>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="flex items-center justify-end border-t border-slate-100 pt-3">
                <button
                  onClick={() => setSelectedSchoolForParentImpersonation(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Fermer
                </button>
              </div>

            </motion.div>
          </div>
        )}

        {/* Modal de Confirmation de Promotion en Superviseur Adjoint */}
        {adminToPromote && (
          <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white border border-slate-200 p-6 rounded-3xl w-full max-w-lg shadow-2xl space-y-5"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-2xl shrink-0">
                    <ShieldCheck className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-base">
                      Confirmation de Promotion
                    </h3>
                    <p className="text-xs text-slate-500 font-semibold">
                      Élévation des privilèges de supervision système
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setAdminToPromote(null)}
                  disabled={!!isPromotingId}
                  className="p-1.5 hover:bg-slate-100 border border-slate-200 text-slate-400 hover:text-slate-600 rounded-xl transition cursor-pointer disabled:opacity-50"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-slate-450 uppercase tracking-wider">Bénéficiaire Sélectionné</span>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 bg-amber-50 border border-amber-200 text-amber-800 rounded-md">
                    Statut actuel : Admin Simple
                  </span>
                </div>
                <div className="space-y-0.5">
                  <p className="text-sm font-black text-slate-900">{adminToPromote.name}</p>
                  <p className="text-xs font-mono text-slate-500">{adminToPromote.email}</p>
                </div>
              </div>

              <div className="space-y-2.5">
                <p className="text-xs font-extrabold text-slate-700 uppercase tracking-wider">
                  Privilèges étendus octroyés :
                </p>
                <ul className="space-y-1.5 text-xs text-slate-600 font-medium">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                    <span>Accès complet d'audit système et journalisation étendue</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                    <span>Supervision et synchronisation des établissements scolaires</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                    <span>Surveillance financière globale et consolidation des flux</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-emerald-600 shrink-0" />
                    <span>Monitorage des webhooks de paiement en temps réel</span>
                  </li>
                </ul>
              </div>

              <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl text-[11px] text-amber-900 leading-relaxed font-medium">
                ⚠️ <strong>Note de sécurité</strong> : Cette modification sera enregistrée dans le journal d'audit Firestore et est révocable à tout moment par le Super-Admin Principal.
              </div>

              <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setAdminToPromote(null)}
                  disabled={!!isPromotingId}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer disabled:opacity-50"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const target = adminToPromote;
                    await handlePromoteToDeputy(target);
                    setAdminToPromote(null);
                  }}
                  disabled={!!isPromotingId}
                  className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:scale-95 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-600/20 transition cursor-pointer flex items-center gap-2 disabled:opacity-50"
                >
                  {isPromotingId ? (
                    <>
                      <RotateCw className="h-4 w-4 animate-spin" />
                      <span>Promotion en cours...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="h-4 w-4" />
                      <span>Confirmer la promotion</span>
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SECURITY REVOCATION CONFIRMATION MODAL WITH AUTOMATIC EMAIL ALERT */}
      <AnimatePresence>
        {adminToRevoke && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white rounded-3xl shadow-2xl border border-rose-200/80 max-w-md w-full p-6 space-y-5 overflow-hidden relative"
            >
              {/* Top Accent bar */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-rose-500 via-red-600 to-amber-500" />

              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-rose-100/80 text-rose-700 rounded-2xl">
                    <ShieldAlert className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900">Révocation de Sécurité</h3>
                    <p className="text-xs text-rose-600 font-bold">Alerte e-mail automatique au Super-Admin</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setAdminToRevoke(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="p-4 bg-rose-50/60 border border-rose-200/70 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-rose-900/70 uppercase tracking-wider">Compte Administrateur Ciblé</span>
                  <span className="text-[10px] font-extrabold px-2 py-0.5 bg-rose-100 border border-rose-300 text-rose-900 rounded-md">
                    {adminToRevoke.role === 'deputy' ? 'Superviseur Adjoint' : 'Admin Secondaire'}
                  </span>
                </div>
                <div className="space-y-0.5">
                  <p className="text-sm font-black text-slate-900">{adminToRevoke.name}</p>
                  <p className="text-xs font-mono text-slate-600">{adminToRevoke.email}</p>
                </div>
              </div>

              <div className="space-y-2 text-xs text-slate-600">
                <p className="font-bold text-slate-800">Conséquences de la révocation :</p>
                <ul className="space-y-1.5 font-medium">
                  <li className="flex items-start gap-2">
                    <span className="text-rose-600 font-black">•</span>
                    <span>Clôture immédiate de tous ses droits d'accès à la plateforme</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-rose-600 font-black">•</span>
                    <span>Suppression de son profil dans l'annuaire <code>super_admins</code></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-rose-600 font-black">•</span>
                    <span>Enregistrement irrévocable dans les journaux d'audit de sécurité</span>
                  </li>
                </ul>
              </div>

              {/* Automatic Email Notification notice box */}
              <div className="p-3 bg-indigo-50/80 border border-indigo-200/80 rounded-xl space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-black text-indigo-950">
                  <Mail className="h-4 w-4 text-indigo-600 shrink-0" />
                  <span>Notification e-mail de sécurité automatique</span>
                </div>
                <p className="text-[11px] text-indigo-900/80 leading-relaxed">
                  Un e-mail de sécurité contenant l'heure, l'opérateur et les détails de révocation sera <strong>automatiquement envoyé</strong> à l'adresse du Super-Admin Principal : <strong className="font-mono text-indigo-950">jacquesbene301@gmail.com</strong>.
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setAdminToRevoke(null)}
                  disabled={!!isRevokingId}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer disabled:opacity-50"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const target = adminToRevoke;
                    await handleRevokeAdmin(target);
                  }}
                  disabled={!!isRevokingId}
                  className="px-5 py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 active:scale-95 text-white rounded-xl text-xs font-black shadow-md shadow-rose-600/20 transition cursor-pointer flex items-center gap-2 disabled:opacity-50"
                >
                  {isRevokingId ? (
                    <>
                      <RotateCw className="h-4 w-4 animate-spin" />
                      <span>Révocation & envoi de l'alerte...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4" />
                      <span>Confirmer & Envoyer l'alerte e-mail</span>
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
