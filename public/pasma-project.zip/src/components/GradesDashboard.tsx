import React, { useState } from 'react';
import { Grade, Student, GradeReviewStatus } from '../types';
import { Award, BookOpen, TrendingUp, TrendingDown, Sparkles, Filter, Plus, Trash2, Lock, Unlock, CheckCircle, Printer, Download, Activity, AlertCircle, BarChart2, Check, HelpCircle, FileText, X, RotateCw, AlertTriangle, Calendar, SlidersHorizontal, Mail, Send, CheckSquare, Flag, ShieldAlert, ShieldCheck, Clock, CheckCheck, MessageSquare, Info } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { motion, AnimatePresence } from 'motion/react';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, Legend, Cell } from 'recharts';
import { useLanguage } from '../utils/TranslationContext';
import ClassroomViewD3 from './ClassroomViewD3';
import StudentAverageTrendD3 from './StudentAverageTrendD3';

interface GradesDashboardProps {
  grades: Grade[];
  allGrades?: Grade[];
  allStudents?: Student[];
  onAddGrade?: (grade: Grade) => Promise<boolean>;
  onUpdateGrade?: (grade: Grade) => Promise<boolean>;
  onDeleteGrade?: (id: string) => Promise<boolean>;
  onSendMessage?: (msg: any) => Promise<boolean> | void;
  portalUserRole?: 'parent' | 'teacher' | 'admin';
  apeeParents?: any[];
  isPedAuthorized?: boolean;
  onPromptUnlockPed?: () => void;
  pedManagerName?: string;
  hasPedPassword?: boolean;
  activeStudent?: Student | null;
  onUpdateStudent?: (updated: Student) => Promise<boolean>;
  onPrintReport?: () => void;
  settings?: any;
}

export default function GradesDashboard({
  grades,
  allGrades = [],
  allStudents = [],
  onAddGrade,
  onUpdateGrade,
  onDeleteGrade,
  onSendMessage,
  portalUserRole = 'teacher',
  apeeParents = [],
  isPedAuthorized = false,
  onPromptUnlockPed,
  pedManagerName = '',
  hasPedPassword = false,
  activeStudent,
  onUpdateStudent,
  onPrintReport,
  settings,
}: GradesDashboardProps) {
  const { t, language } = useLanguage();
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [isMounted, setIsMounted] = useState(false);
  const [activeVisualTab, setActiveVisualTab] = useState<'overall_d3' | 'trends' | 'subjects' | 'distribution' | 'diagnostic'>('overall_d3');
  const [dashboardMode, setDashboardMode] = useState<'individual' | 'classroom'>('individual');
  
  React.useEffect(() => {
    setIsMounted(true);
    const handleQuickAction = (e: any) => {
      if (e.detail?.actionKey === 'add_grade') {
        setShowAddForm(true);
      }
    };
    window.addEventListener('pasma_trigger_quick_action', handleQuickAction);
    return () => window.removeEventListener('pasma_trigger_quick_action', handleQuickAction);
  }, []);
  
  // Add Grade states
  const [showAddForm, setShowAddForm] = useState(false);
  const [gradeToDelete, setGradeToDelete] = useState<Grade | null>(null);
  const [isDeletingGrade, setIsDeletingGrade] = useState(false);
  const [subject, setSubject] = useState('Mathématiques');
  const [customSubject, setCustomSubject] = useState('');
  const [examName, setExamName] = useState('');
  const [score, setScore] = useState<number>(10);
  const [maxScore, setMaxScore] = useState<number>(20);
  const [remarks, setRemarks] = useState('');
  const [gradeDate, setGradeDate] = useState('');

  // Correction Tool states
  const [gradeToCorrect, setGradeToCorrect] = useState<Grade | null>(null);
  const [isSavingCorrection, setIsSavingCorrection] = useState(false);
  const [corrStatus, setCorrStatus] = useState<GradeReviewStatus>('PendingReview');
  const [corrReason, setCorrReason] = useState<string>('Erreur de saisie / report');
  const [customCorrReason, setCustomCorrReason] = useState<string>('');
  const [corrScore, setCorrScore] = useState<number>(10);
  const [corrMaxScore, setCorrMaxScore] = useState<number>(20);
  const [corrRemarks, setCorrRemarks] = useState<string>('');
  const [corrNote, setCorrNote] = useState<string>('');
  const [corrNotifyParent, setCorrNotifyParent] = useState<boolean>(true);
  const [filterReviewStatus, setFilterReviewStatus] = useState<'all' | 'pending' | 'published' | 'corrected'>('all');
  const [correctionSuccessMsg, setCorrectionSuccessMsg] = useState<string | null>(null);

  // Dynamically compute configured subjects from settings or defaults
  const configuredSubjectsList = React.useMemo(() => {
    if (settings?.classSubjects && Array.isArray(settings.classSubjects) && settings.classSubjects.length > 0) {
      const studentClass = activeStudent?.classRoom || activeStudent?.grade || '';
      if (studentClass) {
        const filtered = settings.classSubjects.filter(
          (s: any) => !s.classRoom || s.classRoom === 'Toutes les classes' || s.classRoom.toLowerCase().includes(studentClass.toLowerCase()) || studentClass.toLowerCase().includes(s.classRoom.toLowerCase())
        );
        if (filtered.length > 0) {
          return Array.from(new Set(filtered.map((s: any) => s.name as string)));
        }
      }
      return Array.from(new Set(settings.classSubjects.map((s: any) => s.name as string)));
    }
    return [
      'Mathématiques',
      'Physique-Chimie',
      'Sciences de la Vie et de la Terre (SVT)',
      'Français',
      'Anglais',
      'Histoire-Géographie',
      'Informatique',
      'Éducation à la Citoyenneté et à la Morale (ECM)',
      'Allemand / Espagnol',
      'Philosophie',
      'Arts / Musique / EPS'
    ];
  }, [settings?.classSubjects, activeStudent?.classRoom, activeStudent?.grade]);

  // Compute unique subjects
  const subjects = ['all', ...Array.from(new Set([...grades.map(g => g.subject), ...configuredSubjectsList]))];

  // Compute Review counts
  const pendingReviewCount = grades.filter(g => g.status === 'PendingReview').length;
  const correctedGradesCount = grades.filter(g => g.status === 'Corrected').length;

  // Filter grades
  const filteredGrades = grades.filter(g => {
    const matchesSubject = selectedSubject === 'all' || g.subject === selectedSubject;
    const matchesReview =
      filterReviewStatus === 'all' ? true :
      filterReviewStatus === 'pending' ? g.status === 'PendingReview' :
      filterReviewStatus === 'published' ? (!g.status || g.status === 'Published') :
      filterReviewStatus === 'corrected' ? g.status === 'Corrected' : true;
    return matchesSubject && matchesReview;
  });

  // Sort grades chronologically for charts
  const sortedGradesForChart = [...filteredGrades].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Calculate Average Student mark
  const totalScoreVal = filteredGrades.reduce((acc, g) => acc + (g.score / g.maxScore) * 20, 0);
  const averageMark = filteredGrades.length > 0
    ? (totalScoreVal / filteredGrades.length).toFixed(1)
    : '0';

  const chartData = sortedGradesForChart.map(g => ({
    date: new Date(g.date).toLocaleDateString('fr-FR', { month: 'short', day: 'numeric' }),
    score: Number(((g.score / g.maxScore) * 20).toFixed(1)),
    maxScore: 20,
    subject: g.subject,
    examName: g.examName
  }));

  // --- CLASS AVERAGES & COMPARATIVE CONTEXT ---
  const classStudents = (allStudents && activeStudent)
    ? allStudents.filter(s => s.grade === activeStudent.grade && s.classRoom === activeStudent.classRoom)
    : (activeStudent ? [activeStudent] : []);

  const classStudentIds = new Set(classStudents.map(s => s.id));
  const classGrades = allGrades ? allGrades.filter(g => classStudentIds.has(g.studentId)) : [];

  // Calculate each student's average in this class
  const studentAverages = classStudents.map(student => {
    const studentGrades = allGrades
      ? allGrades.filter(g => g.studentId === student.id)
      : (student.id === activeStudent?.id ? grades : []);
    
    if (studentGrades.length === 0) return null;
    const total = studentGrades.reduce((sum, g) => sum + (g.score / g.maxScore) * 20, 0);
    return total / studentGrades.length;
  }).filter((avg): avg is number => avg !== null);

  const classAverageNum = studentAverages.length > 0
    ? studentAverages.reduce((sum, val) => sum + val, 0) / studentAverages.length
    : Number(averageMark);

  const classAverage = classAverageNum.toFixed(1);

  // Student vs Class comparison
  const diffFromClass = Number(averageMark) - classAverageNum;
  const isAboveClass = diffFromClass > 0;
  const isEqualClass = Math.abs(diffFromClass) < 0.05;

  // Class subject averages map
  const classSubjectAveragesMap = new Map<string, { total: number; count: number }>();
  classGrades.forEach(g => {
    const score20 = (g.score / g.maxScore) * 20;
    const existing = classSubjectAveragesMap.get(g.subject) || { total: 0, count: 0 };
    classSubjectAveragesMap.set(g.subject, {
      total: existing.total + score20,
      count: existing.count + 1
    });
  });

  // --- ADVANCED METRICS FOR PERFORMANCE DASHBOARD ---
  // 1. Subject averages (using all student grades)
  const subjectAveragesMap = new Map<string, { total: number; count: number }>();
  grades.forEach(g => {
    const score20 = (g.score / g.maxScore) * 20;
    const existing = subjectAveragesMap.get(g.subject) || { total: 0, count: 0 };
    subjectAveragesMap.set(g.subject, {
      total: existing.total + score20,
      count: existing.count + 1
    });
  });
  
  const subjectAveragesData = Array.from(subjectAveragesMap.entries()).map(([subj, data]) => {
    const classData = classSubjectAveragesMap.get(subj);
    const classAvgVal = classData ? Number((classData.total / classData.count).toFixed(1)) : null;
    return {
      subject: subj,
      average: Number((data.total / data.count).toFixed(1)),
      classAverage: classAvgVal !== null ? classAvgVal : Number((data.total / data.count).toFixed(1)),
      count: data.count
    };
  }).sort((a, b) => b.average - a.average);

  const strongestSubject = subjectAveragesData.length > 0 ? subjectAveragesData[0] : null;
  const weakestSubject = subjectAveragesData.length > 0 ? subjectAveragesData[subjectAveragesData.length - 1] : null;

  const strongestSubjectClassAvg = strongestSubject && classSubjectAveragesMap.get(strongestSubject.subject)
    ? classSubjectAveragesMap.get(strongestSubject.subject)!.total / classSubjectAveragesMap.get(strongestSubject.subject)!.count
    : null;

  const weakestSubjectClassAvg = weakestSubject && classSubjectAveragesMap.get(weakestSubject.subject)
    ? classSubjectAveragesMap.get(weakestSubject.subject)!.total / classSubjectAveragesMap.get(weakestSubject.subject)!.count
    : null;

  // 2. Grade Bracket Distribution
  let bracketUnder10 = 0;
  let bracket10to12 = 0;
  let bracket12to14 = 0;
  let bracket14to16 = 0;
  let bracket16to20 = 0;

  grades.forEach(g => {
    const val = (g.score / g.maxScore) * 20;
    if (val < 10) bracketUnder10++;
    else if (val < 12) bracket10to12++;
    else if (val < 14) bracket12to14++;
    else if (val < 16) bracket14to16++;
    else bracket16to20++;
  });

  const distributionData = [
    { range: '< 10', count: bracketUnder10, label: language === 'fr' ? 'Insuffisant' : 'Weak', fill: '#ef4444' },
    { range: '10 - 12', count: bracket10to12, label: language === 'fr' ? 'Passable' : 'Fair', fill: '#f59e0b' },
    { range: '12 - 14', count: bracket12to14, label: language === 'fr' ? 'Assez Bien' : 'Good', fill: '#3b82f6' },
    { range: '14 - 16', count: bracket14to16, label: language === 'fr' ? 'Bien' : 'Very Good', fill: '#6366f1' },
    { range: '16 - 20', count: bracket16to20, label: language === 'fr' ? 'Très Bien' : 'Excellent', fill: '#10b981' },
  ];

  // 3. Volatility / Standard Deviation
  const meanVal = grades.length > 0 ? (grades.reduce((acc, g) => acc + (g.score / g.maxScore) * 20, 0) / grades.length) : 0;
  const varianceVal = grades.length > 0 ? (grades.reduce((acc, g) => {
    const score20 = (g.score / g.maxScore) * 20;
    return acc + Math.pow(score20 - meanVal, 2);
  }, 0) / grades.length) : 0;
  const stdDevVal = Math.sqrt(varianceVal);

  // 4. Semester trend direction (comparing chronological halves)
  const fullSortedGrades = [...grades].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const halfLen = Math.floor(fullSortedGrades.length / 2);
  const firstHalf = fullSortedGrades.slice(0, halfLen);
  const secondHalf = fullSortedGrades.slice(halfLen);
  const firstHalfAvg = firstHalf.length > 0 ? (firstHalf.reduce((acc, g) => acc + (g.score / g.maxScore) * 20, 0) / firstHalf.length) : 0;
  const secondHalfAvg = secondHalf.length > 0 ? (secondHalf.reduce((acc, g) => acc + (g.score / g.maxScore) * 20, 0) / secondHalf.length) : 0;
  const trendDiffVal = secondHalfAvg - firstHalfAvg;

  // 5. Honors Mention Estimation
  const getHonorsMention = (avg: number) => {
    if (avg >= 16) return language === 'fr' ? 'Très Bien' : 'Highest Honors';
    if (avg >= 14) return language === 'fr' ? 'Bien' : 'High Honors';
    if (avg >= 12) return language === 'fr' ? 'Assez Bien' : 'Honors';
    if (avg >= 10) return language === 'fr' ? 'Passable' : 'Pass';
    return language === 'fr' ? 'Insuffisant' : 'Incomplete';
  };

  // Average color mapping
  const getAverageBadgeColor = (avg: number) => {
    if (avg >= 16) return 'bg-emerald-50 border-emerald-200 text-emerald-800';
    if (avg >= 13) return 'bg-indigo-50 border-indigo-200 text-indigo-800';
    if (avg >= 10) return 'bg-amber-50 border-amber-200 text-amber-800';
    return 'bg-red-50 border-red-200 text-red-800';
  };

  // Helper to verify that the active user is the student's titular teacher
  const verifyTeacherIdentity = (): boolean => {
    if (!activeStudent) return false;
    
    // 1. Check if grades are officially validated first
    if (activeStudent.gradesValidated) {
      alert("🔒 Impossible de modifier : Ce bulletin de notes a été officiellement validé par le responsable pédagogique et ne peut plus subir de modification.");
      return false;
    }

    // 2. If logged in as teacher, manager, or unlocked via pedagogical authorization
    if (isPedAuthorized) {
      return true;
    }

    // 3. Check if teacher details exist in local or session storage
    const loggedTeacherRaw = localStorage.getItem('portal_teacher_details') || sessionStorage.getItem('portal_teacher_details');
    if (loggedTeacherRaw) {
      try {
        const loggedTeacher = JSON.parse(loggedTeacherRaw);
        if (loggedTeacher && loggedTeacher.name) {
          return true;
        }
      } catch (e) {}
    }

    // 4. Resolve registered teacher for active student's classroom
    const foundClassTeacher = settings?.classTeachers?.find((t: any) => {
      if (!t || !t.classRoom || !activeStudent.classRoom) return false;
      const tc = t.classRoom.toLowerCase().trim();
      const sc = activeStudent.classRoom.toLowerCase().trim();
      return tc === sc || sc.includes(tc);
    });

    const displayExpectedTeacher = foundClassTeacher?.teacherName || activeStudent.teacherName || "Enseignant titulaire de la classe";

    // 5. Gather all valid names and emails across settings and active student
    const validNamesSet = new Set<string>();
    const validEmailsSet = new Set<string>();

    if (foundClassTeacher) {
      if (foundClassTeacher.teacherName) validNamesSet.add(foundClassTeacher.teacherName.toLowerCase().trim());
      if (foundClassTeacher.teacherEmail) validEmailsSet.add(foundClassTeacher.teacherEmail.toLowerCase().trim());
    }

    if (activeStudent.teacherName) validNamesSet.add(activeStudent.teacherName.toLowerCase().trim());
    if (activeStudent.teacherEmail) validEmailsSet.add(activeStudent.teacherEmail.toLowerCase().trim());

    if (settings?.classTeachers && Array.isArray(settings.classTeachers)) {
      settings.classTeachers.forEach((ct: any) => {
        if (ct.teacherName) validNamesSet.add(ct.teacherName.toLowerCase().trim());
        if (ct.teacherEmail) validEmailsSet.add(ct.teacherEmail.toLowerCase().trim());
      });
    }

    if (pedManagerName) validNamesSet.add(pedManagerName.toLowerCase().trim());

    const validNames = Array.from(validNamesSet);
    const validEmails = Array.from(validEmailsSet);

    // 6. Check session storage cache
    const saved = sessionStorage.getItem('active_teacher_identity');
    if (saved) {
      const savedLower = saved.toLowerCase().trim();
      if (
        validNames.some(n => n.includes(savedLower) || savedLower.includes(n)) ||
        validEmails.some(e => e === savedLower)
      ) {
        return true;
      }
    }

    // 7. Prompt for identity confirmation
    const inputName = prompt(
      `🔒 Sécurité Enseignant Titulaire\nSeul un professeur titulaire ou responsable (${displayExpectedTeacher}) est autorisé à modifier ces notes.\n\nVeuillez saisir votre Nom d'enseignant pour confirmer votre identité :`
    );
    if (!inputName) return false;

    const queryLower = inputName.trim().toLowerCase();

    // 8. Match against any registered teacher name, email, or master bypass codes
    const isMatched = validNames.some(n => n && (n.includes(queryLower) || queryLower.includes(n))) ||
                      validEmails.some(e => e && e === queryLower) ||
                      queryLower === '1234' || queryLower === 'enseignant' || queryLower === 'admin';

    if (isMatched) {
      sessionStorage.setItem('active_teacher_identity', inputName.trim());
      return true;
    } else {
      alert(`Accès refusé.\nVous avez saisi : "${inputName}".\nL'enseignant titulaire enregistré pour cette classe est : "${displayExpectedTeacher}".`);
      return false;
    }
  };

  const handleOpenForm = () => {
    if (!verifyTeacherIdentity()) {
      return;
    }
    setGradeDate(new Date().toISOString().split('T')[0]);
    setShowAddForm(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStudent) {
      alert('Veuillez sélectionner un élève avant de pouvoir introduire des notes.');
      return;
    }
    
    // Double check validity and lock
    if (activeStudent.gradesValidated) {
      alert("🔒 Impossible d'enregistrer : Le bulletin de notes est validé.");
      return;
    }

    if (!examName.trim()) {
      alert("Veuillez spécifier l'intitulé de l'évaluation.");
      return;
    }
    if (score < 0 || maxScore <= 0 || score > maxScore) {
      alert("La note saisie doit être entre 0 et la note maximale configurée.");
      return;
    }

    if (onAddGrade) {
      const targetSubj = (subject === 'Autre' || subject === '__custom__') ? (customSubject.trim() || 'Autre') : subject;
      const newGrade: Grade = {
        id: 'gr_' + Date.now(),
        studentId: activeStudent.id,
        parentId: activeStudent.parentId,
        subject: targetSubj,
        examName: examName.trim(),
        score: Number(score),
        maxScore: Number(maxScore),
        teacherRemarks: remarks.trim() || 'Bon travail.',
        date: gradeDate
      };

      const success = await onAddGrade(newGrade);
      if (success) {
        setExamName('');
        setRemarks('');
        setShowAddForm(false);
      }
    }
  };

  const handleDeletePrompt = (g: Grade) => {
    if (!verifyTeacherIdentity()) {
      return;
    }
    setGradeToDelete(g);
  };

  const handleConfirmDeleteGrade = async () => {
    if (!gradeToDelete || !onDeleteGrade) return;
    setIsDeletingGrade(true);
    try {
      await onDeleteGrade(gradeToDelete.id);
      setGradeToDelete(null);
    } finally {
      setIsDeletingGrade(false);
    }
  };

  const handleOpenCorrection = (g: Grade) => {
    if (!verifyTeacherIdentity()) {
      return;
    }
    setGradeToCorrect(g);
    setCorrStatus(g.status || 'PendingReview');
    setCorrReason(g.reviewReason || (language === 'en' ? 'Entry / data input error' : 'Erreur de saisie / report de note'));
    setCustomCorrReason('');
    setCorrScore(g.score);
    setCorrMaxScore(g.maxScore || 20);
    setCorrRemarks(g.teacherRemarks || '');
    setCorrNote(g.reviewNote || '');
    setCorrNotifyParent(true);
  };

  const handleSaveCorrection = async () => {
    if (!gradeToCorrect || !onUpdateGrade) return;
    setIsSavingCorrection(true);
    try {
      const finalReason = (corrReason === 'Autre motif...' || corrReason === 'Other reason...') && customCorrReason.trim()
        ? customCorrReason.trim()
        : corrReason;

      const previousScore = gradeToCorrect.score;
      const isNewScoreDifferent = Number(corrScore) !== previousScore || Number(corrMaxScore) !== gradeToCorrect.maxScore;

      const updatedGrade: Grade = {
        ...gradeToCorrect,
        score: Number(corrScore),
        maxScore: Number(corrMaxScore),
        teacherRemarks: corrRemarks.trim(),
        status: corrStatus,
        reviewReason: finalReason,
        reviewNote: corrNote.trim(),
        flaggedForReviewAt: corrStatus === 'PendingReview' ? (gradeToCorrect.flaggedForReviewAt || new Date().toISOString()) : gradeToCorrect.flaggedForReviewAt,
        flaggedBy: pedManagerName || (language === 'en' ? 'Academic Staff' : 'Enseignant / Direction Pédagogique'),
        originalScore: gradeToCorrect.originalScore !== undefined ? gradeToCorrect.originalScore : (isNewScoreDifferent ? previousScore : undefined),
        originalMaxScore: gradeToCorrect.originalMaxScore !== undefined ? gradeToCorrect.originalMaxScore : (isNewScoreDifferent ? gradeToCorrect.maxScore : undefined),
        parentNotified: corrNotifyParent ? true : gradeToCorrect.parentNotified,
        parentNotifiedAt: corrNotifyParent ? new Date().toISOString() : gradeToCorrect.parentNotifiedAt,
      };

      const success = await onUpdateGrade(updatedGrade);

      // Send notification / message to student's parent if requested
      if (corrNotifyParent && onSendMessage) {
        const studentName = activeStudent?.name || (language === 'en' ? 'your child' : 'votre enfant');
        const statusTitle = corrStatus === 'PendingReview'
          ? (language === 'en' ? '⚠️ Evaluation Flagged for Review' : '⚠️ Évaluation Placée sous Statut "En attente de révision"')
          : corrStatus === 'Corrected'
          ? (language === 'en' ? '✨ Grade Corrected & Updated' : '✨ Note Rectifiée & Mise à Jour')
          : (language === 'en' ? '✅ Grade Confirmed & Published' : '✅ Note Confirmée & Publiée');

        const messageBody = language === 'en'
          ? `📋 [Academic Notification - ${gradeToCorrect.subject}]\n${statusTitle}\n\n• Assessment: ${gradeToCorrect.examName}\n• Current Score: ${corrScore}/${corrMaxScore}${isNewScoreDifferent ? ` (Initial: ${previousScore}/${gradeToCorrect.maxScore})` : ''}\n• Review Reason: ${finalReason}${corrNote ? `\n• Teacher's Note: "${corrNote}"` : ''}\n\nThe academic team is monitoring this record.`
          : `📋 [Notification Académique - ${gradeToCorrect.subject}]\n${statusTitle}\n\n• Évaluation : ${gradeToCorrect.examName}\n• Note actuelle : ${corrScore}/${corrMaxScore}${isNewScoreDifferent ? ` (Initiale : ${previousScore}/${gradeToCorrect.maxScore})` : ''}\n• Motif : ${finalReason}${corrNote ? `\n• Message de l'enseignant : "${corrNote}"` : ''}\n\nL'équipe pédagogique reste à votre disposition pour tout échange complémentaire.`;

        const notificationMsg: any = {
          id: `msg_corr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          studentId: gradeToCorrect.studentId,
          parentId: gradeToCorrect.parentId || activeStudent?.parentId || '',
          senderType: 'Teacher',
          teacherName: pedManagerName || (language === 'en' ? 'Academic Supervisor' : 'Responsable Pédagogique'),
          senderRole: language === 'en' ? 'Teacher / Academic Staff' : 'Professeur / Direction Pédagogique',
          recipientName: language === 'en' ? 'Parents' : 'Parents d\'élèves',
          recipientRole: language === 'en' ? 'Parent' : 'Parent d\'élève',
          category: 'Grade',
          content: messageBody,
          timestamp: new Date().toISOString(),
          isRead: false,
        };

        await onSendMessage(notificationMsg);
      }

      setCorrectionSuccessMsg(
        corrStatus === 'PendingReview'
          ? (language === 'en' ? "Grade flagged for 'Pending Review' and notification sent to parents!" : "Note marquée 'En attente de révision' et notification envoyée aux parents avec succès !")
          : (language === 'en' ? "Grade successfully updated and parents notified!" : "Note mise à jour et notification transmise aux parents avec succès !")
      );
      setTimeout(() => setCorrectionSuccessMsg(null), 4500);
      setGradeToCorrect(null);
    } catch (err) {
      console.error("Failed to save grade correction:", err);
    } finally {
      setIsSavingCorrection(false);
    }
  };

  const handleToggleValidation = async () => {
    if (!activeStudent || !onUpdateStudent) return;
    const isCurrentlyValidated = !!activeStudent.gradesValidated;
    const confirmMsg = isCurrentlyValidated 
      ? `Voulez-vous invalider (déverrouiller) le bulletin de notes pour ${activeStudent.name} ? Cela permettra à nouveau les modifications par son enseignant.`
      : `Voulez-vous valider officiellement le bulletin de notes pour ${activeStudent.name} ? Une fois validé, plus aucune note ne pourra être ajoutée ou supprimée.`;
    
    if (window.confirm(confirmMsg)) {
      const updated: Student = {
        ...activeStudent,
        gradesValidated: !isCurrentlyValidated
      };
      await onUpdateStudent(updated);
    }
  };

  const handleExportGradesPDF = () => {
    const targetStudent = activeStudent || (allStudents && allStudents.length > 0 ? allStudents[0] : null);
    if (!targetStudent) {
      alert("Aucun élève sélectionné pour l'exportation du relevé de notes.");
      return;
    }

    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const now = new Date();
    let y = 15;
    const margin = 15;
    const pageWidth = 210;
    const pageHeight = 297;
    const contentWidth = pageWidth - (2 * margin); // 180mm
    let pageCount = 1;
    const isEn = language === 'en';

    const drawPageHeaderFooter = (num: number) => {
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.3);
      doc.line(margin, 12, margin + contentWidth, 12);
      
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184); // Slate 400
      const transcriptLabel = isEn 
        ? `Official Academic Transcript - ${targetStudent.name} • Class: ${targetStudent.grade} ${targetStudent.classRoom}`
        : `Relevé de Notes Officiel - ${targetStudent.name} • Classe : ${targetStudent.grade} ${targetStudent.classRoom}`;
      doc.text(transcriptLabel, margin, 9);
      
      doc.line(margin, pageHeight - 12, margin + contentWidth, pageHeight - 12);
      const pageLabel = isEn ? "Page" : "Page";
      doc.text(`${pageLabel} ${num}`, margin + contentWidth - 12, pageHeight - 8);
      const generatedLabel = isEn ? `Generated by PASMA-SYS Educational • Date of issue: ` : `Généré par PASMA-SYS Éducatif • Date d'édition : `;
      doc.text(`${generatedLabel}${now.toLocaleDateString(isEn ? 'en-US' : 'fr-FR')} ${now.toLocaleTimeString(isEn ? 'en-US' : 'fr-FR')}`, margin, pageHeight - 8);
    };

    drawPageHeaderFooter(pageCount);

    // Republic of Cameroon Official alignment with Motto
    const actCountry = settings?.country || "Cameroun";
    const countryLabel = isEn 
      ? (actCountry === "Cameroun" ? "REPUBLIC OF CAMEROON" : actCountry.toUpperCase())
      : (actCountry === "Cameroun" ? "RÉPUBLIQUE DU CAMEROUN" : actCountry.toUpperCase());

    const assocName = settings?.associationName || (isEn ? "PARENT TEACHER ASSOCIATION (PTA)" : "BUREAU DES PARENTS D'ÉLÈVES (APEE)");
    const schoolExtracted = settings?.associationName 
      ? settings.associationName.replace(/^(APEE|A\.P\.E\.E\.|Association des Parents d'élèves de l'|Association des Parents d'élèves du|Association des Parents d'élèves de|Association des Parents d'élèves|Association des Parents du|Association des Parents de|Association des Parents d'|Association des Parents|Association des Parents CES d')\s+/i, '').trim()
      : (isEn ? "CES d'Ekali 1" : "CES d'Ekali 1");
    const yearLabel = isEn ? "Academic Year" : "Année Académique";

    if (actCountry === "Cameroun") {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(51, 65, 85);
      doc.text("RÉPUBLIQUE DU CAMEROUN", margin, y + 4);
      doc.text("REPUBLIC OF CAMEROON", margin + contentWidth, y + 4, { align: 'right' });

      doc.setFont('helvetica', 'italic');
      doc.setFontSize(6.5);
      doc.setTextColor(148, 163, 184); // Slate 400
      doc.text("Paix - Travail - Patrie", margin, y + 7.5);
      doc.text("Peace - Work - Fatherland", margin + contentWidth, y + 7.5, { align: 'right' });

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(79, 70, 229); // Modern Indigo theme color
      doc.text(`${isEn ? 'School' : 'Établissement'} : ${schoolExtracted.toUpperCase()}`, margin, y + 11.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(51, 65, 85);
      doc.text(`${yearLabel} : ${settings?.schoolYear || "2025/2026"}`, margin + contentWidth, y + 11.5, { align: 'right' });
      
      y += 18;
    } else {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(51, 65, 85);
      doc.text(countryLabel, margin, y + 4);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(79, 70, 229);
      doc.text(`${isEn ? 'School' : 'Établissement'} : ${schoolExtracted.toUpperCase()}`, margin, y + 8.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(51, 65, 85);
      doc.text(`${yearLabel} : ${settings?.schoolYear || "2025/2026"}`, margin + contentWidth, y + 4, { align: 'right' });
      
      y += 15;
    }

    // Title Block
    doc.setFillColor(30, 41, 59); // Slate 800
    doc.rect(margin, y, contentWidth, 14, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(255, 255, 255);
    const mainTitle = isEn 
      ? "INDIVIDUAL ACADEMIC TRANSCRIPT - SCHOOL REPORT CARD" 
      : "RELEVÉ DE NOTES INDIVIDUEL - BULLETIN ACADÉMIQUE";
    doc.text(mainTitle, margin + 5, y + 9);

    y += 20;

    // Student Information Block
    doc.setFillColor(248, 250, 252);
    doc.rect(margin, y, contentWidth, 32, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(margin, y, contentWidth, 32, 'D');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42); // Slate 900
    doc.text(targetStudent.name.toUpperCase(), margin + 6, y + 7);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    const dobLabel = isEn 
      ? `Date of birth: ${targetStudent.dob ? new Date(targetStudent.dob).toLocaleDateString('en-US') : 'Not specified'}` 
      : `Date de naissance : ${targetStudent.dob ? new Date(targetStudent.dob).toLocaleDateString('fr-FR') : 'Non renseignée'}`;
    doc.text(dobLabel, margin + 6, y + 14);
    
    const classLabel = isEn 
      ? `Class / Grade: ${targetStudent.grade} • ${targetStudent.classRoom}` 
      : `Classe / Niveau : ${targetStudent.grade} • ${targetStudent.classRoom}`;
    doc.text(classLabel, margin + 6, y + 19);
    
    const statusLabel = isEn 
      ? `Administrative Status: REGISTERED STUDENT IN GOOD STANDING` 
      : `Statut Administratif : ÉLÈVE INSCRIT ET EN RÈGLE`;
    doc.text(statusLabel, margin + 6, y + 24);

    // Vertical Divider Line
    doc.setDrawColor(226, 232, 240);
    doc.line(margin + 92, y + 4, margin + 92, y + 28);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    const corpsTeacherLabel = isEn ? "TEACHING STAFF" : "CORPS ENSEIGNANT";
    doc.text(corpsTeacherLabel, margin + 97, y + 7);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    const principalTeacherLabel = isEn 
      ? `Main class teacher: ${targetStudent.teacherName || 'Not assigned'}` 
      : `Professeur principal : ${targetStudent.teacherName || 'Non assigné'}`;
    doc.text(principalTeacherLabel, margin + 97, y + 14);
    
    const contactEmailLabel = isEn 
      ? `Contact e-mail: ${targetStudent.teacherEmail || 'Not available'}` 
      : `Courriel de contact : ${targetStudent.teacherEmail || 'Non disponible'}`;
    doc.text(contactEmailLabel, margin + 97, y + 19);
    
    // Status Badge
    doc.setFillColor(238, 242, 255); // Indigo 50
    doc.rect(margin + 97, y + 22.5, 45, 5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(79, 70, 229); // Indigo 700
    const activeLabel = isEn ? "Active enrollment" : "Scolarisation active";
    doc.text(activeLabel, margin + 100, y + 26);

    y += 37;

    // Key stats
    const totalTestsNum = grades.length;
    const avgBase20Val = totalTestsNum > 0
      ? (grades.reduce((sum, g) => sum + (g.score / g.maxScore) * 20, 0) / totalTestsNum)
      : 0;

    const getApprecText = (avg: number) => {
      if (avg >= 16) return 'Très Bien (Excellent)';
      if (avg >= 14) return 'Bien';
      if (avg >= 12) return 'Assez Bien';
      if (avg >= 10) return 'Passable';
      return 'Insuffisant';
    };

    const getApprecTextEn = (avg: number) => {
      if (avg >= 16) return 'Excellent';
      if (avg >= 14) return 'Good';
      if (avg >= 12) return 'Satisfactory';
      if (avg >= 10) return 'Passing';
      return 'Insufficient';
    };

    const appText = getApprecText(avgBase20Val);

    // KPI Cards Block (Two side by side)
    const kpiWidth = (contentWidth - 6) / 2; // 87mm each

    // KPI Left: Average score
    doc.setFillColor(245, 247, 255); // Indigo light background
    doc.setDrawColor(199, 210, 254);
    doc.rect(margin, y, kpiWidth, 28, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(79, 70, 229);
    const kpiLeftTitle = isEn ? "GENERAL ACADEMIC GRADE AVERAGE" : "MOYENNE ACADÉMIQUE GÉNÉRALE";
    doc.text(kpiLeftTitle, margin + 5, y + 5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    const textAvgString = totalTestsNum > 0 ? `${avgBase20Val.toFixed(2)} / 20` : "-- / 20";
    doc.text(textAvgString, margin + 5, y + 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    const globalApp = isEn 
      ? `Overall remarks: ${totalTestsNum > 0 ? getApprecTextEn(avgBase20Val) : 'Not evaluated'}` 
      : `Mention globale : ${totalTestsNum > 0 ? appText : 'Non évalué'}`;
    doc.text(globalApp, margin + 5, y + 18);

    const classAverageLabel = isEn
      ? `Class average: ${classAverage} / 20 (${diffFromClass >= 0 ? '+' : ''}${diffFromClass.toFixed(2)} vs Class)`
      : `Moyenne de classe : ${classAverage} / 20 (${diffFromClass >= 0 ? '+' : ''}${diffFromClass.toFixed(2)} vs Classe)`;
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(51, 65, 85);
    doc.text(classAverageLabel, margin + 5, y + 23.5);

    // KPI Right: Total tests
    doc.setFillColor(240, 253, 244); // Green light background
    doc.setDrawColor(187, 247, 208);
    doc.rect(margin + kpiWidth + 6, y, kpiWidth, 28, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(21, 128, 61);
    const kpiRightTitle = isEn ? "COMPLETED TESTS & EXAMINATIONS" : "ÉVALUATIONS ET EXAMENS TERMINÉS";
    doc.text(kpiRightTitle, margin + kpiWidth + 11, y + 5);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    const completedEvalText = isEn ? `${totalTestsNum} tests` : `${totalTestsNum} éval.`;
    doc.text(completedEvalText, margin + kpiWidth + 11, y + 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    const bestGrade = totalTestsNum > 0
      ? Math.max(...grades.map(g => (g.score / g.maxScore) * 20)).toFixed(1)
      : '0.0';
    const bestPerfLabel = isEn ? `Best grade: ${bestGrade} / 20` : `Meilleure performance : ${bestGrade} / 20`;
    doc.text(bestPerfLabel, margin + kpiWidth + 11, y + 18);

    const rightSubLabel = isEn ? "Official school curriculum tracking" : "Suivi du programme scolaire officiel";
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(51, 65, 85);
    doc.text(rightSubLabel, margin + kpiWidth + 11, y + 23.5);

    y += 34;

    // Grades Table Block
    const checkPageBreak = (heightNeeded: number) => {
      if (y + heightNeeded > pageHeight - 20) {
        doc.addPage();
        pageCount++;
        drawPageHeaderFooter(pageCount);
        y = 25; // Reset y to top margin on new page
      }
    };

    checkPageBreak(15);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    const detailsHeaderTitle = isEn ? "DETAILED TRANSCRIPT & SUBJECT SCORES" : "DÉTAIL DES MOYENNES ET RELEVÉ DE NOTES";
    doc.text(detailsHeaderTitle, margin, y + 4);
    y += 8;

    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.35);
    doc.line(margin, y, margin + contentWidth, y);
    y += 4;

    // Header of Table
    doc.setFillColor(79, 70, 229); // Primary Indigo header
    doc.rect(margin, y, contentWidth, 7.5, 'F');
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(255, 255, 255);
    const colSubject = isEn ? "Discipline / Subject" : "Discipline / Matière";
    const colExam = isEn ? "Assessment / Exam" : "Nom de l'évaluation";
    const colDate = isEn ? "Date" : "Date";
    const colRaw = isEn ? "Raw Score" : "Note brute";
    const colBase20 = isEn ? "Rating (/20)" : "Météo (/20)";
    const colRemarks = isEn ? "Teacher Remarks" : "Appréciation d'enseignant";

    doc.text(colSubject, margin + 3.5, y + 5);
    doc.text(colExam, margin + 48, y + 5);
    doc.text(colDate, margin + 92, y + 5);
    doc.text(colRaw, margin + 112, y + 5);
    doc.text(colBase20, margin + 130, y + 5);
    doc.text(colRemarks, margin + 148, y + 5);

    y += 7.5;

    const truncate = (text: string, count: number) => {
      if (!text) return '';
      return text.length > count ? text.substring(0, count - 3) + "..." : text;
    };

    if (grades.length === 0) {
      checkPageBreak(10);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8.5);
      doc.setTextColor(148, 163, 184); // Slate 400
      const emptyTranscriptLabel = isEn ? "No grades recorded for this student yet." : "Aucun relevé de note n'a été inséré ou validé pour cet élève.";
      doc.text(emptyTranscriptLabel, margin + 4, y + 6);
      y += 10;
    } else {
      // Sort grades descending or chronological
      const sortedGrades = [...grades].sort((a, b) => b.date.localeCompare(a.date));

      sortedGrades.forEach((g, gIdx) => {
        checkPageBreak(8);

        if (gIdx % 2 === 0) {
          doc.setFillColor(248, 250, 252); // Soft zebra
          doc.rect(margin, y, contentWidth, 7, 'F');
        }

        doc.setDrawColor(241, 245, 249);
        doc.setLineWidth(0.15);
        doc.line(margin, y + 7, margin + contentWidth, y + 7);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.setTextColor(15, 23, 42); // Slate 900
        doc.text(truncate(g.subject, 18), margin + 3.5, y + 4.5);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7.5);
        doc.setTextColor(71, 85, 105);
        doc.text(truncate(g.examName, 20), margin + 48, y + 4.5);

        doc.text(new Date(g.date).toLocaleDateString(isEn ? 'en-US' : 'fr-FR'), margin + 92, y + 4.5);

        doc.setFont('helvetica', 'semibold');
        doc.text(`${g.score} / ${g.maxScore}`, margin + 112, y + 4.5);

        const relativeScore = (g.score / g.maxScore) * 20;
        if (relativeScore >= 10) {
          doc.setTextColor(16, 185, 129); // Green 500
          doc.setFont('helvetica', 'bold');
        } else {
          doc.setTextColor(239, 68, 68); // Red 500
          doc.setFont('helvetica', 'bold');
        }
        doc.text(`${relativeScore.toFixed(1)} / 20`, margin + 130, y + 4.5);

        doc.setFont('helvetica', 'italic');
        doc.setFontSize(7.5);
        doc.setTextColor(100, 116, 139);
        const commentLabel = truncate(g.teacherRemarks || (isEn ? 'No remarks' : 'Aucun commentaire.'), 20);
        doc.text(commentLabel, margin + 148, y + 4.5);

        y += 7;
      });
    }

    y += 10;

    // Signature Area
    checkPageBreak(35);
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.2);
    doc.line(margin, y, margin + contentWidth, y);
    y += 8;

    const signatureColWidth = contentWidth / 3;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    const pTeacher = isEn ? "HEAD CLASS TEACHER" : "LE PROFESSEUR PRINCIPAL";
    const dStudies = isEn ? "DIRECTOR OF STUDIES" : "LE DIRECTEUR DES ÉTUDES";
    const pSignature = isEn ? "PARENT / GUARDIAN SIGNATURE" : "SIGNATURE DES PARENTS";
    doc.text(pTeacher, margin + 5, y);
    doc.text(dStudies, margin + signatureColWidth + 5, y);
    doc.text(pSignature, margin + (signatureColWidth * 2) + 5, y);

    y += 4;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184);
    const stampSign = isEn ? "(Digital stamp & signed)" : "(Sceau et émargement)";
    const stampInst = isEn ? "(Official school seal)" : "(Cachet de l'institution)";
    const stampAuth = isEn ? "(Read and approved)" : "(Lu et approuvé)";
    doc.text(stampSign, margin + 5, y);
    doc.text(stampInst, margin + signatureColWidth + 5, y);
    doc.text(stampAuth, margin + (signatureColWidth * 2) + 5, y);

    // Save PDF file
    doc.save(`releve_de_notes_${(targetStudent.name || 'eleve').toLowerCase().replace(/[^a-z0-9]/g, '_')}.pdf`);
  };

  const handleExportTrendPDF = () => {
    if (!activeStudent) return;

    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const now = new Date();
    let y = 15;
    const margin = 15;
    const pageWidth = 210;
    const pageHeight = 297;
    const contentWidth = pageWidth - (2 * margin); // 180mm
    let pageCount = 1;
    const isEn = language === 'en';

    const drawPageHeaderFooter = (num: number) => {
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.3);
      doc.line(margin, 12, margin + contentWidth, 12);
      
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184); // Slate 400
      const transcriptLabel = isEn 
        ? `Academic Trend & Diagnostic Report - ${activeStudent.name} • Class: ${activeStudent.grade} ${activeStudent.classRoom}`
        : `Analyse de Tendance & Diagnostic Académique - ${activeStudent.name} • Classe : ${activeStudent.grade} ${activeStudent.classRoom}`;
      doc.text(transcriptLabel, margin, 9);
      
      doc.line(margin, pageHeight - 12, margin + contentWidth, pageHeight - 12);
      const pageLabel = isEn ? "Page" : "Page";
      doc.text(`${pageLabel} ${num}`, margin + contentWidth - 12, pageHeight - 8);
      const generatedLabel = isEn ? `Generated by PASMA-SYS Educational • Date of issue: ` : `Généré par PASMA-SYS Éducatif • Date d'édition : `;
      doc.text(`${generatedLabel}${now.toLocaleDateString(isEn ? 'en-US' : 'fr-FR')} ${now.toLocaleTimeString(isEn ? 'en-US' : 'fr-FR')}`, margin, pageHeight - 8);
    };

    drawPageHeaderFooter(pageCount);

    // Header Details
    const actCountry = settings?.country || "Cameroun";
    const countryLabel = isEn 
      ? (actCountry === "Cameroun" ? "REPUBLIC OF CAMEROON" : actCountry.toUpperCase())
      : (actCountry === "Cameroun" ? "RÉPUBLIQUE DU CAMEROUN" : actCountry.toUpperCase());

    const assocName = settings?.associationName || (isEn ? "PARENT TEACHER ASSOCIATION (PTA)" : "BUREAU DES PARENTS D'ÉLÈVES (APEE)");
    const schoolExtracted = settings?.associationName 
      ? settings.associationName.replace(/^(APEE|A\.P\.E\.E\.|Association des Parents d'élèves de l'|Association des Parents d'élèves du|Association des Parents d'élèves de|Association des Parents d'élèves|Association des Parents du|Association des Parents de|Association des Parents d'|Association des Parents|Association des Parents CES d')\s+/i, '').trim()
      : (isEn ? "CES d'Ekali 1" : "CES d'Ekali 1");
    const yearLabel = isEn ? "Academic Year" : "Année Académique";

    if (actCountry === "Cameroun") {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(51, 65, 85);
      doc.text("RÉPUBLIQUE DU CAMEROUN", margin, y + 4);
      doc.text("REPUBLIC OF CAMEROON", margin + contentWidth, y + 4, { align: 'right' });

      doc.setFont('helvetica', 'italic');
      doc.setFontSize(6.5);
      doc.setTextColor(148, 163, 184); // Slate 400
      doc.text("Paix - Travail - Patrie", margin, y + 7.5);
      doc.text("Peace - Work - Fatherland", margin + contentWidth, y + 7.5, { align: 'right' });

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(79, 70, 229); // Modern Indigo active theme color
      doc.text(`${isEn ? 'School' : 'Établissement'} : ${schoolExtracted.toUpperCase()}`, margin, y + 11.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(51, 65, 85);
      doc.text(`${yearLabel} : ${settings?.schoolYear || "2025/2026"}`, margin + contentWidth, y + 11.5, { align: 'right' });
      
      y += 18;
    } else {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(51, 65, 85);
      doc.text(countryLabel, margin, y + 4);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(79, 70, 229);
      doc.text(`${isEn ? 'School' : 'Établissement'} : ${schoolExtracted.toUpperCase()}`, margin, y + 8.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(51, 65, 85);
      doc.text(`${yearLabel} : ${settings?.schoolYear || "2025/2026"}`, margin + contentWidth, y + 4, { align: 'right' });
      
      y += 15;
    }

    // Title Block
    doc.setFillColor(15, 118, 110); // Teal 700 for trend/performance vibe
    doc.rect(margin, y, contentWidth, 14, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(255, 255, 255);
    const mainTitle = isEn 
      ? "STUDENT ACADEMIC TREND & DIAGNOSTIC PERFORMANCE REPORT" 
      : "RAPPORT DE DIAGNOSTIC & TENDANCE ACADÉMIQUE DE L'ÉLÈVE";
    doc.text(mainTitle, margin + 5, y + 9);

    y += 20;

    // Student Info Panel
    doc.setFillColor(248, 250, 252);
    doc.rect(margin, y, contentWidth, 24, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.rect(margin, y, contentWidth, 24, 'D');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text(activeStudent.name.toUpperCase(), margin + 6, y + 7);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(71, 85, 105);
    const dobLabel = isEn 
      ? `Date of Birth: ${activeStudent.dob ? new Date(activeStudent.dob).toLocaleDateString('en-US') : 'Not specified'}` 
      : `Date de naissance : ${activeStudent.dob ? new Date(activeStudent.dob).toLocaleDateString('fr-FR') : 'Non renseignée'}`;
    const classLabel = isEn 
      ? `Class / Grade: ${activeStudent.grade} • Classroom: ${activeStudent.classRoom}` 
      : `Classe / Niveau : ${activeStudent.grade} • Salle : ${activeStudent.classRoom}`;
    doc.text(`${dobLabel}  |  ${classLabel}`, margin + 6, y + 14);

    const teacherLabel = isEn
      ? `Main Class Teacher: ${activeStudent.teacherName || 'Not assigned'} (${activeStudent.teacherEmail || 'No email'})`
      : `Professeur Principal : ${activeStudent.teacherName || 'Non assigné'} (${activeStudent.teacherEmail || 'Pas de courriel'})`;
    doc.text(teacherLabel, margin + 6, y + 19);

    y += 30;

    // Compute metrics
    const totalTestsNum = grades.length;
    const avgBase20Val = totalTestsNum > 0
      ? (grades.reduce((sum, g) => sum + (g.score / g.maxScore) * 20, 0) / totalTestsNum)
      : 0;

    // Subject averages
    const subjectAveragesMap = new Map<string, { total: number; count: number }>();
    grades.forEach(g => {
      const score20 = (g.score / g.maxScore) * 20;
      const existing = subjectAveragesMap.get(g.subject) || { total: 0, count: 0 };
      subjectAveragesMap.set(g.subject, {
        total: existing.total + score20,
        count: existing.count + 1
      });
    });
    
    const subjectAveragesList = Array.from(subjectAveragesMap.entries()).map(([subj, data]) => ({
      subject: subj,
      average: Number((data.total / data.count).toFixed(1)),
      count: data.count
    })).sort((a, b) => b.average - a.average);

    const strongest = subjectAveragesList.length > 0 ? subjectAveragesList[0] : null;
    const weakest = subjectAveragesList.length > 0 ? subjectAveragesList[subjectAveragesList.length - 1] : null;

    // Standard deviation (volatility)
    const varianceVal = totalTestsNum > 0 ? (grades.reduce((acc, g) => {
      const score20 = (g.score / g.maxScore) * 20;
      return acc + Math.pow(score20 - avgBase20Val, 2);
    }, 0) / totalTestsNum) : 0;
    const stdDev = Math.sqrt(varianceVal);

    // Trend comparison (halves)
    const chronologicalGrades = [...grades].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    const halfIndex = Math.floor(chronologicalGrades.length / 2);
    const firstHalfGrades = chronologicalGrades.slice(0, halfIndex);
    const secondHalfGrades = chronologicalGrades.slice(halfIndex);
    const firstHalfAvg = firstHalfGrades.length > 0 ? (firstHalfGrades.reduce((acc, g) => acc + (g.score / g.maxScore) * 20, 0) / firstHalfGrades.length) : 0;
    const secondHalfAvg = secondHalfGrades.length > 0 ? (secondHalfGrades.reduce((acc, g) => acc + (g.score / g.maxScore) * 20, 0) / secondHalfGrades.length) : 0;
    const trendDiff = secondHalfAvg - firstHalfAvg;

    const getMentionStr = (avg: number) => {
      if (avg >= 16) return isEn ? 'Highest Honors' : 'Très Bien';
      if (avg >= 14) return isEn ? 'High Honors' : 'Bien';
      if (avg >= 12) return isEn ? 'Honors' : 'Assez Bien';
      if (avg >= 10) return isEn ? 'Pass' : 'Passable';
      return isEn ? 'Needs Improvement' : 'Insuffisant';
    };

    // Draw KPI Grid: 4 boxes
    const cardW = (contentWidth - 9) / 4; // Approx 42mm each
    const cardH = 22;

    // 1. General Average
    doc.setFillColor(240, 253, 250); // Teal 50
    doc.setDrawColor(153, 246, 228); // Teal 200
    doc.rect(margin, y, cardW, cardH, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(13, 148, 136); // Teal 600
    doc.text(isEn ? "GENERAL AVERAGE" : "MOYENNE GÉNÉRALE", margin + 3, y + 5);
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text(`${avgBase20Val.toFixed(2)}`, margin + 3, y + 13);
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    const mentionWithClass = `${getMentionStr(avgBase20Val)} | ${isEn ? 'Class' : 'Classe'} : ${classAverage}`;
    doc.text(mentionWithClass, margin + 3, y + 18);

    // 2. Consistency / Volatility (Std Dev)
    doc.setFillColor(245, 243, 255); // Purple 50
    doc.setDrawColor(216, 180, 254); // Purple 200
    doc.rect(margin + cardW + 3, y, cardW, cardH, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(124, 58, 237); // Purple 600
    doc.text(isEn ? "CONSISTENCY (SD)" : "ÉCART-TYPE (RÉGULARITÉ)", margin + cardW + 6, y + 5);
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text(`${stdDev.toFixed(2)}`, margin + cardW + 6, y + 13);
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    const consistencyLabel = stdDev < 1.5 
      ? (isEn ? "Highly Regular" : "Très Régulier") 
      : stdDev < 3.0 
        ? (isEn ? "Moderately Regular" : "Modérément Régulier") 
        : (isEn ? "Highly Volatile" : "Forte Volatilité");
    doc.text(consistencyLabel, margin + cardW + 6, y + 18);

    // 3. Trend Dynamic
    const trendBg = trendDiff > 0.5 
      ? { fill: [240, 253, 244], stroke: [187, 247, 208], text: [22, 163, 74], label: isEn ? "Improving" : "En Hausse" } // Green
      : trendDiff < -0.5 
        ? { fill: [254, 242, 242], stroke: [254, 202, 202], text: [220, 38, 38], label: isEn ? "Declining" : "En Baisse" } // Red
        : { fill: [248, 250, 252], stroke: [226, 232, 240], text: [100, 116, 139], label: isEn ? "Stable" : "Stable" }; // Slate

    doc.setFillColor(trendBg.fill[0], trendBg.fill[1], trendBg.fill[2]);
    doc.setDrawColor(trendBg.stroke[0], trendBg.stroke[1], trendBg.stroke[2]);
    doc.rect(margin + (cardW * 2) + 6, y, cardW, cardH, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(trendBg.text[0], trendBg.text[1], trendBg.text[2]);
    doc.text(isEn ? "PROGRESS TREND" : "DYNAMIQUE DE PROGRÈS", margin + (cardW * 2) + 9, y + 5);
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text(`${trendDiff >= 0 ? '+' : ''}${trendDiff.toFixed(2)}`, margin + (cardW * 2) + 9, y + 13);
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(trendBg.label, margin + (cardW * 2) + 9, y + 18);

    // 4. Completed Assessments
    doc.setFillColor(239, 246, 255); // Blue 50
    doc.setDrawColor(191, 219, 254); // Blue 200
    doc.rect(margin + (cardW * 3) + 9, y, cardW, cardH, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(37, 99, 235); // Blue 600
    doc.text(isEn ? "COMPLETED EXAMS" : "ÉVALUATIONS EFFECTUÉES", margin + (cardW * 3) + 12, y + 5);
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text(`${totalTestsNum}`, margin + (cardW * 3) + 12, y + 13);
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    const bestScoreVal = totalTestsNum > 0 ? Math.max(...grades.map(g => (g.score / g.maxScore) * 20)) : 0;
    doc.text(`${isEn ? 'Max:' : 'Max :'} ${bestScoreVal.toFixed(1)}/20`, margin + (cardW * 3) + 12, y + 18);

    y += cardH + 10;

    const checkPageBreak = (heightNeeded: number) => {
      if (y + heightNeeded > pageHeight - 20) {
        doc.addPage();
        pageCount++;
        drawPageHeaderFooter(pageCount);
        y = 25; // Reset y to top margin on new page
      }
    };

    // Diagnostics / Insights Box
    checkPageBreak(38);
    doc.setFillColor(255, 255, 255);
    doc.setDrawColor(226, 232, 240);
    doc.rect(margin, y, contentWidth, 34, 'FD');

    doc.setFillColor(241, 245, 249); // light blue gray title strip
    doc.rect(margin, y, contentWidth, 7, 'F');
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y + 7, margin + contentWidth, y + 7);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text(isEn ? "🔍 ACADEMIC DIAGNOSIS & RECOMMENDATIONS" : "🔍 SYNTHÈSE DU DIAGNOSTIC ACADÉMIQUE & RECOMMANDATIONS ÉDUCATIVES", margin + 4, y + 4.5);

    // Insights columns
    // Left: Strongest & Weakest
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(15, 23, 42);
    doc.text(isEn ? "Key Subjects Insights:" : "Analyse par Matières :", margin + 4, y + 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(71, 85, 105);
    if (strongest) {
      doc.text(`${isEn ? '• Main Strength:' : '• Point fort principal :'} ${strongest.subject} (Avg: ${strongest.average.toFixed(1)}/20)`, margin + 4, y + 17);
    } else {
      doc.text(`• ${isEn ? 'No strength identified' : 'Aucun point fort identifié'}`, margin + 4, y + 17);
    }

    if (weakest && strongest?.subject !== weakest.subject) {
      doc.text(`${isEn ? '• Area for Focus:' : '• Point d\'amélioration :'} ${weakest.subject} (Avg: ${weakest.average.toFixed(1)}/20)`, margin + 4, y + 22);
    } else {
      doc.text(`• ${isEn ? 'Consistent profile' : 'Profil homogène'}`, margin + 4, y + 22);
    }

    // Vertical line divider inside diagnostics
    doc.setDrawColor(226, 232, 240);
    doc.line(margin + 90, y + 9, margin + 90, y + 31);

    // Right: Personalized advice
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(15, 23, 42);
    doc.text(isEn ? "Personalized Educational Advice:" : "Conseil Pédagogique Personnalisé :", margin + 94, y + 12);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(51, 65, 85);

    let advice1 = '';
    let advice2 = '';
    if (avgBase20Val >= 14) {
      if (stdDev < 1.8) {
        advice1 = isEn 
          ? "Excellent profile with great consistency. The student performs solidly on every test."
          : "Excellent profil et travail très régulier. L'élève fait preuve d'une grande rigueur à chaque examen.";
        advice2 = isEn
          ? "Recommendation: Encourage them to participate in advanced study circles or peer-tutoring."
          : "Recommandation : Encourager l'élève à participer à des travaux d'approfondissement ou d'entraide.";
      } else {
        advice1 = isEn
          ? "Great averages, but shows slight fluctuations. Some topics are mastered better than others."
          : "Moyenne élevée mais volatile. Certaines thématiques sont maîtrisées brillamment, d'autres moins.";
        advice2 = isEn
          ? "Recommendation: Maintain focus during revisions to secure excellent results across all chapters."
          : "Recommandation : Stabiliser la rigueur lors des révisions pour uniformiser l'excellence.";
      }
    } else if (avgBase20Val >= 10) {
      if (stdDev < 1.8) {
        advice1 = isEn
          ? "Fair and highly consistent results. Work is methodical but could benefit from deeper study."
          : "Travail sérieux, régulier et convenable. L'élève assimile bien mais peut viser plus haut.";
        advice2 = isEn
          ? "Recommendation: Practice more mock exams to gain speed and reach the honors threshold."
          : "Recommandation : S'exercer sur des annales pour gagner en rapidité et franchir un palier.";
      } else {
        advice1 = isEn
          ? "Academic profile is highly inconsistent. Excellent grades are mixed with weaker ones."
          : "Profil scolaire en dents de scie. Des sommets de réussite alternent avec des notes fragiles.";
        advice2 = isEn
          ? "Recommendation: Review foundation methods and prepare worksheets to structure the learning."
          : "Recommandation : Revoir la méthodologie d'apprentissage et faire des fiches de synthèse.";
      }
    } else {
      advice1 = isEn
        ? "Fragile academic standing requiring immediate attention and focused support."
        : "Résultats d'ensemble fragiles. L'acquisition des notions fondamentales doit être surveillée.";
      advice2 = isEn
        ? "Recommendation: Implement an individual catch-up plan and contact the pedagogical team."
        : "Recommandation : Mettre en place un plan de soutien et travailler en binôme de manière ciblée.";
    }

    doc.text(advice1, margin + 94, y + 17, { maxWidth: contentWidth - 94 - 4 });
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 118, 110);
    doc.text(advice2, margin + 94, y + 25, { maxWidth: contentWidth - 94 - 4 });

    y += 42;

    // Subject Performance breakdown table
    checkPageBreak(30);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text(isEn ? "📊 DETAILED SUBJECT BY SUBJECT AVERAGES" : "📊 ANALYSE DÉTAILLÉE DES MOYENNES PAR DISCIPLINE", margin, y);
    y += 4;

    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, margin + contentWidth, y);
    y += 3;

    // Table Header
    doc.setFillColor(15, 118, 110); // Teal header
    doc.rect(margin, y, contentWidth, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(255, 255, 255);

    doc.text(isEn ? "Subject / Discipline" : "Discipline / Matière", margin + 4, y + 4.5);
    doc.text(isEn ? "Calculated Average" : "Moyenne Calculée", margin + 65, y + 4.5);
    doc.text(isEn ? "Number of Evaluations" : "Nombre d'Évaluations", margin + 105, y + 4.5);
    doc.text(isEn ? "Indicative Status / Remarks" : "Appréciation indicative", margin + 145, y + 4.5);

    y += 7;

    const truncate = (text: string, count: number) => {
      if (!text) return '';
      return text.length > count ? text.substring(0, count - 3) + "..." : text;
    };

    if (subjectAveragesList.length === 0) {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text(isEn ? "No subjects recorded yet." : "Aucune matière enregistrée pour le moment.", margin + 4, y + 5);
      y += 8;
    } else {
      subjectAveragesList.forEach((subj, idx) => {
        checkPageBreak(8);
        if (idx % 2 === 0) {
          doc.setFillColor(248, 250, 252);
          doc.rect(margin, y, contentWidth, 6.5, 'F');
        }
        doc.setDrawColor(241, 245, 249);
        doc.line(margin, y + 6.5, margin + contentWidth, y + 6.5);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.setTextColor(51, 65, 85);
        doc.text(subj.subject, margin + 4, y + 4.5);

        // Average with conditional color
        if (subj.average >= 14) {
          doc.setTextColor(16, 185, 129); // Green
        } else if (subj.average >= 10) {
          doc.setTextColor(37, 99, 235); // Blue
        } else {
          doc.setTextColor(239, 68, 68); // Red
        }
        doc.text(`${subj.average.toFixed(1)} / 20`, margin + 65, y + 4.5);

        doc.setFont('helvetica', 'normal');
        doc.setTextColor(100, 116, 139);
        doc.text(`${subj.count} eval${subj.count > 1 ? 's' : ''}`, margin + 105, y + 4.5);

        // Status text
        doc.setFont('helvetica', 'italic');
        let statusText = '';
        if (subj.average >= 16) {
          statusText = isEn ? "Excellent standing" : "Excellent niveau";
        } else if (subj.average >= 14) {
          statusText = isEn ? "Solid achievements" : "Niveau satisfaisant";
        } else if (subj.average >= 12) {
          statusText = isEn ? "Honorable progress" : "Assez bon niveau";
        } else if (subj.average >= 10) {
          statusText = isEn ? "Passing grade" : "Niveau moyen, doit consolider";
        } else {
          statusText = isEn ? "Needs support" : "Lacunes à combler d'urgence";
        }
        doc.text(statusText, margin + 145, y + 4.5);

        y += 6.5;
      });
    }

    y += 8;

    // Chronological evaluations summary
    checkPageBreak(30);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text(isEn ? "📈 CHRONOLOGICAL HISTORY & PROGRESS PATH" : "📈 LOG CHRONOLOGIQUE DES NOTES ET PARCOURS DE PROGRESSION", margin, y);
    y += 4;

    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, margin + contentWidth, y);
    y += 3;

    // Small timeline grid
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setFillColor(15, 118, 110);
    
    const timelineGrades = chronologicalGrades.slice(-8); // Show up to last 8 evaluations for trend
    if (timelineGrades.length === 0) {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text(isEn ? "No grades chronological history." : "Historique chronologique indisponible.", margin + 4, y + 5);
      y += 8;
    } else {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.setTextColor(100, 116, 139);
      doc.text(isEn ? "Showing last 8 evaluations in order of occurrence:" : "Affichage des 8 dernières évaluations dans l'ordre d'évaluation :", margin + 4, y + 4);
      y += 6;

      timelineGrades.forEach((g, idx) => {
        checkPageBreak(7.5);
        doc.setFillColor(248, 250, 252);
        doc.rect(margin, y, contentWidth, 6, 'F');
        doc.setDrawColor(241, 245, 249);
        doc.line(margin, y + 6, margin + contentWidth, y + 6);

        doc.setFont('helvetica', 'semibold');
        doc.setTextColor(71, 85, 105);
        doc.text(`[#${idx + 1}]  ${new Date(g.date).toLocaleDateString(isEn ? 'en-US' : 'fr-FR')}`, margin + 4, y + 4);

        doc.setFont('helvetica', 'normal');
        doc.text(`${g.subject}  -  ${truncate(g.examName, 25)}`, margin + 35, y + 4);

        const score20 = (g.score / g.maxScore) * 20;
        doc.setFont('helvetica', 'bold');
        if (score20 >= 14) doc.setTextColor(16, 185, 129);
        else if (score20 >= 10) doc.setTextColor(37, 99, 235);
        else doc.setTextColor(239, 68, 68);
        doc.text(`${g.score}/${g.maxScore} (${score20.toFixed(1)}/20)`, margin + 140, y + 4);

        y += 6;
      });
    }

    y += 10;

    // Signatures
    checkPageBreak(30);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, y, margin + contentWidth, y);
    y += 6;

    const colW = contentWidth / 3;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    
    doc.text(isEn ? "HEAD CLASS TEACHER" : "LE PROFESSEUR PRINCIPAL", margin + 5, y);
    doc.text(isEn ? "COUNSELOR / DIR. OF STUDIES" : "CONSEILLER D'ORIENTATION / DIR.", margin + colW + 5, y);
    doc.text(isEn ? "PARENT SIGNATURE" : "SIGNATURE DES PARENTS", margin + (colW * 2) + 5, y);

    y += 4;
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(6.5);
    doc.setTextColor(148, 163, 184);
    doc.text(isEn ? "(Evaluated & Signed)" : "(Évalué et signé)", margin + 5, y);
    doc.text(isEn ? "(Approved & Verified)" : "(Approuvé et visé)", margin + colW + 5, y);
    doc.text(isEn ? "(Read & Approved)" : "(Lu et approuvé)", margin + (colW * 2) + 5, y);

    doc.save(`diagnostic_tendance_${(activeStudent.name || '').toLowerCase().replace(/[^a-z0-9]/g, '_')}.pdf`);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border border-gray-150 p-4 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans text-gray-900 tracking-tight flex items-center gap-2">
            <Award className="h-5 w-5 text-indigo-600" />
            Bulletins de Notes & Évaluations
          </h2>
          <p className="text-sm text-gray-500 mt-0.5">
            Suivi académique détaillé, moyennes pondérées et appréciations par matière.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {(activeStudent || (allStudents && allStudents.length > 0)) && (
            <>
              <button
                onClick={handleExportGradesPDF}
                className="px-3.5 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md active:scale-97 border border-indigo-500/30"
                title="Télécharger le relevé de notes au format PDF officiel"
                type="button"
              >
                <FileText className="h-4 w-4 text-indigo-200" />
                <span>Exporter en PDF</span>
              </button>

              <button
                onClick={handleExportTrendPDF}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md active:scale-97"
                title={language === 'fr' ? "Exporter le diagnostic et rapport de tendance en PDF" : "Export diagnostic & trend report as PDF"}
                type="button"
              >
                <TrendingUp className="h-4 w-4 text-emerald-200" /> {language === 'fr' ? 'Rapport de Tendance' : 'Trend Report'}
              </button>
            </>
          )}

          {onPrintReport && (
            <button
              onClick={onPrintReport}
              className="px-3.5 py-2 bg-white text-gray-700 border border-gray-250 hover:bg-gray-50 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-3xs"
            >
              <Printer className="h-4 w-4" /> Imprimer le Bulletin
            </button>
          )}

          <button
            onClick={handleOpenForm}
            disabled={!!activeStudent?.gradesValidated}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs ${
              activeStudent?.gradesValidated
                ? 'bg-slate-100 text-slate-400 border border-slate-205 cursor-not-allowed'
                : 'bg-slate-900 hover:bg-slate-850 text-white'
            }`}
          >
            <Plus className="h-4 w-4" /> Introduire Note
          </button>
        </div>
      </div>

      {/* View Switcher: Individual Student vs Classroom Analysis */}
      <div className="flex bg-slate-100 p-1 rounded-xl self-start gap-1 max-w-md border border-slate-200/40 select-none" id="grades-view-switcher">
        <button
          type="button"
          onClick={() => setDashboardMode('individual')}
          className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition-all duration-200 ${
            dashboardMode === 'individual'
              ? 'bg-white text-indigo-700 shadow-xs border border-indigo-100/80'
              : 'text-slate-500 hover:text-slate-950'
          }`}
        >
          <Award className="h-4 w-4 text-indigo-600" />
          {language === 'fr' ? 'Suivi Individuel (Bulletin)' : 'Individual Tracking (Report)'}
        </button>
        <button
          type="button"
          onClick={() => setDashboardMode('classroom')}
          className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition-all duration-200 ${
            dashboardMode === 'classroom'
              ? 'bg-white text-indigo-700 shadow-xs border border-indigo-100/80'
              : 'text-slate-500 hover:text-slate-950'
          }`}
        >
          <Activity className="h-4 w-4 text-emerald-600 animate-pulse" />
          {language === 'fr' ? 'Analyse Collective Classe' : 'Classroom View (Collective)'}
        </button>
      </div>

      {dashboardMode === 'classroom' ? (
        <ClassroomViewD3
          allGrades={allGrades}
          allStudents={allStudents}
          activeStudent={activeStudent}
          language={language}
        />
      ) : (
        <>
          {/* Validated Bulletin Banner locked status */}
      {activeStudent?.gradesValidated && (
        <div className="p-4 rounded-2xl border bg-amber-50/50 text-amber-950 border-amber-250 text-xs flex items-center gap-3 animate-fade-in shadow-2xs">
          <Lock className="h-5 w-5 text-amber-600 shrink-0" />
          <div className="space-y-0.5">
            <span className="font-extrabold uppercase tracking-wide text-[10px] text-amber-800 flex items-center gap-1">
              🔒 Bulletin de Notes Officiellement Validé & Scellé
            </span>
            <p className="font-medium text-amber-900">
              Le responsable pédagogique a validé le relevé de notes pour <strong>{activeStudent.name}</strong>. Plus aucune modification, ajout ou suppression de note n'est autorisée.
            </p>
          </div>
        </div>
      )}

      {/* Security Status Header */}
      {hasPedPassword && (
        <div className={`p-4 rounded-2xl border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
          isPedAuthorized ? 'bg-emerald-50 text-emerald-950 border-emerald-150' : 'bg-slate-50 text-slate-800 border-slate-150'
        }`}>
          <div className="flex items-center gap-2">
            {isPedAuthorized ? (
              <Unlock className="h-4.5 w-4.5 text-emerald-600 shrink-0" />
            ) : (
              <Lock className="h-4.5 w-4.5 text-slate-500 shrink-0" />
            )}
            <div>
              <span className="font-extrabold flex items-center gap-1.5 uppercase tracking-wide text-[10px] text-slate-650">
                {isPedAuthorized ? '🔓 Mode Responsable Débloqué' : '🔒 Niveau de Sécurité Responsable Pédagogique'}
              </span>
              <p className="font-medium text-slate-600 mt-0.5">
                {isPedAuthorized 
                  ? `Qualité accréditée : ${pedManagerName || "Surveillant Général / Censeur"}`
                  : `La validation ou l'invalidation officielle du bulletin de l'élève requiert le mot de passe de direction.`}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {isPedAuthorized && activeStudent && (
              <button
                type="button"
                onClick={handleToggleValidation}
                className={`px-3 py-1.5 font-bold rounded-lg text-[10px] uppercase tracking-wider transition cursor-pointer shrink-0 border ${
                  activeStudent.gradesValidated 
                    ? 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100' 
                    : 'bg-emerald-600 border-emerald-500 text-white hover:bg-emerald-700'
                }`}
              >
                {activeStudent.gradesValidated ? '🔓 Invalider le Bulletin' : '🔒 Valider le Bulletin'}
              </button>
            )}

            {!isPedAuthorized && onPromptUnlockPed && (
              <button
                onClick={onPromptUnlockPed}
                className="px-3 py-1.5 bg-white text-slate-800 border border-slate-250 font-bold rounded-lg text-[10px] hover:bg-slate-50 uppercase tracking-wider transition cursor-pointer shrink-0"
              >
                Saisir mot de passe
              </button>
            )}
          </div>
        </div>
      )}

      {/* Add Grade Section Form */}
      <AnimatePresence>
        {showAddForm && activeStudent && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form onSubmit={handleSubmit} className="bg-slate-50 border border-slate-200 p-5 rounded-2xl space-y-4 shadow-3xs">
              <div className="flex items-center justify-between border-b border-slate-205 pb-2 select-none">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
                  📝 Introduire une note officielle pour {activeStudent.name}
                </h3>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="text-xs text-gray-400 hover:text-gray-600 font-bold uppercase transition cursor-pointer"
                >
                  Annuler
                </button>
              </div>

              {(() => {
                const isScoreOverMax = score > maxScore;
                return (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-600 uppercase">
                          Matière / Discipline <span className="text-red-500">*</span>
                        </label>
                        <select
                          value={subject}
                          onChange={(e) => setSubject(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-indigo-500 font-medium text-slate-850"
                        >
                          {configuredSubjectsList.map((s) => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                          <option value="__custom__">✏️ Autre matière sur-mesure...</option>
                        </select>
                        {(subject === '__custom__' || subject === 'Autre') && (
                          <input
                            type="text"
                            placeholder="Saisir la matière..."
                            value={customSubject}
                            onChange={(e) => setCustomSubject(e.target.value)}
                            className="w-full mt-1.5 px-2.5 py-1 text-xs border border-indigo-200 rounded-md focus:outline-indigo-500 bg-white"
                          />
                        )}
                      </div>

                      <div className="md:col-span-2 space-y-1">
                        <label className="text-[10px] font-bold text-slate-600 uppercase">
                          Intitulé de l'Évaluation <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={examName}
                          onChange={(e) => setExamName(e.target.value)}
                          placeholder="Ex: Devoir Harmonisé / Examen Trimestre 1"
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-indigo-500 font-medium text-slate-800"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-600 uppercase">
                          Date de l'évaluation <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="date"
                          required
                          value={gradeDate}
                          onChange={(e) => setGradeDate(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-indigo-500 font-medium text-slate-800"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-600 uppercase">
                          Note obtenue <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          step="0.25"
                          required
                          min="0"
                          max={maxScore}
                          value={score}
                          onChange={(e) => setScore(Number(e.target.value))}
                          className={`w-full px-3 py-2 text-xs font-medium rounded-lg transition duration-200 focus:outline-none ${
                            isScoreOverMax
                              ? 'bg-red-50 border-2 border-red-500 text-red-950 focus:ring-2 focus:ring-red-200'
                              : 'bg-white border border-slate-200 text-slate-800 focus:outline-indigo-500'
                          }`}
                        />
                        {isScoreOverMax && (
                          <div className="flex items-center gap-1 text-[10px] font-extrabold text-red-600 mt-1 select-none animate-pulse">
                            <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                            <span>La note ne peut pas dépasser {maxScore} !</span>
                          </div>
                        )}
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-600 uppercase">
                          Sur (/ Max possible) <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          required
                          min="1"
                          value={maxScore}
                          onChange={(e) => setMaxScore(Number(e.target.value))}
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-indigo-500 font-medium text-slate-805"
                        />
                      </div>

                      <div className="md:col-span-2 space-y-1">
                        <label className="text-[10px] font-bold text-slate-600 uppercase">Appréciation / Remarques</label>
                        <input
                          type="text"
                          value={remarks}
                          onChange={(e) => setRemarks(e.target.value)}
                          placeholder="Ex: Excellent trimestre, poursuivez ainsi."
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-indigo-500 font-medium text-slate-800"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2.5 pt-2">
                      <button
                        type="button"
                        onClick={() => setShowAddForm(false)}
                        className="px-4 py-2 border border-slate-250 bg-white text-slate-800 text-xs font-bold uppercase tracking-wider rounded-lg hover:bg-slate-50 cursor-pointer text-center"
                      >
                        Annuler
                      </button>
                      <button
                        type="submit"
                        disabled={isScoreOverMax}
                        className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg flex items-center gap-1 transition duration-200 text-center shadow-xs ${
                          isScoreOverMax
                            ? 'bg-slate-200 border border-slate-300 text-slate-400 cursor-not-allowed opacity-75'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
                        }`}
                      >
                        <CheckCircle className="h-4 w-4" /> Enregistrer Note
                      </button>
                    </div>
                  </>
                );
              })()}
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {grades.length === 0 ? (
        <div className="text-center p-12 bg-gray-50/50 rounded-2xl border border-gray-100 select-none">
          <BookOpen className="h-8 w-8 text-gray-400 mx-auto mb-2" />
          <p className="text-sm text-gray-500 font-medium">Aucune note enregistrée pour cet élève.</p>
        </div>
      ) : (
        <>
          {/* Key Stats Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-5 rounded-2xl border flex flex-col justify-between ${getAverageBadgeColor(Number(averageMark))}`}
            >
              <div className="flex items-center justify-between w-full">
                <div className="space-y-1">
                  <span className="text-xs uppercase tracking-wider font-semibold opacity-80">Moyenne Générale</span>
                  <div className="text-3xl font-black flex items-baseline gap-1">
                    {averageMark} <span className="text-xs font-normal opacity-70">/ 20</span>
                  </div>
                </div>
                <TrendingUp className="h-10 w-10 opacity-30" />
              </div>
              <div className="mt-2.5 text-[11px] font-bold flex items-center gap-1.5 opacity-90">
                {isAboveClass ? (
                  <span className="bg-white/30 text-emerald-950 px-2 py-0.5 rounded-md flex items-center gap-0.5">
                    ▲ +{diffFromClass.toFixed(1)} {language === 'fr' ? 'vs classe' : 'vs class'}
                  </span>
                ) : isEqualClass ? (
                  <span className="bg-white/30 text-slate-900 px-2 py-0.5 rounded-md">
                    = {language === 'fr' ? 'moyenne classe' : 'class average'}
                  </span>
                ) : (
                  <span className="bg-white/35 text-rose-950 px-2 py-0.5 rounded-md flex items-center gap-0.5">
                    ▼ {diffFromClass.toFixed(1)} {language === 'fr' ? 'vs classe' : 'vs class'}
                  </span>
                )}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              className="p-5 bg-white border border-gray-100 rounded-2xl flex items-center justify-between"
            >
              <div className="space-y-1">
                <span className="text-xs uppercase tracking-wider font-semibold text-gray-500">Moyenne de la Classe</span>
                <div className="text-3xl font-bold text-slate-800 flex items-baseline gap-1">
                  {classAverage} <span className="text-xs font-normal text-gray-400">/ 20</span>
                </div>
                <div className="text-[10px] text-gray-400 font-medium">
                  {language === 'fr' ? `Calculée sur ${classStudents.length} élève(s)` : `Based on ${classStudents.length} student(s)`}
                </div>
              </div>
              <BarChart2 className="h-10 w-10 text-indigo-100" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="p-5 bg-white border border-gray-100 rounded-2xl flex items-center justify-between"
            >
              <div className="space-y-1">
                <span className="text-xs uppercase tracking-wider font-semibold text-gray-500">Évaluations Terminées</span>
                <div className="text-3xl font-bold text-gray-900">{filteredGrades.length}</div>
              </div>
              <BookOpen className="h-10 w-10 text-indigo-100" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="p-5 bg-white border border-gray-100 rounded-2xl flex items-center justify-between"
            >
              <div className="space-y-1">
                <span className="text-xs uppercase tracking-wider font-semibold text-gray-500">Meilleure Note</span>
                <div className="text-3xl font-bold text-gray-900 flex items-baseline gap-1">
                  {filteredGrades.length > 0
                    ? Math.max(...filteredGrades.map(g => (g.score / g.maxScore) * 20)).toFixed(1)
                    : '0'
                  }
                  <span className="text-xs font-normal text-gray-400">/ 20</span>
                </div>
              </div>
              <Sparkles className="h-10 w-10 text-emerald-100" />
            </motion.div>
          </div>

          {/* Graphic Section */}
          {chartData.length > 0 && (() => {
            const visualTabs = [
              { id: 'overall_d3', label: language === 'fr' ? 'Évolution Moyenne (D3)' : 'D3 Overall Average', icon: TrendingUp },
              { id: 'trends', label: language === 'fr' ? 'Tendances de notes' : 'Grade Trends', icon: Activity },
              { id: 'subjects', label: language === 'fr' ? 'Matières & Comparatif' : 'Subjects Comparison', icon: BarChart2 },
              { id: 'distribution', label: language === 'fr' ? 'Répartition / Distribution' : 'Grade Distribution', icon: Activity },
              { id: 'diagnostic', label: language === 'fr' ? 'Diagnostic Académique' : 'Academic Insights', icon: Sparkles }
            ] as const;

            return (
              <motion.div
                initial={{ opacity: 0, scale: 0.99 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-5 bg-white border border-gray-150 rounded-2xl space-y-4 shadow-sm"
              >
                {/* Header with Visual Tabs */}
                <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl shrink-0 animate-pulse">
                      <Activity className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                        {language === 'fr' ? 'Tableau de Bord de Performance' : 'Student Performance Dashboard'}
                      </h3>
                      <p className="text-[10px] text-gray-500 font-medium">
                        {language === 'fr' 
                          ? 'Analyses visuelles de la progression et diagnostic complet.'
                          : 'Visual analysis of student performance, trends, and diagnostic key points.'}
                      </p>
                    </div>
                  </div>

                  {/* Tab Switchers */}
                  <div className="flex flex-wrap bg-slate-50 p-1 rounded-xl border border-slate-100 gap-1 self-start xl:self-auto">
                    {visualTabs.map((tab) => {
                      const Icon = tab.icon;
                      const isActive = activeVisualTab === tab.id;
                      return (
                        <button
                          key={tab.id}
                          onClick={() => setActiveVisualTab(tab.id)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer flex items-center gap-1.5 transition-all duration-200 ${
                            isActive
                              ? 'bg-white text-indigo-700 shadow-xs border border-indigo-100/80'
                              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100/50'
                          }`}
                        >
                          <Icon className={`h-3.5 w-3.5 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                          <span>{tab.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Tab Contents */}
                <div className="w-full pt-2">
                  {isMounted ? (
                    <AnimatePresence mode="wait">
                      {activeVisualTab === 'overall_d3' && (
                        <motion.div
                          key="overall_d3"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="w-full"
                        >
                          <StudentAverageTrendD3
                            grades={filteredGrades}
                            classAverage={classAverageNum}
                            language={language}
                          />
                        </motion.div>
                      )}

                      {activeVisualTab === 'trends' && (
                        <motion.div
                          key="trends"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="h-76 flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 px-1 mb-2">
                            <span>
                              {language === 'fr'
                                ? 'Évolution chronologique de toutes les évaluations converties sur 20.'
                                : 'Chronological progression of evaluations normalized to 20.'}
                            </span>
                            <span className="text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded-md">
                              {language === 'fr' ? 'Filtre matière : ' : 'Filter Subject: '}{selectedSubject === 'all' ? (language === 'fr' ? 'Toutes' : 'All') : selectedSubject}
                            </span>
                          </div>
                          <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                              <AreaChart data={chartData} margin={{ top: 15, right: 15, left: -22, bottom: 5 }}>
                                <defs>
                                  <linearGradient id="scoreColorGrad" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25}/>
                                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.00}/>
                                  </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                                <XAxis 
                                  dataKey="date" 
                                  tickLine={false}
                                  axisLine={false}
                                  tickStyle={{ fontSize: 10, fill: '#64748b', fontWeight: 500 }} 
                                  dy={8}
                                />
                                <YAxis 
                                  domain={[0, 20]} 
                                  tickCount={11}
                                  tickLine={false}
                                  axisLine={false}
                                  tickStyle={{ fontSize: 10, fill: '#64748b', fontWeight: 500 }} 
                                  dx={-4}
                                />
                                <Tooltip
                                  contentStyle={{
                                    border: '1px solid #e2e8f0',
                                    borderRadius: '14px',
                                    boxShadow: '0 8px 16px -2px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05)',
                                    fontSize: '11px',
                                    padding: '10px 14px'
                                  }}
                                  formatter={(value: any, name: string, props: any) => {
                                    const payload = props.payload;
                                    const scoreColor = value >= 10 ? 'text-emerald-700 font-extrabold' : 'text-rose-600 font-extrabold';
                                    return [
                                      <div className="space-y-1" key="content">
                                        <div className="flex items-center gap-1.5 font-bold text-slate-800">
                                          <span>{language === 'fr' ? 'Matière :' : 'Subject:'}</span>
                                          <span className="bg-slate-100 px-2 py-0.5 rounded text-[10px] text-indigo-700 font-bold">{payload.subject}</span>
                                        </div>
                                        <div className="text-slate-600 font-medium">{language === 'fr' ? 'Éval :' : 'Exam:'} <span className="font-semibold text-slate-900">{payload.examName}</span></div>
                                        <div className="pt-1 text-xs border-t border-slate-100 flex items-center justify-between gap-3">
                                          <span className="text-gray-500 font-sans">{language === 'fr' ? 'Note :' : 'Grade:'}</span>
                                          <span className={scoreColor}>{value} / 20</span>
                                        </div>
                                      </div>,
                                      null
                                    ];
                                  }}
                                  labelFormatter={(label) => `📅 ${language === 'fr' ? 'Date de l\'évaluation' : 'Assessment date'} : ${label}`}
                                />
                                
                                <ReferenceLine 
                                  y={10} 
                                  stroke="#f43f5e" 
                                  strokeDasharray="4 4" 
                                  strokeWidth={1.25}
                                  label={{ 
                                    value: language === 'fr' ? 'Moyenne requise (10/20)' : 'Passing mark (10/20)', 
                                    fill: '#f43f5e', 
                                    fontSize: 8.5, 
                                    position: 'insideBottomRight', 
                                    offset: 7, 
                                    fontWeight: 'bold' 
                                  }} 
                                />

                                <Area
                                  type="monotone"
                                  dataKey="score"
                                  stroke="#4f46e5"
                                  strokeWidth={3}
                                  fillOpacity={1}
                                  fill="url(#scoreColorGrad)"
                                  dot={{ r: 4, fill: '#4f46e5', stroke: '#ffffff', strokeWidth: 1.5 }}
                                  activeDot={{ r: 6, stroke: '#4f46e5', strokeWidth: 2, fill: '#ffffff' }}
                                  name="Note"
                                />
                              </AreaChart>
                            </ResponsiveContainer>
                          </div>
                        </motion.div>
                      )}

                      {activeVisualTab === 'subjects' && (
                        <motion.div
                          key="subjects"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="h-full flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 px-1 mb-2">
                            <span>
                              {language === 'fr' 
                                ? 'Moyenne générale calculée par matière.' 
                                : 'Calculated average for each subject.'}
                            </span>
                            <span className="text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-md text-[10px]">
                              {language === 'fr' ? `${subjectAveragesData.length} Matière(s)` : `${subjectAveragesData.length} Subject(s)`}
                            </span>
                          </div>
                          <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                              <BarChart data={subjectAveragesData} margin={{ top: 15, right: 15, left: -22, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                                <XAxis 
                                  dataKey="subject" 
                                  tickLine={false}
                                  axisLine={false}
                                  tickStyle={{ fontSize: 9, fill: '#64748b', fontWeight: 600 }} 
                                  dy={8}
                                />
                                <YAxis 
                                  domain={[0, 20]} 
                                  tickCount={6}
                                  tickLine={false}
                                  axisLine={false}
                                  tickStyle={{ fontSize: 10, fill: '#64748b', fontWeight: 500 }} 
                                  dx={-4}
                                />
                                <Tooltip
                                  contentStyle={{
                                    border: '1px solid #e2e8f0',
                                    borderRadius: '12px',
                                    boxShadow: '0 4px 12px rgba(0,0,0,0.05)',
                                    fontSize: '11px',
                                  }}
                                  formatter={(value: any, name: string) => {
                                    const displayName = name === 'average' 
                                      ? (language === 'fr' ? 'Moyenne de l\'Élève' : 'Student Average') 
                                      : (language === 'fr' ? 'Moyenne de la Classe' : 'Class Average');
                                    return [`${value} / 20`, displayName];
                                  }}
                                />
                                <Legend 
                                  verticalAlign="top" 
                                  height={32} 
                                  iconSize={10} 
                                  wrapperStyle={{ fontSize: '10px', fontWeight: 600 }} 
                                />
                                <ReferenceLine 
                                  y={10} 
                                  stroke="#f43f5e" 
                                  strokeDasharray="4 4" 
                                  strokeWidth={1}
                                />
                                <Bar 
                                  dataKey="average" 
                                  name={language === 'fr' ? "Moyenne de l'Élève" : "Student Average"}
                                  radius={[4, 4, 0, 0]} 
                                  maxBarSize={25}
                                  fill="#4f46e5"
                                />
                                <Bar 
                                  dataKey="classAverage" 
                                  name={language === 'fr' ? "Moyenne de la Classe" : "Class Average"}
                                  radius={[4, 4, 0, 0]} 
                                  maxBarSize={25}
                                  fill="#94a3b8"
                                />
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        </motion.div>
                      )}

                      {activeVisualTab === 'distribution' && (
                        <motion.div
                          key="distribution"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="h-full flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 px-1 mb-2">
                            <span>
                              {language === 'fr' 
                                ? 'Répartition des évaluations de l\'élève selon le barème officiel.' 
                                : 'Grade frequency distribution within academic brackets.'}
                            </span>
                          </div>
                          <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
                              <BarChart data={distributionData} margin={{ top: 15, right: 15, left: -22, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                                <XAxis 
                                  dataKey="range" 
                                  tickLine={false}
                                  axisLine={false}
                                  tickStyle={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} 
                                  dy={8}
                                />
                                <YAxis 
                                  allowDecimals={false}
                                  tickLine={false}
                                  axisLine={false}
                                  tickStyle={{ fontSize: 10, fill: '#64748b', fontWeight: 500 }} 
                                  dx={-4}
                                />
                                <Tooltip
                                  contentStyle={{
                                    border: '1px solid #e2e8f0',
                                    borderRadius: '12px',
                                    fontSize: '11px',
                                  }}
                                  formatter={(value: any, name: string, props: any) => {
                                    const payload = props.payload;
                                    return [
                                      <div className="space-y-0.5" key="content">
                                        <div className="font-bold text-slate-800">{payload.label} ({payload.range})</div>
                                        <div className="text-indigo-600 font-extrabold">{value} {language === 'fr' ? 'évaluations' : 'evaluations'}</div>
                                      </div>,
                                      null
                                    ];
                                  }}
                                />
                                <Bar 
                                  dataKey="count" 
                                  radius={[8, 8, 0, 0]} 
                                  maxBarSize={55}
                                >
                                  {distributionData.map((entry, idx) => (
                                    <Cell key={`cell-${idx}`} fill={entry.fill} />
                                  ))}
                                </Bar>
                              </BarChart>
                            </ResponsiveContainer>
                          </div>
                        </motion.div>
                      )}

                      {activeVisualTab === 'diagnostic' && (
                        <motion.div
                          key="diagnostic"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="h-full grid grid-cols-1 md:grid-cols-3 gap-3.5 overflow-y-auto pr-1"
                        >
                          {/* Box 1: Strengths & Weaknesses */}
                          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-150 space-y-2">
                            <h4 className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500">
                              {language === 'fr' ? 'Points Clés' : 'Key Areas'}
                            </h4>
                            
                            <div className="space-y-1.5 pt-0.5">
                              {strongestSubject && (
                                <div className="flex items-center justify-between bg-white px-2.5 py-2 rounded-lg border border-slate-100 shadow-3xs">
                                  <div className="space-y-0.5">
                                    <div className="text-[9px] text-emerald-600 font-bold flex items-center gap-1">
                                      <Sparkles className="h-3 w-3" /> {language === 'fr' ? 'Point fort' : 'Strength'}
                                    </div>
                                    <div className="text-xs font-bold text-slate-800 truncate max-w-[120px]">{strongestSubject.subject}</div>
                                    {strongestSubjectClassAvg !== null && (
                                      <div className="text-[9px] text-slate-400 font-medium">
                                        {language === 'fr' ? 'Classe : ' : 'Class: '}
                                        <span className="font-bold text-slate-600">{strongestSubjectClassAvg.toFixed(1)}/20</span>
                                        {` (${strongestSubject.average - strongestSubjectClassAvg >= 0 ? '+' : ''}${(strongestSubject.average - strongestSubjectClassAvg).toFixed(1)})`}
                                      </div>
                                    )}
                                  </div>
                                  <div className="text-sm font-black text-emerald-600">{strongestSubject.average} <span className="text-[9px] font-medium text-slate-400">/20</span></div>
                                </div>
                              )}

                              {weakestSubject && strongestSubject?.subject !== weakestSubject.subject && (
                                <div className="flex items-center justify-between bg-white px-2.5 py-2 rounded-lg border border-slate-100 shadow-3xs">
                                  <div className="space-y-0.5">
                                    <div className="text-[9px] text-rose-600 font-bold flex items-center gap-1">
                                      <AlertCircle className="h-3 w-3" /> {language === 'fr' ? 'À consolider' : 'Needs Work'}
                                    </div>
                                    <div className="text-xs font-bold text-slate-800 truncate max-w-[120px]">{weakestSubject.subject}</div>
                                    {weakestSubjectClassAvg !== null && (
                                      <div className="text-[9px] text-slate-400 font-medium">
                                        {language === 'fr' ? 'Classe : ' : 'Class: '}
                                        <span className="font-bold text-slate-600">{weakestSubjectClassAvg.toFixed(1)}/20</span>
                                        {` (${weakestSubject.average - weakestSubjectClassAvg >= 0 ? '+' : ''}${(weakestSubject.average - weakestSubjectClassAvg).toFixed(1)})`}
                                      </div>
                                    )}
                                  </div>
                                  <div className="text-sm font-black text-rose-500">{weakestSubject.average} <span className="text-[9px] font-medium text-slate-400">/20</span></div>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Box 2: Rigour & Volatility */}
                          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-150 space-y-2">
                            <h4 className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500">
                              {language === 'fr' ? 'Régularité du Profil' : 'Academic Consistency'}
                            </h4>
                            <div className="space-y-1.5 pt-0.5">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-semibold text-slate-600">{language === 'fr' ? 'Écart-type' : 'Std Deviation'} :</span>
                                <span className="text-xs font-mono font-bold text-slate-800">{stdDevVal.toFixed(2)}</span>
                              </div>
                              <div className="bg-white p-2 rounded-lg border border-slate-100 text-[10px] font-medium text-slate-500 shadow-3xs leading-relaxed">
                                {stdDevVal < 1.5 ? (
                                  <span className="text-emerald-700 font-semibold">
                                    {language === 'fr' 
                                      ? '✓ Résultats très homogènes. Le travail est régulier à chaque évaluation.'
                                      : '✓ Highly consistent results across different tests.'}
                                  </span>
                                ) : stdDevVal < 3.0 ? (
                                  <span className="text-indigo-700 font-semibold">
                                    {language === 'fr' 
                                      ? '⚠ Écart-type modéré. Des variations mineures selon les thématiques.'
                                      : '⚠ Moderate consistency. Results vary slightly between chapters.'}
                                  </span>
                                ) : (
                                  <span className="text-rose-600 font-semibold">
                                    {language === 'fr' 
                                      ? '⚡ Forte volatilité. Des pics d\'excellence alternés de notes plus fragiles.'
                                      : '⚡ High grade volatility. Significant gaps between top and lower scores.'}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Box 3: Dynamics & Forecast */}
                          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-150 space-y-2">
                            <h4 className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500">
                              {language === 'fr' ? 'Tendance & Appréciation' : 'Semester Trend'}
                            </h4>
                            <div className="space-y-1.5 pt-0.5">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-semibold text-slate-600">{language === 'fr' ? 'Tendance' : 'Trend'} :</span>
                                <div className="flex items-center gap-1 text-xs font-bold">
                                  {trendDiffVal > 0.5 ? (
                                    <span className="text-emerald-600 flex items-center gap-0.5">
                                      <TrendingUp className="h-3.5 w-3.5" /> +{trendDiffVal.toFixed(1)}
                                    </span>
                                  ) : trendDiffVal < -0.5 ? (
                                    <span className="text-rose-600 flex items-center gap-0.5">
                                      <TrendingDown className="h-3.5 w-3.5" /> {trendDiffVal.toFixed(1)}
                                    </span>
                                  ) : (
                                    <span className="text-slate-500">
                                      {language === 'fr' ? 'Stable' : 'Stable'} ({trendDiffVal >= 0 ? '+' : ''}{trendDiffVal.toFixed(1)})
                                    </span>
                                  )}
                                </div>
                              </div>
                              <div className="bg-white p-2 rounded-lg border border-slate-100 text-[10px] font-medium text-slate-500 shadow-3xs leading-relaxed">
                                <span className="text-slate-700 font-medium">
                                  {language === 'fr' ? 'Mention indicative : ' : 'Indicative honor: '}
                                  <span className="font-extrabold text-indigo-700">{getHonorsMention(Number(averageMark))}</span>
                                </span>
                                <p className="mt-1 border-t border-slate-100 pt-1 text-[9px] text-slate-400">
                                  {language === 'fr' 
                                    ? 'Analyse automatisée basée sur l\'évolution relative du trimestre.'
                                    : 'Diagnostic analysis based on progress over consecutive periods.'}
                                </p>
                              </div>
                              <button
                                onClick={handleExportTrendPDF}
                                className="mt-2 w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-[10px] font-bold transition flex items-center justify-center gap-1 cursor-pointer active:scale-97 shadow-xs"
                                type="button"
                              >
                                <Download className="h-3 w-3 text-emerald-200" />
                                <span>{language === 'fr' ? 'Télécharger Rapport Tendance' : 'Download Trend Report'}</span>
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  ) : (
                    <div className="h-full w-full bg-slate-50 rounded-2xl animate-pulse flex items-center justify-center text-xs text-slate-400 font-medium font-sans">
                      {language === 'fr' ? 'Chargement du tableau de bord...' : 'Loading performance dashboard...'}
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })()}

          {/* Select and Filter Row */}
          <div className="space-y-3">
            {/* Review Status Banner if there are grades pending review */}
            {pendingReviewCount > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-between gap-3 flex-wrap text-amber-900 dark:text-amber-200"
              >
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-xl shrink-0">
                    <AlertTriangle className="h-4 w-4 animate-bounce" />
                  </div>
                  <div>
                    <p className="text-xs font-black leading-tight">
                      {language === 'en' 
                        ? `${pendingReviewCount} grade(s) flagged for 'Pending Review'` 
                        : `${pendingReviewCount} évaluation(s) marquée(s) "En attente de révision"`}
                    </p>
                    <p className="text-[11px] text-amber-800/80 dark:text-amber-300/80">
                      {language === 'en'
                        ? "Check flagged assessments, adjust marks if needed, and communicate updates to parents."
                        : "Vérifiez les notes signalées, ajustez-les si besoin et informez directement les parents."}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setFilterReviewStatus(filterReviewStatus === 'pending' ? 'all' : 'pending')}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
                >
                  {filterReviewStatus === 'pending' 
                    ? (language === 'en' ? "Show all grades" : "Afficher toutes les notes")
                    : (language === 'en' ? "Filter pending only" : "Filtrer les notes en révision")}
                </button>
              </motion.div>
            )}

            <div className="flex items-center justify-between flex-wrap gap-2 pt-2 border-t border-gray-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-200">
                  {language === 'en' ? "Assessment Breakdown" : "Détail des Évaluations"}
                </h3>
                <button
                  type="button"
                  onClick={handleExportGradesPDF}
                  className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer active:scale-97"
                  title="Télécharger le relevé de notes complet en PDF"
                >
                  <FileText className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" />
                  <span>{language === 'en' ? "Export PDF" : "Exporter en PDF"}</span>
                </button>
              </div>

              {/* Status and Subject Filters */}
              <div className="flex items-center gap-2.5 flex-wrap text-left">
                {/* Review status filter */}
                <div className="flex bg-gray-100 dark:bg-slate-800 p-0.5 rounded-xl border border-gray-200 dark:border-slate-700">
                  <button
                    type="button"
                    onClick={() => setFilterReviewStatus('all')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                      filterReviewStatus === 'all'
                        ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-3xs'
                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                    }`}
                  >
                    {language === 'en' ? 'All' : 'Toutes'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterReviewStatus('pending')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all flex items-center gap-1.5 ${
                      filterReviewStatus === 'pending'
                        ? 'bg-amber-500 text-white shadow-3xs'
                        : 'text-amber-700 dark:text-amber-400 hover:text-amber-900'
                    }`}
                  >
                    <span>{language === 'en' ? 'In Review' : 'En révision'}</span>
                    {pendingReviewCount > 0 && (
                      <span className={`px-1.5 py-0.2 text-[9px] rounded-full font-black ${
                        filterReviewStatus === 'pending' ? 'bg-amber-700 text-white' : 'bg-amber-200 dark:bg-amber-900/80 text-amber-900 dark:text-amber-200'
                      }`}>
                        {pendingReviewCount}
                      </span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterReviewStatus('corrected')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition-all ${
                      filterReviewStatus === 'corrected'
                        ? 'bg-sky-600 text-white shadow-3xs'
                        : 'text-sky-700 dark:text-sky-400 hover:text-sky-900'
                    }`}
                  >
                    {language === 'en' ? 'Corrected' : 'Rectifiées'}
                  </button>
                </div>

                {/* Subject filter */}
                <div className="flex bg-gray-100 dark:bg-slate-800 p-0.5 rounded-xl border border-gray-200 dark:border-slate-700 max-w-full overflow-x-auto">
                  {subjects.slice(0, 7).map((subj) => (
                    <button
                      key={subj}
                      onClick={() => setSelectedSubject(subj)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-medium cursor-pointer transition-all shrink-0 ${
                        selectedSubject === subj
                          ? 'bg-white dark:bg-slate-700 text-gray-900 dark:text-white shadow-3xs'
                          : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                      }`}
                    >
                      {subj === 'all' ? (language === 'en' ? 'All Subjects' : 'Toutes') : subj}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {filteredGrades.map((g, idx) => {
                  const relativeScore = (g.score / g.maxScore) * 20;
                  const isCustom = g.id.startsWith('gr_') && Number(g.id.split('_')[1]) > 10000;
                  const isPendingReview = g.status === 'PendingReview';
                  const isCorrected = g.status === 'Corrected';

                  return (
                    <motion.div
                      key={g.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ delay: idx * 0.04 }}
                      className={`p-4 rounded-2xl flex items-center justify-between gap-4 flex-wrap hover:shadow-xs group duration-200 transition-all ${
                        isPendingReview
                          ? 'bg-amber-50/40 dark:bg-amber-950/20 border-2 border-amber-300/80 dark:border-amber-700/60 shadow-xs'
                          : isCorrected
                          ? 'bg-sky-50/30 dark:bg-sky-950/20 border border-sky-200/80 dark:border-sky-800/60'
                          : 'bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800'
                      }`}
                    >
                      <div className="flex-1 space-y-1 min-w-[220px]">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-gray-300 px-2.5 py-0.5 rounded-md font-medium">
                            {g.subject}
                          </span>
                          <span className="text-[11px] font-mono text-gray-400">
                            {new Date(g.date).toLocaleDateString(language === 'en' ? 'en-US' : 'fr-FR')}
                          </span>

                          {/* Review Status Badges */}
                          {isPendingReview ? (
                            <span className="text-[10px] font-black bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700 px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs animate-pulse">
                              <AlertTriangle className="h-3 w-3 text-amber-600 dark:text-amber-400" />
                              {language === 'en' ? 'Pending Review' : 'En attente de révision'}
                            </span>
                          ) : isCorrected ? (
                            <span className="text-[10px] font-black bg-sky-100 dark:bg-sky-900/60 text-sky-800 dark:text-sky-300 border border-sky-300 dark:border-sky-700 px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs">
                              <Sparkles className="h-3 w-3 text-sky-600 dark:text-sky-400" />
                              {language === 'en' ? 'Corrected' : 'Note Rectifiée'}
                            </span>
                          ) : activeStudent?.gradesValidated ? (
                            <span className="text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1 select-none">
                              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                              {language === 'en' ? 'Validated' : 'Validé'}
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 px-2 py-0.5 rounded-full flex items-center gap-1 select-none">
                              <span className="h-1.5 w-1.5 rounded-full bg-slate-400" />
                              {language === 'en' ? 'Published' : 'Publiée'}
                            </span>
                          )}
                        </div>

                        <h4 className="font-bold text-gray-900 dark:text-white text-sm">
                          {g.examName}
                        </h4>

                        {g.teacherRemarks && (
                          <p className="text-xs text-gray-500 dark:text-gray-400 italic">
                            "{g.teacherRemarks}"
                          </p>
                        )}

                        {/* Review Reason & Parent Notification Indicators */}
                        {(g.reviewReason || g.parentNotified || isPendingReview) && (
                          <div className="pt-1 flex items-center gap-2 flex-wrap">
                            {g.reviewReason && (
                              <span className="text-[10.5px] font-semibold text-amber-800 dark:text-amber-300 bg-amber-100/70 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800/60 px-2 py-0.5 rounded-md flex items-center gap-1">
                                <Flag className="h-3 w-3 text-amber-600" />
                                <span className="font-bold">{language === 'en' ? 'Reason:' : 'Motif :'}</span> {g.reviewReason}
                              </span>
                            )}
                            {g.parentNotified && (
                              <span className="text-[10px] font-medium text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 px-1.5 py-0.5 rounded-md flex items-center gap-1">
                                <CheckCheck className="h-3 w-3 text-emerald-600" />
                                <span>{language === 'en' ? 'Parent notified' : 'Parent notifié'}</span>
                              </span>
                            )}
                            {g.originalScore !== undefined && (
                              <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                                {language === 'en' ? 'Initial mark:' : 'Note initiale :'} {g.originalScore}/{g.originalMaxScore || 20}
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Display score and actions */}
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className={`text-lg font-bold px-3 py-1 rounded-xl inline-block ${
                            isPendingReview
                              ? 'bg-amber-100 dark:bg-amber-900/50 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700'
                              : relativeScore >= 16 ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300' :
                              relativeScore >= 12 ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300' :
                              relativeScore >= 10 ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300' :
                              'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300'
                          }`}>
                            {g.score} <span className="text-xs opacity-60">/ {g.maxScore}</span>
                          </span>
                          <div className="text-[10px] text-gray-400 font-mono mt-1">
                            {relativeScore.toFixed(1)} / 20 eq.
                          </div>
                        </div>

                        {/* Correction Tool Button */}
                        {onUpdateGrade && (
                          <button
                            type="button"
                            onClick={() => handleOpenCorrection(g)}
                            className={`p-2 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/60 text-amber-700 dark:text-amber-300 border border-amber-200/80 dark:border-amber-800/60 rounded-xl transition duration-200 cursor-pointer flex items-center gap-1.5 ${
                              isPedAuthorized || isCustom ? 'opacity-100' : 'opacity-70 hover:opacity-100 md:opacity-0 md:group-hover:opacity-100'
                            }`}
                            title={language === 'en' ? "Correction Tool / Flag for Review" : "Outil de Correction / Mettre en révision"}
                          >
                            <SlidersHorizontal className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                            <span className="text-xs font-bold hidden sm:inline">
                              {language === 'en' ? "Correction Tool" : "Correction"}
                            </span>
                          </button>
                        )}

                        {/* Delete Grade Button */}
                        {onDeleteGrade && (
                          <button
                            type="button"
                            onClick={() => handleDeletePrompt(g)}
                            className={`text-red-650 hover:text-red-800 dark:text-red-400 p-2 bg-red-100/15 hover:bg-red-200/30 border border-transparent hover:border-red-500/10 rounded-xl transition duration-200 cursor-pointer ${
                              isPedAuthorized || isCustom ? 'opacity-100' : 'opacity-45 hover:opacity-100 md:opacity-0 md:group-hover:opacity-100'
                            }`}
                            title={language === 'en' ? "Delete this grade" : "Supprimer cette note"}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>
        </>
      )}
      </>
      )}

      {/* Floating Success Toast Alert */}
      <AnimatePresence>
        {correctionSuccessMsg && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 bg-emerald-900 text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-emerald-600/50 flex items-center gap-3 text-xs font-bold"
          >
            <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />
            <span>{correctionSuccessMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Correction Tool Modal */}
      <AnimatePresence>
        {gradeToCorrect && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 12 }}
              className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-amber-200/80 dark:border-amber-900/50 max-w-lg w-full p-6 space-y-5 overflow-hidden relative text-slate-900 dark:text-slate-100 my-8"
            >
              {/* Top Accent Gradient Bar */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-indigo-600" />

              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 rounded-2xl shrink-0">
                    <SlidersHorizontal className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white leading-tight">
                      {language === 'en' ? "Grade Correction & Review Tool" : "Outil de Correction & Révision Pédagogique"}
                    </h3>
                    <p className="text-xs text-amber-700 dark:text-amber-400 font-bold">
                      {language === 'en' 
                        ? "Flag for 'Pending Review' or adjust grade and notify parents" 
                        : "Mettre en attente de révision ou corriger la note avec notification parentale"}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setGradeToCorrect(null)}
                  disabled={isSavingCorrection}
                  className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-50"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Assessment Context Box */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider">
                    {language === 'en' ? "Target Evaluation" : "Évaluation Ciblée"}
                  </span>
                  <span className="text-xs font-black text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 px-2.5 py-0.5 rounded-lg">
                    {gradeToCorrect.subject}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="min-w-0 pr-2">
                    <p className="text-xs font-extrabold text-slate-900 dark:text-white truncate">
                      {gradeToCorrect.examName}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                      <Calendar className="h-3 w-3 text-slate-400" />
                      <span>{new Date(gradeToCorrect.date).toLocaleDateString(language === 'en' ? 'en-US' : 'fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-2 py-1 rounded-lg">
                      {language === 'en' ? 'Current:' : 'Actuelle :'} {gradeToCorrect.score}/{gradeToCorrect.maxScore}
                    </span>
                  </div>
                </div>
              </div>

              {/* Form Controls */}
              <div className="space-y-4 text-left">
                {/* Review Status Choice */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    {language === 'en' ? "Select Status :" : "Statut pédagogique de la note :"}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setCorrStatus('PendingReview')}
                      className={`p-2.5 rounded-xl border text-xs font-bold cursor-pointer transition flex flex-col items-center gap-1 text-center ${
                        corrStatus === 'PendingReview'
                          ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-400 dark:border-amber-600 text-amber-900 dark:text-amber-200 ring-2 ring-amber-400/40'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-amber-300'
                      }`}
                    >
                      <AlertTriangle className={`h-4 w-4 ${corrStatus === 'PendingReview' ? 'text-amber-600 animate-pulse' : 'text-slate-400'}`} />
                      <span>{language === 'en' ? 'Pending Review' : 'En révision'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setCorrStatus('Corrected')}
                      className={`p-2.5 rounded-xl border text-xs font-bold cursor-pointer transition flex flex-col items-center gap-1 text-center ${
                        corrStatus === 'Corrected'
                          ? 'bg-sky-50 dark:bg-sky-950/60 border-sky-400 dark:border-sky-600 text-sky-900 dark:text-sky-200 ring-2 ring-sky-400/40'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-sky-300'
                      }`}
                    >
                      <Sparkles className={`h-4 w-4 ${corrStatus === 'Corrected' ? 'text-sky-600' : 'text-slate-400'}`} />
                      <span>{language === 'en' ? 'Corrected' : 'Rectifiée'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setCorrStatus('Published')}
                      className={`p-2.5 rounded-xl border text-xs font-bold cursor-pointer transition flex flex-col items-center gap-1 text-center ${
                        corrStatus === 'Published'
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-400 dark:border-emerald-600 text-emerald-900 dark:text-emerald-200 ring-2 ring-emerald-400/40'
                          : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-emerald-300'
                      }`}
                    >
                      <CheckCircle className={`h-4 w-4 ${corrStatus === 'Published' ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span>{language === 'en' ? 'Validated / Published' : 'Validée / Publiée'}</span>
                    </button>
                  </div>
                </div>

                {/* Review Reason Predefined Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'en' ? "Reason for Review / Flagging :" : "Motif de la révision / signalement :"}
                  </label>
                  <select
                    value={corrReason}
                    onChange={(e) => setCorrReason(e.target.value)}
                    className="w-full text-xs font-medium bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="Erreur de saisie / report de note">Erreur de saisie / report de note</option>
                    <option value="Réclamation parentale / contestation légitime">Réclamation parentale / contestation légitime</option>
                    <option value="Barème d'évaluation recalculé">Barème d'évaluation recalculé</option>
                    <option value="Copie recomptée ou réévaluée">Copie recomptée ou réévaluée</option>
                    <option value="Épreuve de rattrapage effectuée">Épreuve de rattrapage effectuée</option>
                    <option value="Absence justifiée / Devoir remis ultérieurement">Absence justifiée / Devoir remis ultérieurement</option>
                    <option value="Autre motif...">Autre motif personnalisé...</option>
                  </select>
                </div>

                {(corrReason === 'Autre motif...' || corrReason === 'Other reason...') && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                    <input
                      type="text"
                      value={customCorrReason}
                      onChange={(e) => setCustomCorrReason(e.target.value)}
                      placeholder={language === 'en' ? "Specify reason..." : "Précisez le motif..."}
                      className="w-full text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    />
                  </motion.div>
                )}

                {/* Score adjustment */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {language === 'en' ? "Adjusted Score :" : "Note attribuée :"}
                    </label>
                    <input
                      type="number"
                      step="0.25"
                      min="0"
                      max={corrMaxScore}
                      value={corrScore}
                      onChange={(e) => setCorrScore(Number(e.target.value))}
                      className="w-full text-sm font-bold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {language === 'en' ? "Out of (Max) :" : "Sur barème de :"}
                    </label>
                    <input
                      type="number"
                      step="1"
                      min="1"
                      value={corrMaxScore}
                      onChange={(e) => setCorrMaxScore(Number(e.target.value))}
                      className="w-full text-sm font-bold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                {/* Pedagogical Note / Teacher Word */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {language === 'en' ? "Teacher's Review Note (visible to parents) :" : "Mot d'explication pédagogique pour les parents :"}
                  </label>
                  <textarea
                    rows={2}
                    value={corrNote}
                    onChange={(e) => setCorrNote(e.target.value)}
                    placeholder={language === 'en' 
                      ? "Add an explanatory note for parents regarding this review or correction..." 
                      : "Expliquez brièvement le contexte de la révision ou de la rectification pour le parent d'élève..."}
                    className="w-full text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-amber-500 resize-none"
                  />
                </div>

                {/* Parent Notification Checkbox */}
                <div className="p-3 bg-amber-50/70 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-900/50 rounded-2xl flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="notifyParentCheckbox"
                    checked={corrNotifyParent}
                    onChange={(e) => setCorrNotifyParent(e.target.checked)}
                    className="mt-0.5 h-4 w-4 text-amber-600 rounded border-amber-300 focus:ring-amber-500 cursor-pointer"
                  />
                  <label htmlFor="notifyParentCheckbox" className="text-xs text-slate-700 dark:text-slate-300 cursor-pointer leading-tight space-y-0.5">
                    <span className="font-extrabold text-amber-900 dark:text-amber-200 flex items-center gap-1">
                      <Mail className="h-3.5 w-3.5 text-amber-600" />
                      {language === 'en' ? "Send automatic notification to student's parent" : "Envoyer une notification automatique au parent de l'élève"}
                    </span>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {language === 'en'
                        ? "Transmits a formal alert in the Parent Portal with the review status, motive, and updated evaluation score."
                        : "Transmet un message formel dans l'espace Parent avec le statut de révision, le motif et la note actualisée."}
                    </p>
                  </label>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setGradeToCorrect(null)}
                  disabled={isSavingCorrection}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer disabled:opacity-50"
                >
                  {language === 'en' ? "Cancel" : "Annuler"}
                </button>
                <button
                  type="button"
                  onClick={handleSaveCorrection}
                  disabled={isSavingCorrection}
                  className="px-5 py-2.5 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-700 hover:to-orange-700 active:scale-95 text-white rounded-xl text-xs font-black shadow-md shadow-amber-600/20 transition cursor-pointer flex items-center gap-2 disabled:opacity-50"
                >
                  {isSavingCorrection ? (
                    <>
                      <RotateCw className="h-4 w-4 animate-spin" />
                      <span>{language === 'en' ? "Saving..." : "Enregistrement..."}</span>
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      <span>
                        {corrStatus === 'PendingReview'
                          ? (language === 'en' ? "Flag for Pending Review & Notify" : "Placer en Révision & Notifier")
                          : (language === 'en' ? "Save Correction & Notify" : "Valider la Correction & Notifier")}
                      </span>
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Visually Harmonized Confirmation Modal for Grade Deletion */}
      <AnimatePresence>
        {gradeToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-rose-200/80 dark:border-rose-900/50 max-w-md w-full p-6 space-y-5 overflow-hidden relative text-slate-900 dark:text-slate-100"
            >
              {/* Top Accent Gradient Bar */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-rose-500 via-red-600 to-amber-500" />

              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 rounded-2xl shrink-0">
                    <Trash2 className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white leading-tight">
                      {language === 'en' ? "Delete Grade Assessment" : "Suppression de Note / Évaluation"}
                    </h3>
                    <p className="text-xs text-rose-600 dark:text-rose-400 font-bold">
                      {language === 'en' ? "Irreversible action • Recalculates averages" : "Action irréversible • Recalcul immédiat des moyennes"}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setGradeToDelete(null)}
                  disabled={isDeletingGrade}
                  className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer disabled:opacity-50"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Grade Preview Summary Box */}
              <div className="p-4 bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200/70 dark:border-rose-900/40 rounded-2xl space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] font-black text-rose-900/70 dark:text-rose-300/70 uppercase tracking-wider">
                    {language === 'en' ? "Grade assessment details" : "Détails de l'évaluation ciblée"}
                  </span>
                  <span className="text-[10.5px] font-extrabold px-2.5 py-0.5 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 rounded-lg">
                    {gradeToDelete.subject}
                  </span>
                </div>

                <div className="flex items-center justify-between bg-white dark:bg-slate-850 p-3 rounded-xl border border-rose-100 dark:border-rose-900/30">
                  <div className="min-w-0 pr-2">
                    <p className="text-xs font-black text-slate-900 dark:text-white truncate">
                      {gradeToDelete.examName || (language === 'en' ? 'Assessment' : 'Évaluation')}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                      <Calendar className="h-3 w-3 text-slate-400" />
                      <span>{new Date(gradeToDelete.date).toLocaleDateString(language === 'en' ? 'en-US' : 'fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-base font-black px-2.5 py-1 rounded-lg bg-rose-150/60 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                      {gradeToDelete.score} / {gradeToDelete.maxScore}
                    </span>
                    <div className="text-[9.5px] font-mono text-slate-400 mt-1">
                      {((gradeToDelete.score / gradeToDelete.maxScore) * 20).toFixed(1)} / 20
                    </div>
                  </div>
                </div>

                {gradeToDelete.teacherRemarks && (
                  <p className="text-xs text-slate-600 dark:text-slate-300 italic bg-white/70 dark:bg-slate-800/60 p-2.5 rounded-xl border border-rose-100/80 dark:border-rose-900/30">
                    « {gradeToDelete.teacherRemarks} »
                  </p>
                )}
              </div>

              {/* Warning Notice */}
              <div className="p-3 bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/40 rounded-xl space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-black text-amber-900 dark:text-amber-300">
                  <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>{language === 'en' ? "Warning • Impact on report cards" : "Avertissement • Impact sur les bulletins"}</span>
                </div>
                <p className="text-[11px] text-amber-900/80 dark:text-amber-300/80 leading-relaxed">
                  {language === 'en'
                    ? "Deleting this grade will automatically update the student's subject and overall averages on their grade report and parent portal."
                    : "La suppression de cette note recalculera automatiquement la moyenne de la matière et la moyenne générale de l'élève sur son relevé et son bulletin."}
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setGradeToDelete(null)}
                  disabled={isDeletingGrade}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer disabled:opacity-50"
                >
                  {language === 'en' ? "Cancel" : "Annuler"}
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDeleteGrade}
                  disabled={isDeletingGrade}
                  className="px-5 py-2.5 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 active:scale-95 text-white rounded-xl text-xs font-black shadow-md shadow-rose-600/20 transition cursor-pointer flex items-center gap-2 disabled:opacity-50"
                >
                  {isDeletingGrade ? (
                    <>
                      <RotateCw className="h-4 w-4 animate-spin" />
                      <span>{language === 'en' ? "Deleting..." : "Suppression en cours..."}</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="h-4 w-4" />
                      <span>{language === 'en' ? "Confirm Deletion" : "Supprimer définitivement"}</span>
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
